import { Mic, Square, Volume2 } from "lucide-react";
import { useEffect, useRef, useState, type RefObject } from "react";

export type VoiceCapability = {
  transcription: { available: boolean; engine: string; reason?: string };
  speech: { available: boolean; engine: string; reason?: string };
  limits: { maxSeconds: number; maxBytes: number };
};
type InputState =
  | { phase: "idle" }
  | { phase: "requesting" }
  | { phase: "recording"; seconds: number }
  | { phase: "transcribing" }
  | { phase: "review"; source: string }
  | { phase: "error"; message: string; retryable: boolean; code?: string };
type SpeechState = "idle" | "generating" | "ready" | "playing" | "paused" | "ended" | "error";
type MicrophoneDetails = {
  permission: PermissionState | "unavailable";
  secureContext?: boolean;
  captureSupported?: boolean;
  recorderSupported?: boolean;
  stage: "not requested" | "requesting access" | "access received" | "recording" | "recording stopped" | "cancelled" | "failed";
  error?: string;
};
type MicrophonePreview = { url: string; fileName: string };
const CAPTURE_WAIT_MS = 20_000;
const MAX_SECONDS = 30;
const MAX_BYTES = 8_388_608;

export function useVoiceCapability() {
  const [capability, setCapability] = useState<VoiceCapability>();
  const [error, setError] = useState<string>();
  useEffect(() => {
    const controller = new AbortController();
    void fetch("/api/homeops/voice/status", { signal: controller.signal })
      .then(async (response) => {
        if (!response.ok) throw new Error("Voice status is unavailable. You can still type.");
        const result = await response.json() as VoiceCapability;
        if (typeof result.transcription?.available !== "boolean" || typeof result.speech?.available !== "boolean")
          throw new Error("Voice status could not be read. You can still type.");
        setCapability(result);
      })
      .catch((problem: unknown) => {
        if (!controller.signal.aborted) setError(errorMessage(problem));
      });
    return () => controller.abort();
  }, []);
  return { capability, error };
}

async function responseError(response: Response) {
  const result = await response.json().catch(() => null);
  return new Error(result?.error?.message ?? `Voice request failed (${response.status}).`);
}

function errorMessage(problem: unknown) {
  return problem instanceof Error ? problem.message : "Voice request failed. Please try again or type.";
}

async function audioBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("The audio file could not be read."));
    reader.onload = () => resolve(String(reader.result).split(",")[1] ?? "");
    reader.readAsDataURL(blob);
  });
}

export function VoiceInput({ csrf, capability, capabilityError, disabled, onTranscript, onBusyChange, onBeforeCapture }: {
  csrf?: string;
  capability?: VoiceCapability;
  capabilityError?: string;
  disabled: boolean;
  onTranscript: (text: string) => void;
  onBusyChange: (busy: boolean) => void;
  onBeforeCapture?: () => void;
}) {
  const [state, setState] = useState<InputState>({ phase: "idle" });
  const [microphone, setMicrophone] = useState<MicrophoneDetails>({ permission: "unavailable", stage: "not requested" });
  const [inputSource, setInputSource] = useState<"live-microphone" | "recorded-audio">();
  const [preview, setPreview] = useState<MicrophonePreview>();
  const previewRef = useRef<MicrophonePreview | undefined>(undefined);
  const previewAudio = useRef<HTMLAudioElement>(null);
  const permissionDeadline = useRef<ReturnType<typeof setTimeout> | null>(null);
  const recorder = useRef<MediaRecorder | null>(null);
  const stream = useRef<MediaStream | null>(null);
  const timer = useRef<ReturnType<typeof setInterval> | null>(null);
  const captureDeadline = useRef<ReturnType<typeof setTimeout> | null>(null);
  const request = useRef<AbortController | null>(null);
  const generation = useRef(0);
  const retryAudio = useRef<{ blob: Blob; source: string } | null>(null);
  const transcriptCallback = useRef(onTranscript);
  transcriptCallback.current = onTranscript;
  const active = ["requesting", "recording", "transcribing"].includes(state.phase);

  function clearPreview(updateState = true) {
    previewAudio.current?.pause();
    previewAudio.current?.removeAttribute("src");
    previewAudio.current?.load();
    if (previewRef.current) URL.revokeObjectURL(previewRef.current.url);
    previewRef.current = undefined;
    if (updateState) setPreview(undefined);
  }

  function observeMicrophone(token: number) {
    setMicrophone((value) => ({ ...value, secureContext: window.isSecureContext,
      captureSupported: Boolean(navigator.mediaDevices?.getUserMedia), recorderSupported: typeof MediaRecorder !== "undefined" }));
    if (permissionDeadline.current) clearTimeout(permissionDeadline.current);
    const unavailable = () => {
      if (token === generation.current) setMicrophone((value) => ({ ...value, permission: "unavailable" }));
    };
    permissionDeadline.current = setTimeout(unavailable, 1_000);
    try {
      const query = navigator.permissions?.query({ name: "microphone" as PermissionName });
      if (!query) {
        clearTimeout(permissionDeadline.current);
        permissionDeadline.current = null;
        unavailable();
        return;
      }
      void query.then((result) => {
        if (token === generation.current) {
          if (permissionDeadline.current) clearTimeout(permissionDeadline.current);
          permissionDeadline.current = null;
          setMicrophone((value) => ({ ...value, permission: result.state }));
        }
      }, () => {
        if (token === generation.current) {
          if (permissionDeadline.current) clearTimeout(permissionDeadline.current);
          permissionDeadline.current = null;
          unavailable();
        }
      });
    } catch {
      if (permissionDeadline.current) clearTimeout(permissionDeadline.current);
      permissionDeadline.current = null;
      unavailable();
    }
  }

  function releaseMicrophone() {
    if (captureDeadline.current) clearTimeout(captureDeadline.current);
    captureDeadline.current = null;
    if (timer.current) clearInterval(timer.current);
    timer.current = null;
    stream.current?.getTracks().forEach((track) => track.stop());
    stream.current = null;
  }

  useEffect(() => {
    onBusyChange(active);
  }, [active, onBusyChange]);
  useEffect(() => { observeMicrophone(generation.current); }, []);
  useEffect(() => () => {
    generation.current += 1;
    request.current?.abort();
    if (recorder.current) {
      recorder.current.onstop = null;
      recorder.current.ondataavailable = null;
      recorder.current.onerror = null;
      if (recorder.current.state !== "inactive") recorder.current.stop();
    }
    releaseMicrophone();
    if (permissionDeadline.current) clearTimeout(permissionDeadline.current);
    clearPreview(false);
    retryAudio.current = null;
  }, []);

  async function transcribe(blob: Blob, source: string, token = ++generation.current) {
    retryAudio.current = { blob, source };
    if (blob.size === 0 || blob.size > Math.min(capability?.limits.maxBytes ?? MAX_BYTES, MAX_BYTES)) {
      setState({ phase: "error", message: "Choose a nonempty recording under 8 MB and 30 seconds.", retryable: false });
      retryAudio.current = null;
      return;
    }
    setState({ phase: "transcribing" });
    request.current?.abort();
    const controller = new AbortController();
    request.current = controller;
    try {
      const encoded = await audioBase64(blob);
      if (token !== generation.current) return;
      const response = await fetch("/api/homeops/voice/transcribe", {
        method: "POST",
        headers: { "content-type": "application/json", "x-homeops-csrf": csrf ?? "" },
        signal: controller.signal,
        body: JSON.stringify({ audioBase64: encoded, mimeType: blob.type || "audio/wav" }),
      });
      if (!response.ok) throw await responseError(response);
      const result = await response.json() as { text?: unknown };
      if (typeof result.text !== "string" || !result.text.trim()) throw new Error("No words were recognized. Try a clearer recording or type your message.");
      if (token !== generation.current) return;
      transcriptCallback.current(result.text.trim());
      retryAudio.current = null;
      setState({ phase: "review", source });
    } catch (problem) {
      if (!controller.signal.aborted && token === generation.current)
        setState({ phase: "error", message: errorMessage(problem), retryable: true });
    }
  }

  function stopRecording() {
    if (recorder.current?.state === "recording") {
      setMicrophone((value) => ({ ...value, stage: "recording stopped" }));
      setState({ phase: "transcribing" });
      recorder.current.stop();
    }
    releaseMicrophone();
  }

  function cancel() {
    generation.current += 1;
    request.current?.abort();
    if (recorder.current) {
      recorder.current.onstop = null;
      recorder.current.ondataavailable = null;
      recorder.current.onerror = null;
      if (recorder.current.state !== "inactive") recorder.current.stop();
      recorder.current = null;
    }
    releaseMicrophone();
    clearPreview();
    retryAudio.current = null;
    setMicrophone((value) => ({ ...value, stage: "cancelled" }));
    setState({ phase: "idle" });
  }

  async function startRecording() {
    clearPreview();
    onBeforeCapture?.();
    const token = ++generation.current;
    setInputSource("live-microphone");
    setMicrophone((value) => ({ ...value, stage: "requesting access", error: undefined }));
    observeMicrophone(token);
    retryAudio.current = null;
    setState({ phase: "requesting" });
    try {
      if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === "undefined")
        throw new Error("Microphone recording is unavailable in this browser. Upload recorded audio or type below.");
      captureDeadline.current = setTimeout(() => {
        if (token !== generation.current) return;
        generation.current += 1;
        releaseMicrophone();
        setMicrophone((value) => ({ ...value, stage: "failed", error: "capture_timeout" }));
        setState({ phase: "error", code: "capture_timeout", retryable: false,
          message: "The browser has not returned microphone access. No recording started. Try Record message again, upload recorded audio or type your message." });
      }, CAPTURE_WAIT_MS);
      const acquired = await navigator.mediaDevices.getUserMedia({ audio: true });
      if (token !== generation.current) {
        acquired.getTracks().forEach((track) => track.stop());
        return;
      }
      if (captureDeadline.current) clearTimeout(captureDeadline.current);
      captureDeadline.current = null;
      stream.current = acquired;
      setMicrophone((value) => ({ ...value, stage: "access received" }));
      const mimeType = ["audio/webm;codecs=opus", "audio/mp4", "audio/ogg;codecs=opus", "audio/webm"]
        .find((type) => MediaRecorder.isTypeSupported(type));
      const recording = new MediaRecorder(acquired, mimeType ? { mimeType } : undefined);
      recorder.current = recording;
      const chunks: Blob[] = [];
      let bytes = 0;
      recording.ondataavailable = (event) => {
        chunks.push(event.data);
        bytes += event.data.size;
        if (bytes > MAX_BYTES) {
          recording.onstop = null;
          if (recording.state !== "inactive") recording.stop();
          releaseMicrophone();
          setMicrophone((value) => ({ ...value, stage: "failed", error: "recording_too_large" }));
          setState({ phase: "error", message: "Recording exceeded 8 MB. Try a shorter recording.", retryable: false });
        }
      };
      recording.onerror = () => {
        recording.onstop = null;
        if (recording.state !== "inactive") recording.stop();
        releaseMicrophone();
        setMicrophone((value) => ({ ...value, stage: "failed", error: "recording_failed" }));
        setState({ phase: "error", message: "Microphone recording failed. Try again, upload recorded audio or type.", retryable: false });
      };
      recording.onstop = () => {
        releaseMicrophone();
        recorder.current = null;
        if (token === generation.current) {
          setMicrophone((value) => ({ ...value, stage: "recording stopped" }));
          const blob = new Blob(chunks, { type: recording.mimeType });
          if (blob.size && blob.size <= MAX_BYTES) {
            const extension = blob.type.includes("mp4") ? "m4a" : blob.type.includes("ogg") ? "ogg" : "webm";
            const captured = { url: URL.createObjectURL(blob), fileName: `homeops-microphone.${extension}` };
            previewRef.current = captured;
            setPreview(captured);
          }
          void transcribe(blob, "Microphone recording", token);
        }
      };
      recording.start(250);
      setMicrophone((value) => ({ ...value, stage: "recording" }));
      setState({ phase: "recording", seconds: 0 });
      const startedAt = Date.now();
      const limit = Math.min(capability?.limits.maxSeconds ?? MAX_SECONDS, MAX_SECONDS);
      timer.current = setInterval(() => {
        const seconds = Math.floor((Date.now() - startedAt) / 1000);
        if (Date.now() - startedAt >= limit * 1000 - 500) stopRecording();
        else setState({ phase: "recording", seconds });
      }, 200);
    } catch (problem) {
      if (token !== generation.current) return;
      releaseMicrophone();
      const name = problem instanceof DOMException ? problem.name : "capture_failed";
      setMicrophone((value) => ({ ...value, stage: "failed", error: name }));
      const messages: Record<string, string> = {
        NotAllowedError: "The browser did not allow microphone access. Check microphone access for this app, upload recorded audio or type your message.",
        NotFoundError: "No microphone was found. Connect a microphone, upload recorded audio or type your message.",
        NotReadableError: "The microphone could not be opened. Check whether another app is using it, then try again, upload recorded audio or type.",
        SecurityError: "Microphone capture is disabled in this browser context. Upload recorded audio or type your message.",
        AbortError: "The browser interrupted microphone capture. Try again, upload recorded audio or type your message.",
      };
      setState({ phase: "error", code: name, message: messages[name] ?? errorMessage(problem), retryable: false });
    }
  }

  const available = capability?.transcription.available === true;
  return (
    <section className="voice-input" aria-label="Voice message" data-voice-input-state={state.phase}
      data-voice-error-code={state.phase === "error" ? state.code : undefined} data-voice-source={inputSource}
      data-microphone-permission={microphone.permission} data-microphone-stage={microphone.stage} data-microphone-error={microphone.error}>
      <div className="voice-toolbar">
        <button type="button" className={state.phase === "recording" ? "voice-record is-recording" : "voice-record"}
          disabled={disabled || !available || (active && state.phase !== "recording")}
          onClick={() => state.phase === "recording" ? stopRecording() : void startRecording()}>
          {state.phase === "recording" ? <Square size={14} /> : <Mic size={15} />}
          {state.phase === "recording" ? `Stop · ${state.seconds}s / 30s` : "Record message"}
        </button>
        {(active || preview) && <button type="button" className="text-button" onClick={cancel}>{active ? "Cancel audio" : "Discard microphone recording"}</button>}
      </div>
      <details className="recorded-audio-options">
        <summary>Use a recording instead</summary>
      <label className="recorded-audio-upload">
        <span>Upload recorded audio <small>30 seconds max · 8 MB</small></span>
        <input type="file" accept="audio/wav,audio/x-wav,audio/webm,audio/mp4,audio/mpeg,audio/ogg,.wav,.webm,.m4a,.mp3,.ogg"
          disabled={disabled || active || !available} onChange={(event) => {
            const file = event.currentTarget.files?.[0];
            event.currentTarget.value = "";
            if (file) {
              clearPreview();
              setInputSource("recorded-audio");
              void transcribe(file, `Recorded audio · ${file.name}`);
            }
          }} />
      </label>
      </details>
      <p className="voice-status" role={state.phase === "error" ? "alert" : "status"}>
        {state.phase === "requesting" ? "Allow microphone access to begin."
          : state.phase === "recording" ? "Recording. Stop when you’re finished."
          : state.phase === "transcribing" ? "Transcribing audio locally…"
          : state.phase === "review" ? `${state.source}. Review and edit the words below, then send.`
          : state.phase === "error" ? state.message
          : capabilityError ?? (!capability ? "Checking local voice capability…"
            : available ? "Speak, then review the words before sending."
            : capability.transcription.reason ?? "Local transcription is unavailable. You can still type.")}
      </p>
      {state.phase === "error" && state.retryable && retryAudio.current && (
        <button type="button" className="text-button" disabled={disabled} onClick={() => {
          if (retryAudio.current) void transcribe(retryAudio.current.blob, retryAudio.current.source);
        }}>Retry transcription</button>
      )}
      {preview && <div className="microphone-preview" data-audio-source="live-microphone">
        <p>Your microphone recording</p>
        <audio ref={previewAudio} controls preload="none" src={preview.url} aria-label="Your microphone recording" />
        <a className="speech-download" href={preview.url} download={preview.fileName}>Download microphone recording</a>
        <p className="voice-consent-note">Kept in this tab until you record again or discard it.</p>
      </div>}
      <details className="microphone-details">
        <summary>Microphone details</summary>
        <p>Browser permission report: {microphone.permission}. This report does not prove that capture can start.</p>
        <p>Secure context: {microphone.secureContext === undefined ? "checking" : microphone.secureContext ? "yes" : "no"}.
          {" "}Capture API: {microphone.captureSupported === undefined ? "checking" : microphone.captureSupported ? "available" : "unavailable"}.
          {" "}Recording API: {microphone.recorderSupported === undefined ? "checking" : microphone.recorderSupported ? "available" : "unavailable"}.</p>
        <p>Last capture stage: {microphone.stage}.{microphone.error ? ` Error: ${microphone.error}.` : ""}</p>
      </details>
      <p className="voice-consent-note">Voice never approves a service. Use the approval card to decide.</p>
    </section>
  );
}

export function AssistantSpeech({ text, messageId, csrf, capability, disabled, stopRef, sourceKind = "reply" }: {
  text: string; messageId?: string; csrf?: string; capability?: VoiceCapability; disabled: boolean;
  stopRef?: RefObject<(() => void) | null>;
  sourceKind?: "reply" | "approval";
}) {
  const [state, setState] = useState<SpeechState>("idle");
  const [error, setError] = useState<string>();
  const [source, setSource] = useState<string>();
  const [readNewReplies, setReadNewReplies] = useState(false);
  const [position, setPosition] = useState({ currentTime: 0, ended: false });
  const audio = useRef<HTMLAudioElement>(null);
  const request = useRef<AbortController | null>(null);
  const sourceRef = useRef<string | undefined>(undefined);
  const seenMessage = useRef<string | undefined>(messageId);
  const speakText = text.slice(0, 1800);

  function stop() {
    request.current?.abort();
    audio.current?.pause();
    if (audio.current) audio.current.currentTime = 0;
    setPosition({ currentTime: 0, ended: false });
    setState(sourceRef.current ? "ready" : "idle");
  }

  useEffect(() => {
    if (stopRef) stopRef.current = stop;
    return () => { if (stopRef) stopRef.current = null; };
  });

  async function generate() {
    request.current?.abort();
    audio.current?.pause();
    const controller = new AbortController();
    request.current = controller;
    setError(undefined);
    setState("generating");
    try {
      const response = await fetch("/api/homeops/voice/speak", {
        method: "POST", signal: controller.signal,
        headers: { "content-type": "application/json", "x-homeops-csrf": csrf ?? "" },
        body: JSON.stringify({ text: speakText }),
      });
      if (!response.ok) throw await responseError(response);
      const blob = await response.blob();
      if (controller.signal.aborted) return;
      if (!blob.size || !blob.type.startsWith("audio/")) throw new Error("The speech service did not return playable audio.");
      if (sourceRef.current) URL.revokeObjectURL(sourceRef.current);
      const url = URL.createObjectURL(blob);
      sourceRef.current = url;
      setSource(url);
      setPosition({ currentTime: 0, ended: false });
      if (audio.current) {
        audio.current.src = url;
        try {
          await audio.current.play();
        } catch {
          if (!controller.signal.aborted) {
            setState("ready");
            setError("Audio is ready. Press play on the player below.");
          }
        }
      }
    } catch (problem) {
      if (!controller.signal.aborted) {
        setError(errorMessage(problem));
        setState("error");
      }
    }
  }

  useEffect(() => {
    request.current?.abort();
    audio.current?.pause();
    if (sourceRef.current) URL.revokeObjectURL(sourceRef.current);
    sourceRef.current = undefined;
    setSource(undefined);
    setState("idle");
    setError(undefined);
    setPosition({ currentTime: 0, ended: false });
    if (messageId && messageId !== seenMessage.current) {
      seenMessage.current = messageId;
      if (readNewReplies && text && !disabled && capability?.speech.available) void generate();
    }
  }, [messageId, text]);
  useEffect(() => () => {
    request.current?.abort();
    audio.current?.pause();
    if (sourceRef.current) URL.revokeObjectURL(sourceRef.current);
  }, []);

  return (
    <section className="assistant-speech" aria-label={sourceKind === "approval" ? "Spoken approval request" : "Spoken assistant reply"} data-speech-state={state} data-spoken-source={sourceKind}>
      <div className="speech-actions">
        <button type="button" className="text-button" disabled={disabled || !text || !capability?.speech.available || state === "generating"}
          onClick={() => void generate()}><Volume2 size={15} />{state === "generating" ? "Preparing speech…" : state === "error" ? "Retry spoken audio" : sourceKind === "approval" ? "Listen to approval request" : "Listen to last reply"}</button>
        {(source || state === "generating") && <button type="button" className="text-button" onClick={stop}><Square size={12} />Stop speech</button>}
      </div>
      <label className="speech-opt-in"><input type="checkbox" checked={readNewReplies}
        disabled={!capability?.speech.available} onChange={(event) => setReadNewReplies(event.currentTarget.checked)} />Read replies and decisions aloud</label>
      <audio ref={audio} controls preload="none" src={source} aria-label={sourceKind === "approval" ? "Actual approval request audio" : "Actual assistant reply audio"} hidden={!source}
        onPlay={() => setState("playing")} onPause={() => setState((value) => value === "playing" ? "paused" : value)}
        onTimeUpdate={(event) => setPosition({ currentTime: event.currentTarget.currentTime, ended: event.currentTarget.ended })}
        onEnded={(event) => { setState("ended"); setPosition({ currentTime: event.currentTarget.currentTime, ended: true }); }}
        onError={() => { if (sourceRef.current) { setState("error"); setError("Audio playback failed. Retry the spoken reply."); } }} />
      {source && <output className="speech-progress" data-current-time={position.currentTime} data-ended={position.ended}>
        {position.ended ? "Playback finished" : `${position.currentTime.toFixed(1)} seconds played`}
      </output>}
      {source && <a className="speech-download" href={source} download={sourceKind === "approval" ? "homeops-approval.wav" : "homeops-reply.wav"}>{sourceKind === "approval" ? "Download approval audio" : "Download spoken reply"}</a>}
      {error && <p className="voice-status" role={state === "error" ? "alert" : "status"}>{error}</p>}
      {capability && !capability.speech.available && <p className="voice-status">{capability.speech.reason ?? "Spoken replies are unavailable. Replies remain readable above."}</p>}
      {text.length > 1800 && <p className="voice-status">Reads the first 1,800 characters of this reply.</p>}
      <details className="speech-source"><summary>{sourceKind === "approval" ? "Approval request text" : "Last assistant text"}</summary><p data-spoken-text={text} data-spoken-source={sourceKind}>{text || "No assistant reply yet."}</p></details>
    </section>
  );
}
