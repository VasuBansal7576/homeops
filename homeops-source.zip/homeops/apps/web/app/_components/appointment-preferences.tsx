import { useEffect, useRef, useState, type FormEvent } from "react";
import {
  AvailabilityPreferencesSchema,
  type AvailabilityPreferences,
} from "../../../../packages/contracts/src/index";

const weekdays = [
  { day: 1, short: "Mon", name: "Monday" },
  { day: 2, short: "Tue", name: "Tuesday" },
  { day: 3, short: "Wed", name: "Wednesday" },
  { day: 4, short: "Thu", name: "Thursday" },
  { day: 5, short: "Fri", name: "Friday" },
  { day: 6, short: "Sat", name: "Saturday" },
  { day: 7, short: "Sun", name: "Sunday" },
];

const scheduleKey = (preferences: AvailabilityPreferences) =>
  JSON.stringify([
    [...preferences.daysOfWeek].sort((a, b) => a - b),
    preferences.startTime,
    preferences.endTime,
    preferences.timezone,
  ]);

export function appointmentSummary(preferences: AvailabilityPreferences) {
  const days = weekdays
    .filter(({ day }) => preferences.daysOfWeek.includes(day))
    .map(({ short }) => short);
  const dayLabel =
    days.join(",") === "Mon,Tue,Wed,Thu,Fri"
      ? "Mon to Fri"
      : days.length === 7
        ? "Every day"
        : days.join(", ");
  return `${dayLabel} · ${preferences.startTime} to ${preferences.endTime} · ${preferences.timezone}`;
}

export function AppointmentPreferences({
  saved,
  busy,
  onSave,
}: {
  saved: AvailabilityPreferences;
  busy: boolean;
  onSave: (preferences: AvailabilityPreferences) => Promise<boolean>;
}) {
  const [draft, setDraft] = useState(saved);
  const [error, setError] = useState<{
    field: "days" | "time" | "save";
    message: string;
  }>();
  const [savedNotice, setSavedNotice] = useState(false);
  const previousSaved = useRef(saved);
  const savedKey = scheduleKey(saved);
  const changed = scheduleKey(draft) !== savedKey;

  useEffect(() => {
    const previous = previousSaved.current;
    previousSaved.current = saved;
    setDraft((current) =>
      scheduleKey(current) === scheduleKey(previous) ? saved : current,
    );
  }, [saved]);

  function edit(next: AvailabilityPreferences) {
    setDraft(next);
    setError(undefined);
    setSavedNotice(false);
  }

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSavedNotice(false);
    if (!draft.daysOfWeek.length) {
      setError({
        field: "days",
        message: "Choose at least one appointment day.",
      });
      return;
    }
    const parsed = AvailabilityPreferencesSchema.safeParse(draft);
    if (!parsed.success) {
      setError({
        field: "time",
        message:
          "Choose a start and end time at least one hour apart within the same day.",
      });
      return;
    }
    setError(undefined);
    if (await onSave(parsed.data)) setSavedNotice(true);
    else
      setError({
        field: "save",
        message:
          "Appointment preferences could not be saved. Your draft is kept. Check the connection and try again.",
      });
  }

  return (
    <form className="appointment-preferences" onSubmit={submit} noValidate>
      <h3 id="appointment-preferences-title">Appointment preferences</h3>
      <p className="schedule-saved">
        <span>Currently saved</span>
        <strong>{appointmentSummary(saved)}</strong>
      </p>
      <fieldset disabled={busy} aria-labelledby="appointment-preferences-title">
        <fieldset
          className="appointment-days"
          aria-describedby={
            error?.field === "days" ? "appointment-error" : undefined
          }
          aria-invalid={error?.field === "days" || undefined}
        >
          <legend>Days you can welcome a provider</legend>
          <div className="appointment-day-options">
            {weekdays.map(({ day, short, name }) => (
              <label key={day}>
                <input
                  type="checkbox"
                  aria-label={name}
                  checked={draft.daysOfWeek.includes(day)}
                  onChange={(event) =>
                    edit({
                      ...draft,
                      daysOfWeek: event.target.checked
                        ? [...new Set([...draft.daysOfWeek, day])].sort(
                            (a, b) => a - b,
                          )
                        : draft.daysOfWeek.filter((value) => value !== day),
                    })
                  }
                />
                <span>{short}</span>
              </label>
            ))}
          </div>
        </fieldset>
        <div className="appointment-times">
          <label>
            From
            <input
              type="time"
              value={draft.startTime}
              required
              step="60"
              aria-invalid={error?.field === "time" || undefined}
              aria-describedby="appointment-time-hint appointment-error"
              onChange={(event) =>
                edit({ ...draft, startTime: event.target.value })
              }
            />
          </label>
          <label>
            Until
            <input
              type="time"
              value={draft.endTime}
              required
              step="60"
              aria-invalid={error?.field === "time" || undefined}
              aria-describedby="appointment-time-hint appointment-error"
              onChange={(event) =>
                edit({ ...draft, endTime: event.target.value })
              }
            />
          </label>
        </div>
        <p id="appointment-time-hint" className="appointment-hint">
          Asia/Kolkata · At least one hour, within the same day.
        </p>
        <p className="appointment-impact">
          Applies to unbooked work. Pending approvals need a fresh review.
          Existing bookings stay as arranged. Urgent visits also respect these
          hours and may wait until the next allowed window.
        </p>
        <div id="appointment-error">
          {error && (
            <p className="appointment-error" role="alert">
              {error.message}
            </p>
          )}
        </div>
        {savedNotice && (
          <p className="appointment-success" role="status">
            Appointment preferences saved.
          </p>
        )}
        <button className="primary-button" disabled={busy || !changed}>
          {busy ? "Saving…" : "Save appointment preferences"}
        </button>
      </fieldset>
    </form>
  );
}
