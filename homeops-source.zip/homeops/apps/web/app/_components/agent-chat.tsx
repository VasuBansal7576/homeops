"use client";

import type { UserContent } from "ai";
import { useEveAgent } from "eve/react";
import { AlertCircleIcon, ArrowUpIcon, BrainIcon, PlusIcon, ShieldCheckIcon, SparklesIcon, SquareIcon } from "lucide-react";
import { useRef, useState } from "react";
import {
  Conversation,
  ConversationContent,
  ConversationScrollButton,
  ConversationTopFade,
} from "@/components/ai-elements/conversation";
import { Message, MessageContent } from "@/components/ai-elements/message";
import {
  PromptInput,
  PromptInputButton,
  type PromptInputMessage,
  PromptInputSubmit,
  PromptInputTextarea,
  PromptInputProvider,
  usePromptInputController,
  usePromptInputAttachments,
} from "@/components/ai-elements/prompt-input";
import { Shimmer } from "@/components/ai-elements/shimmer";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { AgentMessage, ApprovalRequest } from "./agent-message";
import { WEB_CHAT_AGENT } from "@/app/eve-agent";
import { AssistantSpeech, VoiceInput, useVoiceCapability, type VoiceCapability } from "./voice-controls";

const DEFAULT_AGENT_NAME = "HomeOps";
const AGENT_NAME = WEB_CHAT_AGENT ?? DEFAULT_AGENT_NAME;

export function AgentChat({
  sessionId,
  sessionless = false,
  embedded = false,
  csrf,
  onSession,
}: {
  readonly sessionId?: string;
  readonly sessionless?: boolean;
  readonly embedded?: boolean;
  readonly csrf?: string;
  readonly onSession?: (sessionId: string) => void;
}) {
  const [cancellationError, setCancellationError] = useState<string>();
  const [hasInputText, setHasInputText] = useState(false);
  const [voiceBusy, setVoiceBusy] = useState(false);
  const stopSpeech = useRef<(() => void) | null>(null);
  const { capability, error: capabilityError } = useVoiceCapability();
  const hasSubmittedMessage = useRef(false);
  const replaceSessionRoute = (nextSessionId: string) => {
    if (embedded) return;
    if (sessionId !== undefined) return;
    // Framework routers (Next.js, TanStack Router) patch window.history; navigating
    // through them would remount this route and detach the active stream.
    History.prototype.replaceState.call(
      window.history,
      window.history.state,
      "",
      `/s/${encodeURIComponent(nextSessionId)}`,
    );
  };
  const agent = useEveAgent({
    agent: WEB_CHAT_AGENT,
    headers: csrf ? { "x-homeops-csrf": csrf } : undefined,
    prewarm: false,
    initialSession:
      sessionId === undefined
        ? undefined
        : {
            sessionId,
            streamIndex: 0,
          },
    resume: sessionId !== undefined,
    onSessionChange(session) {
      if (session) onSession?.(session.sessionId);
      if (hasSubmittedMessage.current && session !== undefined) {
        replaceSessionRoute(session.sessionId);
      }
    },
  });

  const isBusy = agent.status === "submitted" || agent.status === "streaming";
  const isResuming = agent.status === "resuming";
  const isEmpty = agent.data.messages.length === 0;
  const lastAssistant = agent.data.messages.toReversed().find((message) =>
    message.role === "assistant" && message.parts.some((part) => part.type === "text" && part.text.trim()),
  );
  const lastAssistantText = isBusy || isResuming ? "" : lastAssistant?.parts
    .flatMap((part) => part.type === "text" ? [part.text] : []).join("\n\n") ?? "";
  const pendingApprovals = Object.values(agent.data.inputs).filter((input) =>
    input.status === "open" && input.request.kind === "tool-approval",
  ).map((input) => input.request);
  const pendingApproval = pendingApprovals[0];
  const spokenText = pendingApproval?.prompt ?? lastAssistantText;
  const spokenId = pendingApproval ? `approval:${pendingApproval.requestId}` : lastAssistantText ? lastAssistant?.id : undefined;
  const lastMessage = agent.data.messages.at(-1);
  const isPendingAssistantShell =
    lastMessage?.role === "assistant" &&
    lastMessage.parts.every((part) => part.type === "step-start");
  const showPendingThinking =
    isBusy &&
    (agent.status === "submitted" ||
      lastMessage?.role !== "assistant" ||
      isPendingAssistantShell);
  const turnFailure =
    isBusy || isResuming ? undefined : getLatestTurnFailure(agent.events);
  const errorMessage = cancellationError ?? agent.error?.message ?? turnFailure;
  const hasConversationContent =
    sessionless || !isEmpty || errorMessage !== undefined;
  const showConversationLayout = isResuming || hasConversationContent;
  const activeSessionId = sessionId ?? agent.session?.sessionId;
  // Answers are accepted while work runs; the server's settlement closes each request.
  const canRespond = (requestId: string) =>
    !isResuming && agent.data.inputs[requestId]?.status === "open";
  // A tool call can ask several questions at once, and its message part holds only the latest.
  const questionsFor = (callId: string) =>
    Object.values(agent.data.inputs).filter(
      (input) =>
        input.request.kind === "question" &&
        input.request.action.callId === callId,
    );

  const requestCancellation = () => {
    setCancellationError(undefined);
    void agent.cancel().catch((error: unknown) => {
      setCancellationError(toErrorMessage(error));
    });
  };

  const handleSubmit = async (message: PromptInputMessage) => {
    const text = message.text.trim();
    if ((text.length === 0 && message.files.length === 0) || isResuming || voiceBusy) return;

    setHasInputText(false);
    setCancellationError(undefined);
    hasSubmittedMessage.current = true;
    if (agent.session !== undefined)
      replaceSessionRoute(agent.session.sessionId);
    const options = isBusy ? { turnPolicy: "steer" as const } : undefined;

    if (message.files.length === 0) {
      await agent.send(text, options);
      return;
    }

    const parts: UserContent = [];
    if (text.length > 0) {
      parts.push({ text, type: "text" });
    }
    for (const file of message.files) {
      parts.push({
        data: file.url,
        filename: file.filename,
        mediaType: file.mediaType,
        type: "file",
      });
    }

    await agent.send(parts, options);
  };

  const composer = (
    <PromptInputProvider>
      <div className="composer-inputs">
      <VoiceComposer csrf={csrf} capability={capability} capabilityError={capabilityError}
        disabled={isResuming || isBusy} onDraftChange={setHasInputText} onBusyChange={setVoiceBusy}
        onBeforeCapture={() => stopSpeech.current?.()} />
      <div className="message-composer"><PromptInput className="message-field" onSubmit={handleSubmit}>
        <PromptInputTextarea
          aria-label="Message HomeOps"
          disabled={isResuming}
          onChange={(event) => setHasInputText(event.currentTarget.value.trim().length > 0)}
          placeholder="What can I take off your mind?"
        />
        <ComposerAction
          hasInputText={hasInputText}
          isBusy={isBusy}
          isResuming={isResuming || voiceBusy}
          onCancel={requestCancellation}
        />
      </PromptInput></div>
      </div>
    </PromptInputProvider>
  );

  return (
    <div
      className={cn(
        "flex flex-col overflow-hidden bg-background text-foreground",
        embedded ? "embedded-chat min-h-0 flex-1" : "h-dvh",
      )}
    >
      {showConversationLayout && !embedded ? (
        <ChatHeader canStartNewChat={activeSessionId !== undefined} />
      ) : null}

      {showConversationLayout ? (
        <Conversation
          className="min-h-0 flex-1"
          initial={sessionId === undefined ? undefined : false}
          resize={activeSessionId === undefined ? "smooth" : "instant"}
          scrollRestorationKey={
            isEmpty || activeSessionId === undefined
              ? undefined
              : `eve:web-chat-scroll:${activeSessionId}`
          }
        >
          {!embedded && <ConversationTopFade className="top-14" />}
          <ConversationContent
            className={cn(
              "mx-auto w-full max-w-3xl gap-6 px-4 sm:px-6",
              embedded ? "pt-5 pb-6" : "pt-20 pb-36",
            )}
          >
            {agent.data.messages.map((message, index) =>
              showPendingThinking &&
              isPendingAssistantShell &&
              message.id === lastMessage.id ? null : (
                <AgentMessage
                  canRespond={canRespond}
                  dockedApprovalIds={pendingApprovals.map((request) => request.requestId)}
                  isStreaming={
                    agent.status === "streaming" &&
                    index === agent.data.messages.length - 1
                  }
                  key={message.id}
                  message={message}
                  questionsFor={questionsFor}
                  onInputResponses={(inputResponses) => {
                    setCancellationError(undefined);
                    return agent.respond(inputResponses);
                  }}
                />
              ),
            )}
            {showPendingThinking ? <PendingThinking /> : null}
            {errorMessage ? <ErrorMessage message={errorMessage} /> : null}
          </ConversationContent>
          <ConversationScrollButton />
        </Conversation>
      ) : null}

      {!showConversationLayout && (
        <div className="assistant-welcome voice-welcome">
          <span className="welcome-emblem" aria-hidden="true"><SparklesIcon size={29} strokeWidth={1.25} /></span>
          <p className="eyebrow">YOUR HOME, THOUGHTFULLY LOOKED AFTER</p>
          <h1>A home that<br /><em>remembers.</em></h1>
          <p>Tell me what needs a little care.<br />I’ll remember the details and help with what’s next.</p>
          <span className="welcome-assurance"><ShieldCheckIcon size={15} /> Nothing arranged without your say.</span>
        </div>
      )}
      {pendingApprovals.length > 0 && (
        <div className="approval-dock" aria-label="Service approval required">
          {pendingApprovals.map((request) => (
            <ApprovalRequest key={request.requestId} inputRequest={request} canRespond={canRespond(request.requestId)}
              onInputResponses={(responses) => { setCancellationError(undefined); return agent.respond(responses); }} />
          ))}
        </div>
      )}
      <div className={cn("chat-composer-row", embedded ? "embedded-composer" : "standalone-composer")}>
        <details className="speech-disclosure">
          <summary>Listen to {pendingApproval ? "the approval request" : "the latest reply"}</summary>
          <AssistantSpeech text={spokenText} messageId={spokenId} sourceKind={pendingApproval ? "approval" : "reply"}
            csrf={csrf} capability={capability} disabled={(isBusy && !pendingApproval) || isResuming || voiceBusy} stopRef={stopSpeech} />
        </details>
        {composer}
      </div>
    </div>
  );
}

function VoiceComposer({ csrf, capability, capabilityError, disabled, onDraftChange, onBusyChange, onBeforeCapture }: {
  csrf?: string;
  capability?: VoiceCapability;
  capabilityError?: string;
  disabled: boolean;
  onDraftChange: (hasText: boolean) => void;
  onBusyChange: (busy: boolean) => void;
  onBeforeCapture: () => void;
}) {
  const controller = usePromptInputController();
  const container = useRef<HTMLDivElement>(null);
  return <div className="voice-composer" ref={container}>
    <VoiceInput csrf={csrf} capability={capability} capabilityError={capabilityError}
      disabled={disabled} onBusyChange={onBusyChange} onBeforeCapture={onBeforeCapture} onTranscript={(text) => {
        const previous = controller.textInput.value.trim();
        controller.textInput.setInput(previous ? `${previous}\n${text}` : text);
        onDraftChange(true);
        container.current?.parentElement?.querySelector("textarea")?.focus();
      }} />
  </div>;
}

function ComposerAction({
  hasInputText,
  isBusy,
  isResuming,
  onCancel,
}: {
  readonly hasInputText: boolean;
  readonly isBusy: boolean;
  readonly isResuming: boolean;
  readonly onCancel: () => void;
}) {
  const attachments = usePromptInputAttachments();
  const canSubmit = hasInputText || attachments.files.length > 0;

  if (!isBusy || canSubmit) {
    return <PromptInputSubmit className="composer-send" aria-label="Send message" disabled={isResuming || !canSubmit}><span>Send</span><ArrowUpIcon size={18} /></PromptInputSubmit>;
  }

  return (
    <PromptInputButton
      aria-label="Stop"
      className="absolute right-2.5 bottom-2.5"
      onClick={onCancel}
      variant="outline"
    >
      <SquareIcon className="size-3 fill-current" />
    </PromptInputButton>
  );
}

function ErrorMessage({ message }: { readonly message: string }) {
  return (
    <Message className="max-w-full" from="assistant">
      <MessageContent>
        <div
          className="flex w-full items-start gap-3 rounded-lg border border-destructive/30 bg-destructive/5 px-3 py-2.5 text-sm"
          role="alert"
        >
          <AlertCircleIcon className="mt-0.5 size-4 shrink-0 text-destructive" />
          <div>
            <p className="font-medium">Request failed</p>
            <p className="mt-0.5 text-muted-foreground">{message}</p>
          </div>
        </div>
      </MessageContent>
    </Message>
  );
}

function ChatHeader({
  canStartNewChat,
}: {
  readonly canStartNewChat: boolean;
}) {
  return (
    <header className="pointer-events-none fixed top-0 right-0 left-0 z-20 h-14">
      <div className="relative mx-auto flex h-full w-full max-w-3xl items-center justify-center bg-background px-24">
        <span className="truncate text-muted-foreground text-sm">
          {AGENT_NAME}
        </span>
        {canStartNewChat ? (
          <Button
            aria-label="Start a new chat"
            className="pointer-events-auto fixed top-3 right-6 pr-4"
            onClick={() => window.location.assign("/s")}
            size="sm"
            type="button"
            variant="ghost"
          >
            <PlusIcon className="size-4" />
            <span className="hidden font-normal text-sm sm:inline">
              New chat
            </span>
          </Button>
        ) : null}
      </div>
    </header>
  );
}

function PendingThinking() {
  return (
    <Message aria-live="polite" from="assistant">
      <MessageContent>
        <div className="mb-4 flex w-full items-center gap-2 text-muted-foreground text-sm">
          <BrainIcon className="size-4" />
          <Shimmer duration={1}>Thinking</Shimmer>
        </div>
      </MessageContent>
    </Message>
  );
}

function toErrorMessage(error: unknown): string {
  return error instanceof Error
    ? error.message
    : "Unable to cancel the response.";
}

function getLatestTurnFailure(
  events: ReturnType<typeof useEveAgent>["events"],
): string | undefined {
  for (let index = events.length - 1; index >= 0; index -= 1) {
    const event = events[index];

    if (event.type === "turn.failed") {
      return event.data.code === "MODEL_CALL_FAILED"
        ? "The model is temporarily unavailable. Please try again."
        : event.data.message;
    }

    if (event.type === "turn.completed" || event.type === "turn.cancelled") {
      return undefined;
    }

    if (event.type === "message.received") {
      return undefined;
    }
  }

  return undefined;
}
