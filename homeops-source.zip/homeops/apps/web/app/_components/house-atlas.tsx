import type { HouseholdSnapshot } from "../../../../packages/contracts/src/index";
import "./house-atlas.css";

const positions = {
  ac: { x: 397, y: 161 },
  sink: { x: 585, y: 232 },
  purifier: { x: 641, y: 297 },
  washer: { x: 432, y: 374 },
  garden: { x: 198, y: 332 },
  other: { x: 339, y: 269 },
};

export function HouseAtlas({ snapshot, selectedApplianceId, onSelectAppliance, compact = false }: {
  snapshot: HouseholdSnapshot;
  selectedApplianceId?: string;
  onSelectAppliance: (id: string) => void;
  compact?: boolean;
}) {
  return <section className={`house-atlas ${compact ? "house-atlas-compact" : ""}`} aria-label="Household appliance atlas">
    <div className="atlas-map-label"><span>HOUSE ATLAS / 01</span><span>SELECT AN APPLIANCE</span></div>
            <svg className="atlas-house-drawing" viewBox="0 0 820 550" role="group" aria-label="Illustrated conceptual house. Select a labeled appliance to read its real record.">
              <defs>
                <pattern id="atlas-grid" width="32" height="16" patternUnits="userSpaceOnUse"><path d="M0 8 16 0 32 8 16 16Z" fill="none" stroke="#d8d9d3" strokeWidth=".45"/></pattern>
                <pattern id="atlas-wood" width="38" height="18" patternUnits="userSpaceOnUse" patternTransform="rotate(-28)"><path d="M0 0H38M0 18H38M19 0V18" fill="none" stroke="#cecabd" strokeWidth=".7"/></pattern>
                <linearGradient id="atlas-wall" x1="0" x2="1"><stop stopColor="#f8f7f1"/><stop offset="1" stopColor="#e4e4da"/></linearGradient>
                <filter id="atlas-shadow" x="-20%" y="-20%" width="140%" height="160%"><feGaussianBlur stdDeviation="12"/></filter>
              </defs>
              <path d="M47 365 427 146 791 335 413 548Z" fill="#d7d7cb" opacity=".35" filter="url(#atlas-shadow)"/>
              <rect x="20" y="30" width="780" height="485" fill="url(#atlas-grid)" opacity=".48"/>
              <path d="M81 310 414 112 754 284 418 488Z" fill="#d0cec1" stroke="#26352f" strokeWidth="1.2"/>
              <path d="M81 310v15l337 178v-15Zm337 178 336-204v15L418 503Z" fill="#b4b7a8" stroke="#72776c" strokeWidth=".7"/>
              <path d="m81 310 333-198 340 172-336 204Z" fill="#f0eee5"/>
              <path d="m81 310 333-198 340 172-336 204Z" fill="url(#atlas-wood)"/>
              <path d="m81 310 99-59 174 88-102 61Z" fill="#b6c2a0"/>
              <path d="m441 324 155-95 158 55-162 101Z" fill="#d6e0dd"/>
              <path d="m441 324 151 61-174 103-148-79Z" fill="#e2e4d9"/>
              <g stroke="#b9c4bd" strokeWidth=".6" fill="none"><path d="m465 337 155-96m-128 109 155-96m-128 109 155-96m-128 109 155-96M471 305l155 63m-128-80 155 63"/></g>
              <path d="M81 310V207L414 10v102Z" fill="url(#atlas-wall)" stroke="#899181" strokeWidth="1"/>
              <path d="M414 10 754 182v102L414 112Z" fill="#e1e3d8" stroke="#899181" strokeWidth="1"/>
              <path d="m81 207 333-197 340 172-9 6-331-166L91 213Z" fill="#fffef8" stroke="#899181" strokeWidth=".8"/>
              <path d="m454 61 120 60v53l-120-61Z" fill="#8baeb3" stroke="#678888" strokeWidth="2"/>
              <path d="m514 92 1 53m-61-58 120 60" stroke="#edf4ed" strokeWidth="3"/>
              <path d="m159 184 108-64v51l-108 64Z" fill="#adc4c2" stroke="#8b9c90" strokeWidth="2"/>
              <path d="m213 152 1 50m-55 8 108-64" stroke="#f7f8f1" strokeWidth="3"/>
              <path d="m298 88 98-58v24l-98 58Z" fill="#fff" stroke="#9ba196"/>
              <path d="m307 101 80-48m-76 40 73-44" stroke="#abb0a6" strokeWidth="2"/>
              <path d="m470 173 193 98 41-25-193-97Z" fill="#354a43" stroke="#263c33"/>
              <path d="m470 173 193 98v36l-193-99Z" fill="#a9b5aa" stroke="#7c9081"/>
              <path d="m663 271 41-25v36l-41 25Z" fill="#8c9e92"/>
              <path d="m548 196 43 22-23 14-43-22Z" fill="#d6ddcf" stroke="#f1f3e9" strokeWidth="3"/>
              <path d="m556 214v-16q0-20 13-12v14" fill="none" stroke="#b9c8bf" strokeWidth="4" strokeLinecap="round"/>
              <path d="m603 222 34 18-18 11-35-18Z" fill="#142d25" stroke="#a4b0a7"/>
              <ellipse cx="610" cy="237" rx="9" ry="4" fill="none" stroke="#93a397"/>
              <path d="m644 252 18 9v-32l-18-9Z" fill="#eaf0e4" stroke="#879a8c"/>
              <path d="m644 220 18 9 16-9-19-9Z" fill="#c0d0bf"/>
              <path d="m662 229 16-9v32l-16 9Z" fill="#c1d1c7"/>
              <path d="m211 248 94-57 71 36-95 58Z" fill="#adc0c7" stroke="#385759" strokeWidth="1.5"/>
              <path d="m211 248 70 37v38l-70-36Z" fill="#5e8388" stroke="#385759"/>
              <path d="m281 285 95-58v38l-95 58Z" fill="#73979b" stroke="#385759"/>
              <path d="m218 236 86-53 5 8-88 53Z" fill="#c5d4d6" stroke="#52767a"/>
              <path d="m215 253 31 16 5-16-30-16Zm42 23 27 14 9-18-29-14Z" fill="#b7cbcc" stroke="#52767a"/>
              <path d="m309 244 32-19 25 13-31 19Z" fill="#c5d7d5" stroke="#52767a"/>
              <path d="m288 329 66-40 49 25-66 41Z" fill="#d9ac80" stroke="#9e7859"/>
              <path d="m288 329 49 26v9l-49-26Zm49 26 66-41v9l-66 41Z" fill="#ab825d"/>
              <path d="m311 324 23-14 18 9-24 14Z" fill="#f7f7ed"/>
              <ellipse cx="367" cy="319" rx="10" ry="5" fill="#3a5040"/>
              <path d="m386 378 46-27 47 24-46 29Z" fill="#f7f8f1" stroke="#7d8f86"/>
              <path d="m386 378 47 26v49l-47-25Z" fill="#e1e6de" stroke="#7d8f86"/>
              <path d="m433 404 46-29v49l-46 29Z" fill="#b7c7c0" stroke="#7d8f86"/>
              <ellipse cx="455" cy="416" rx="12" ry="17" fill="#42645e" transform="rotate(24 455 416)"/>
              <ellipse cx="455" cy="416" rx="8" ry="12" fill="#93b2ac" transform="rotate(24 455 416)"/>
              <path d="m440 394 26-16" stroke="#788f85" strokeWidth="3"/>
              <path d="m160 326 54-33 45 23-55 34Z" fill="#f2e0c1" stroke="#698367"/>
              <path d="m160 326 44 24v21l-44-24Zm44 24 55-34v21l-55 34Z" fill="#b6946d" stroke="#698367"/>
              <g fill="#678a58" stroke="#456742" strokeWidth="1"><path d="M192 327c-25-7-33-29-14-26 13 2 14 26 14 26Z"/><path d="M192 327c3-29 25-48 30-28 3 14-30 28-30 28Z"/><path d="M192 327c-12-28-8-48 6-38 11 9-6 38-6 38Z"/><path d="M221 330c-1-32 23-45 22-23-1 11-22 23-22 23Z"/><path d="M221 330c-30-12-33-31-17-25 10 3 17 25 17 25Z"/></g>
              <path d="m604 391 54-33 12 6-55 34Z" fill="#d5b180"/><path d="m616 400 54-33 12 6-55 34Z" fill="#d5b180"/>
              <path d="m316 416 103 54 64-39" fill="none" stroke="#b6b6a4" strokeWidth="1" strokeDasharray="4 5"/>
              <text x="97" y="467" fill="#7d8277" fontSize="11" letterSpacing="2">SCHEMATIC / NOT A FLOOR PLAN</text>
              <path d="M714 442v-38m0 0-5 9m5-9 5 9" stroke="#5a685a" strokeWidth="1.3"/><text x="710" y="458" fontSize="12" fill="#5a685a">N</text>
              {snapshot.appliances.map((appliance, index) => {
                const p = positions[appliance.kind];
                const sameKindIndex = snapshot.appliances.slice(0, index).filter(item => item.kind === appliance.kind).length;
                const x = p.x + (sameKindIndex % 3) * 13;
                const y = p.y + (sameKindIndex % 3) * 20;
                const selected = selectedApplianceId === appliance.id;
                const incident = snapshot.cases.some(item => item.applianceId === appliance.id && !['completed', 'cancelled', 'denied'].includes(item.state));
                const activate = () => { onSelectAppliance(appliance.id); };
                return <g key={appliance.id} className={`atlas-pin ${selected ? 'is-selected' : ''}`} data-appliance-id={appliance.id} role="button" tabIndex={0} aria-pressed={selected} aria-label={`Select ${appliance.name}, ${appliance.location}${incident ? ', open case' : ''}`} onClick={activate} onKeyDown={event => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); activate(); } }} transform={`translate(${x} ${y})`}>
                  <path d="M0 0v28" stroke="currentColor" strokeWidth="1.5"/><ellipse cy="28" rx="7" ry="3" fill="currentColor" opacity=".25"/><circle r="15" fill="currentColor" stroke="#f9f8f2" strokeWidth="3"/><path d="M-5 0H5M0-5V5" stroke="#fff" strokeWidth="1.8"/>
                  <g className="atlas-pin-label"><rect x="20" y="-15" rx="3" width={Math.max(96, Math.min(appliance.name.length * 6.5 + 25, 200))} height="29"/><text x="31" y="4">{appliance.name.length > 25 ? `${appliance.name.slice(0, 24)}…` : appliance.name}{incident ? ' ·' : ''}</text></g>
                </g>;
              })}
            </svg>
    <div className="atlas-map-caption"><span>Conceptual arrangement · not your floor plan</span><span>Saved household records</span></div>
    <div className="atlas-asset-list" aria-label="All household appliances">
      {snapshot.appliances.map(appliance => <button key={appliance.id} type="button" aria-pressed={selectedApplianceId === appliance.id} onClick={() => onSelectAppliance(appliance.id)}><span>{appliance.name}</span><small>{appliance.location}</small><span aria-hidden="true">↗</span></button>)}
      {snapshot.appliances.length === 0 && <p>No appliances recorded. Add them in Household.</p>}
    </div>
  </section>;
}
