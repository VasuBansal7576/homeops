import {
  useEffect,
  useId,
  useRef,
  useState,
  type FormEvent,
  type ReactNode,
} from "react";
import {
  DEFAULT_AVAILABILITY_PREFERENCES,
  HouseholdDatasetSchema,
  PublicCommandSchema,
  type ApplianceInput,
  type ApplianceKind,
  type AvailabilityPreferences,
  type CaseCard,
  type HouseholdDataset,
  type HouseholdSnapshot,
  type ProviderInput,
  type PublicCommand,
} from "../../../../packages/contracts/src/index";
import "./household-data.css";

type CommandProps = {
  onCommand: (command: PublicCommand) => Promise<boolean>;
  busy: boolean;
};
const kinds: { value: ApplianceKind; label: string }[] = [
  { value: "ac", label: "Air conditioner" },
  { value: "purifier", label: "Water purifier" },
  { value: "washer", label: "Washing machine" },
  { value: "garden", label: "Garden" },
  { value: "sink", label: "Sink" },
  { value: "other", label: "Other" },
];
const days = [
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
  "Sunday",
];
const newId = (prefix: string) => `${prefix}-${crypto.randomUUID()}`;

function rupees(value: string) {
  const text = value.trim();
  if (!/^\d+(\.\d{1,2})?$/.test(text))
    throw new Error("Enter an INR amount with at most two decimal places.");
  const [whole, fraction = ""] = text.split(".");
  const minor = BigInt(whole) * 100n + BigInt(fraction.padEnd(2, "0"));
  if (minor > BigInt(Number.MAX_SAFE_INTEGER))
    throw new Error("This INR amount is too large.");
  return { minor: Number(minor), currency: "INR" as const };
}
const major = (minor: number) =>
  `${Math.floor(minor / 100)}.${String(minor % 100).padStart(2, "0")}`;
function integer(value: string, name: string) {
  if (!/^\d+$/.test(value)) throw new Error(`${name} must be a whole number.`);
  return Number(value);
}
function validationMessage(error: {
  issues: { path: PropertyKey[]; message: string }[];
}) {
  return error.issues
    .map(
      (issue) =>
        `${issue.path.map(String).join(" / ") || "Household"}: ${issue.message}`,
    )
    .join(" ");
}
function Field({
  label,
  children,
  hint,
}: {
  label: string;
  children: ReactNode;
  hint?: string;
}) {
  return (
    <label className="hd-field">
      <span>{label}</span>
      {children}
      {hint && <small>{hint}</small>}
    </label>
  );
}
function KindSelect({
  value,
  onChange,
}: {
  value: ApplianceKind;
  onChange: (value: ApplianceKind) => void;
}) {
  return (
    <select
      value={value}
      onChange={(event) => onChange(event.target.value as ApplianceKind)}
    >
      {kinds.map((kind) => (
        <option key={kind.value} value={kind.value}>
          {kind.label}
        </option>
      ))}
    </select>
  );
}
function Feedback({ error, notice }: { error: string; notice: string }) {
  return (
    <div className="hd-feedback" aria-live="polite">
      {error && (
        <p className="hd-error" role="alert">
          {error}
        </p>
      )}
      {notice && (
        <p className="hd-notice" role="status">
          {notice}
        </p>
      )}
    </div>
  );
}
function useSubmission() {
  const locked = useRef(false);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  async function run(action: () => Promise<boolean>, success: string) {
    if (locked.current) return false;
    locked.current = true;
    setError("");
    setNotice("");
    setPending(true);
    try {
      if (!(await action()))
        throw new Error(
          "Could not save. Your draft is kept. Check the connection, review any server message and try again.",
        );
      setNotice(success);
      return true;
    } catch (reason) {
      setError(
        reason instanceof Error
          ? reason.message
          : "Could not save. Your draft is kept. Try again.",
      );
      return false;
    } finally {
      locked.current = false;
      setPending(false);
    }
  }
  return { pending, error, notice, run, setError, setNotice };
}
function useRecordDraft<T>(saved: T, revision: number | null) {
  const [state, setState] = useState({
    draft: saved,
    baseline: saved,
    revision,
    awaitingRefresh: false,
  });
  const savedKey = JSON.stringify(saved);
  const baselineKey = JSON.stringify(state.baseline);
  useEffect(() => {
    setState((current) => {
      if (current.awaitingRefresh && current.revision === revision)
        return current;
      return JSON.stringify(current.draft) === JSON.stringify(current.baseline)
        ? { draft: saved, baseline: saved, revision, awaitingRefresh: false }
        : current;
    });
  }, [savedKey, revision, baselineKey, state.awaitingRefresh]);
  return {
    draft: state.draft,
    revision: state.revision,
    stale: state.revision !== revision,
    edit: (next: T) => setState((current) => ({ ...current, draft: next })),
    reload: () =>
      setState({
        draft: saved,
        baseline: saved,
        revision,
        awaitingRefresh: false,
      }),
    saved: () =>
      setState((current) => ({
        ...current,
        baseline: current.draft,
        awaitingRefresh: true,
      })),
  };
}
async function submitCommand(
  onCommand: CommandProps["onCommand"],
  value: unknown,
) {
  const parsed = PublicCommandSchema.safeParse(value);
  if (!parsed.success) throw new Error(validationMessage(parsed.error));
  return onCommand(parsed.data);
}
function RevisionNotice({
  stale,
  onReload,
}: {
  stale: boolean;
  onReload: () => void;
}) {
  return stale ? (
    <p className="hd-revision" role="status">
      The saved record changed while you were editing. Your draft is kept.{" "}
      <button type="button" className="hd-link" onClick={onReload}>
        Load saved values
      </button>
    </p>
  ) : null;
}

function AvailabilityFields({
  value,
  onChange,
}: {
  value: AvailabilityPreferences;
  onChange: (value: AvailabilityPreferences) => void;
}) {
  return (
    <fieldset className="hd-availability">
      <legend>When can a provider visit?</legend>
      <div className="hd-days">
        {days.map((day, index) => (
          <label key={day}>
            <input
              type="checkbox"
              checked={value.daysOfWeek.includes(index + 1)}
              onChange={(event) =>
                onChange({
                  ...value,
                  daysOfWeek: event.target.checked
                    ? [...value.daysOfWeek, index + 1].sort((a, b) => a - b)
                    : value.daysOfWeek.filter((item) => item !== index + 1),
                })
              }
            />
            <span>{day.slice(0, 3)}</span>
            <span className="hd-sr-only">{day.slice(3)}</span>
          </label>
        ))}
      </div>
      <div className="hd-grid">
        <Field label="Available from">
          <input
            type="time"
            value={value.startTime}
            onChange={(event) =>
              onChange({ ...value, startTime: event.target.value })
            }
          />
        </Field>
        <Field label="Available until">
          <input
            type="time"
            value={value.endTime}
            onChange={(event) =>
              onChange({ ...value, endTime: event.target.value })
            }
          />
        </Field>
      </div>
      <p className="hd-hint">
        Asia/Kolkata. Allow at least one hour in the same day.
      </p>
    </fieldset>
  );
}

export function HouseholdSetup({
  onInitialize,
  busy,
}: {
  onInitialize: (dataset: HouseholdDataset) => Promise<boolean>;
  busy: boolean;
}) {
  const [mode, setMode] = useState<"choose" | "demo" | "personal" | "import">(
    "choose",
  );
  const [catalog, setCatalog] = useState<
    {
      id: string;
      name: string;
      description: string;
      dataset: HouseholdDataset;
    }[]
  >([]);
  const [loading, setLoading] = useState(false);
  const [catalogError, setCatalogError] = useState("");
  const [selected, setSelected] = useState("");
  const [name, setName] = useState("");
  const [budget, setBudget] = useState("");
  const [availability, setAvailability] = useState(
    DEFAULT_AVAILABILITY_PREFERENCES,
  );
  const [importText, setImportText] = useState("");
  const [imported, setImported] = useState<HouseholdDataset | null>(null);
  const submission = useSubmission();
  const disabled = busy || submission.pending || loading;
  const catalogGroup = useId();
  async function loadCatalog() {
    setMode("demo");
    setLoading(true);
    setCatalogError("");
    try {
      const response = await fetch("/api/homeops/datasets", {
        credentials: "same-origin",
      });
      if (!response.ok)
        throw new Error("The demo catalog could not be loaded. Try again.");
      const body: unknown = await response.json();
      if (
        !body ||
        typeof body !== "object" ||
        !("datasets" in body) ||
        !Array.isArray(body.datasets)
      )
        throw new Error("The demo catalog has an unexpected format.");
      const next = body.datasets.map((entry: unknown) => {
        if (!entry || typeof entry !== "object" || !("dataset" in entry))
          throw new Error("The demo catalog contains an invalid entry.");
        const parsed = HouseholdDatasetSchema.safeParse(entry.dataset);
        if (!parsed.success || parsed.data.metadata.kind !== "synthetic")
          throw new Error("The demo catalog contains an invalid dataset.");
        return {
          id: parsed.data.metadata.id,
          name: parsed.data.metadata.name,
          description: parsed.data.metadata.description,
          dataset: parsed.data,
        };
      });
      setCatalog(next);
      if (!next.length)
        setCatalogError(
          "There are no demo datasets available yet. You can still set up a personal household or import a dataset.",
        );
    } catch (reason) {
      setCatalogError(
        reason instanceof Error
          ? reason.message
          : "Could not load the demo catalog.",
      );
    } finally {
      setLoading(false);
    }
  }
  async function initialize(value: unknown) {
    return submission.run(async () => {
      const parsed = HouseholdDatasetSchema.safeParse(value);
      if (!parsed.success) throw new Error(validationMessage(parsed.error));
      return onInitialize(parsed.data);
    }, "Household initialized.");
  }
  async function personal(event: FormEvent) {
    event.preventDefault();
    await submission.run(async () => {
      const dataset = HouseholdDatasetSchema.safeParse({
        format: "homeops.household",
        version: 1,
        metadata: {
          id: newId("personal"),
          name: name.trim(),
          description: "Personal household entered by its operator.",
          kind: "personal",
          provenance: "Entered by the household operator during setup.",
        },
        providerMode: "manual",
        demoNow: null,
        household: {
          id: newId("household"),
          name: name.trim(),
          budget: rupees(budget),
          warrantyNoticeDays: 30,
        },
        schedulingPreferences: availability,
        notes: [],
        appliances: [],
        providers: [],
        expenses: [],
      });
      if (!dataset.success) throw new Error(validationMessage(dataset.error));
      return onInitialize(dataset.data);
    }, "Household initialized.");
  }
  function validateImport() {
    setImported(null);
    submission.setError("");
    submission.setNotice("");
    try {
      const parsed = HouseholdDatasetSchema.safeParse(JSON.parse(importText));
      if (!parsed.success) throw new Error(validationMessage(parsed.error));
      setImported(parsed.data);
    } catch (reason) {
      submission.setError(
        reason instanceof SyntaxError
          ? "This is not valid JSON. Check the file or pasted text and try again."
          : reason instanceof Error
            ? reason.message
            : "Could not validate this dataset.",
      );
    }
  }
  return (
    <section className="hd-panel hd-setup" aria-labelledby="hd-setup-title">
      <p className="hd-eyebrow">Start with your household</p>
      <h2 id="hd-setup-title">A place for everything at home.</h2>
      <p>
        Choose a demo or create your household. Supported region is India, INR
        and Asia/Kolkata.
      </p>
      <p className="hd-hint">
        Setup and import initialize an empty workspace once. They cannot replace
        active service history.
      </p>
      <div className="hd-actions">
        <button
          className={mode === "demo" ? "hd-primary" : ""}
          type="button"
          disabled={disabled}
          onClick={loadCatalog}
        >
          Try a demo
        </button>
        <button
          className={mode === "personal" ? "hd-primary" : ""}
          type="button"
          disabled={disabled}
          onClick={() => setMode("personal")}
        >
          Set up my household
        </button>
        <button
          type="button"
          disabled={disabled}
          onClick={() => setMode("import")}
        >
          Import household JSON
        </button>
      </div>
      {mode === "demo" && (
        <fieldset className="hd-section" disabled={disabled}>
          <legend>Choose a demo</legend>
          <p className="hd-hint">
            Synthetic records and simulated providers are clearly marked. A demo
            may use a controllable clock.
          </p>
          {loading && <p role="status">Loading demo catalog...</p>}
          {catalogError && (
            <p className="hd-error" role="alert">
              {catalogError}
            </p>
          )}
          {catalog.map((entry) => (
            <label className="hd-catalog-item" key={entry.id}>
              <input
                type="radio"
                name={catalogGroup}
                checked={selected === entry.id}
                onChange={() => setSelected(entry.id)}
              />
              <span>
                <strong>{entry.name}</strong>
                <small>{entry.description}</small>
              </span>
            </label>
          ))}
          <button
            className="hd-primary"
            type="button"
            disabled={
              disabled || !catalog.some((entry) => entry.id === selected)
            }
            onClick={() => {
              const entry = catalog.find((item) => item.id === selected);
              if (entry) void initialize(entry.dataset);
            }}
          >
            Start selected demo
          </button>
        </fieldset>
      )}
      {mode === "personal" && (
        <form className="hd-section" onSubmit={personal} noValidate>
          <fieldset disabled={disabled}>
            <legend>Your household</legend>
            <div className="hd-grid">
              <Field label="Household name">
                <input
                  value={name}
                  maxLength={500}
                  onChange={(event) => setName(event.target.value)}
                  autoComplete="organization"
                />
              </Field>
              <Field
                label="Default service budget (INR)"
                hint="Used for new service cases. You can change it later."
              >
                <input
                  inputMode="decimal"
                  value={budget}
                  placeholder="2500.00"
                  onChange={(event) => setBudget(event.target.value)}
                />
              </Field>
            </div>
            <AvailabilityFields
              value={availability}
              onChange={setAvailability}
            />
            <p className="hd-hint">
              Personal mode uses the system clock and manually entered provider
              quotes. It starts without appliances, providers or expenses. An
              approval creates a local plan awaiting your contact.
            </p>
            <button className="hd-primary" disabled={disabled}>
              Create household
            </button>
          </fieldset>
        </form>
      )}
      {mode === "import" && (
        <div className="hd-section">
          <fieldset disabled={disabled}>
            <legend>Import household data</legend>
            <Field label="Choose a JSON file">
              <input
                type="file"
                accept=".json,application/json"
                onChange={async (event) => {
                  const file = event.target.files?.[0];
                  if (!file) return;
                  setImported(null);
                  if (file.size > 10 * 1024 * 1024) {
                    submission.setError(
                      "Choose a JSON file smaller than 10 MB.",
                    );
                    return;
                  }
                  try {
                    setImportText(await file.text());
                    submission.setError("");
                  } catch {
                    submission.setError(
                      "Could not read this file. Try again or paste the JSON below.",
                    );
                  }
                }}
              />
            </Field>
            <Field label="Household JSON">
              <textarea
                rows={8}
                value={importText}
                spellCheck={false}
                onChange={(event) => {
                  setImportText(event.target.value);
                  setImported(null);
                }}
              />
            </Field>
            <button type="button" onClick={validateImport}>
              Validate import
            </button>
            {imported && (
              <div className="hd-import-summary" role="status">
                <strong>{imported.household.name}</strong>
                <p>
                  {imported.metadata.kind === "synthetic"
                    ? "Demo data"
                    : "Personal data"}{" "}
                  ·{" "}
                  {imported.providerMode === "simulated"
                    ? "Simulated providers"
                    : "Manual providers"}{" "}
                  · {imported.appliances.length} appliances ·{" "}
                  {imported.providers.length} providers ·{" "}
                  {imported.expenses.length} expenses
                </p>
                <button
                  className="hd-primary"
                  type="button"
                  onClick={() => void initialize(imported)}
                >
                  Initialize with this dataset
                </button>
              </div>
            )}
          </fieldset>
        </div>
      )}
      <Feedback error={submission.error} notice={submission.notice} />
    </section>
  );
}

function HouseholdEditor({
  snapshot,
  onCommand,
  busy,
}: { snapshot: HouseholdSnapshot } & CommandProps) {
  const saved = {
    name: snapshot.household.name,
    budget: major(snapshot.household.budget.minor),
    noticeDays: String(snapshot.household.warrantyNoticeDays),
  };
  const record = useRecordDraft(saved, snapshot.household.revision);
  const submission = useSubmission();
  const { draft } = record;
  async function submit(event: FormEvent) {
    event.preventDefault();
    if (
      await submission.run(
        () =>
          submitCommand(onCommand, {
            type: "household.update",
            expectedRevision: record.revision,
            name: draft.name,
            budget: rupees(draft.budget),
            warrantyNoticeDays: integer(
              draft.noticeDays,
              "Warranty notice days",
            ),
          }),
        "Household details saved.",
      )
    )
      record.saved();
  }
  return (
    <form onSubmit={submit} noValidate>
      <fieldset disabled={busy || submission.pending}>
        <legend>Household details</legend>
        <div className="hd-grid">
          <Field label="Household name">
            <input
              value={draft.name}
              maxLength={500}
              onChange={(event) =>
                record.edit({ ...draft, name: event.target.value })
              }
            />
          </Field>
          <Field label="Default service budget (INR)">
            <input
              inputMode="decimal"
              value={draft.budget}
              onChange={(event) =>
                record.edit({ ...draft, budget: event.target.value })
              }
            />
          </Field>
          <Field
            label="Warranty notice days"
            hint="How early HomeOps should flag a warranty ending."
          >
            <input
              inputMode="numeric"
              value={draft.noticeDays}
              onChange={(event) =>
                record.edit({ ...draft, noticeDays: event.target.value })
              }
            />
          </Field>
        </div>
        <RevisionNotice stale={record.stale} onReload={record.reload} />
        <button className="hd-primary" disabled={record.stale}>
          Save household details
        </button>
      </fieldset>
      <Feedback error={submission.error} notice={submission.notice} />
    </form>
  );
}

type AssetDraft = {
  id: string;
  name: string;
  kind: ApplianceKind;
  location: string;
  serviced: boolean;
  serviceDate: string;
  serviceSource: string;
  policy: boolean;
  interval: string;
  policySource: string;
  warranty: boolean;
  warrantyDate: string;
  warrantyTerms: string;
  warrantySource: string;
};
function assetDraft(record?: ApplianceInput): AssetDraft {
  return {
    id: record?.id ?? "",
    name: record?.name ?? "",
    kind: record?.kind ?? "other",
    location: record?.location ?? "",
    serviced: !!record?.lastService,
    serviceDate: record?.lastService?.performedOn ?? "",
    serviceSource: record?.lastService?.sourceId ?? "",
    policy: !!record?.maintenance,
    interval: String(record?.maintenance?.intervalDays ?? ""),
    policySource: record?.maintenance?.sourceId ?? "",
    warranty: !!record?.warranty,
    warrantyDate: record?.warranty?.ends ?? "",
    warrantyTerms: record?.warranty?.terms ?? "",
    warrantySource: record?.warranty?.sourceId ?? "",
  };
}
function AssetEditor({
  item,
  onCommand,
  busy,
  onClose,
}: {
  item?: HouseholdSnapshot["appliances"][number];
  onClose: () => void;
} & CommandProps) {
  const [newRecordId] = useState(() => newId("asset"));
  const record = useRecordDraft(
    { ...assetDraft(item?.record), id: item?.id ?? newRecordId },
    item?.revision ?? null,
  );
  const submission = useSubmission();
  const { draft } = record;
  const edit = <K extends keyof AssetDraft>(key: K, value: AssetDraft[K]) =>
    record.edit({ ...draft, [key]: value });
  async function submit(event: FormEvent) {
    event.preventDefault();
    const saved = await submission.run(
      () =>
        submitCommand(onCommand, {
          type: "asset.upsert",
          expectedRevision: record.revision,
          record: {
            id: draft.id,
            name: draft.name,
            kind: draft.kind,
            location: draft.location,
            lastService: draft.serviced
              ? {
                  performedOn: draft.serviceDate,
                  sourceId: draft.serviceSource,
                }
              : null,
            maintenance: draft.policy
              ? {
                  intervalDays: integer(draft.interval, "Service interval"),
                  sourceId: draft.policySource,
                }
              : null,
            warranty: draft.warranty
              ? {
                  ends: draft.warrantyDate,
                  sourceId: draft.warrantySource,
                  terms: draft.warrantyTerms,
                }
              : null,
          },
        }),
      "Appliance saved.",
    );
    if (saved) onClose();
  }
  return (
    <form className="hd-editor" onSubmit={submit} noValidate>
      <fieldset disabled={busy || submission.pending}>
        <legend>
          {item ? `Edit ${item.name}` : "Add an appliance or household asset"}
        </legend>
        <div className="hd-grid">
          <Field label="Name">
            <input
              value={draft.name}
              maxLength={500}
              onChange={(event) => edit("name", event.target.value)}
            />
          </Field>
          <Field label="Kind">
            <KindSelect
              value={draft.kind}
              onChange={(value) => edit("kind", value)}
            />
          </Field>
          <Field label="Location">
            <input
              value={draft.location}
              maxLength={500}
              onChange={(event) => edit("location", event.target.value)}
            />
          </Field>
        </div>
        <label className="hd-check">
          <input
            type="checkbox"
            checked={draft.serviced}
            onChange={(event) => edit("serviced", event.target.checked)}
          />
          I have a last service date
        </label>
        {draft.serviced && (
          <div className="hd-grid">
            <Field label="Last service date">
              <input
                type="date"
                value={draft.serviceDate}
                onChange={(event) => edit("serviceDate", event.target.value)}
              />
            </Field>
            <Field
              label="Service date source"
              hint="An actual receipt, message or your own dated record."
            >
              <input
                value={draft.serviceSource}
                maxLength={160}
                onChange={(event) => edit("serviceSource", event.target.value)}
              />
            </Field>
          </div>
        )}
        <label className="hd-check">
          <input
            type="checkbox"
            checked={draft.policy}
            onChange={(event) => edit("policy", event.target.checked)}
          />
          Set a maintenance interval
        </label>
        {draft.policy && (
          <div className="hd-grid">
            <Field label="Service interval in days">
              <input
                inputMode="numeric"
                value={draft.interval}
                onChange={(event) => edit("interval", event.target.value)}
              />
            </Field>
            <Field
              label="Maintenance policy source"
              hint="For example, the manual or your chosen household policy."
            >
              <input
                value={draft.policySource}
                maxLength={160}
                onChange={(event) => edit("policySource", event.target.value)}
              />
            </Field>
          </div>
        )}
        <label className="hd-check">
          <input
            type="checkbox"
            checked={draft.warranty}
            onChange={(event) => edit("warranty", event.target.checked)}
          />
          I have warranty information
        </label>
        {draft.warranty && (
          <div className="hd-grid">
            <Field label="Warranty end date">
              <input
                type="date"
                value={draft.warrantyDate}
                onChange={(event) => edit("warrantyDate", event.target.value)}
              />
            </Field>
            <Field label="Warranty terms">
              <textarea
                rows={3}
                value={draft.warrantyTerms}
                maxLength={500}
                onChange={(event) => edit("warrantyTerms", event.target.value)}
              />
            </Field>
            <Field label="Warranty source">
              <input
                value={draft.warrantySource}
                maxLength={160}
                onChange={(event) => edit("warrantySource", event.target.value)}
              />
            </Field>
          </div>
        )}
        <p className="hd-hint">
          Unchecked facts remain unknown. Only record dates and terms you can
          support.
        </p>
        <RevisionNotice stale={record.stale} onReload={record.reload} />
        <div className="hd-actions">
          <button className="hd-primary" disabled={record.stale}>
            Save appliance
          </button>
          <button type="button" onClick={onClose}>
            Cancel
          </button>
        </div>
      </fieldset>
      <Feedback error={submission.error} notice={submission.notice} />
    </form>
  );
}

type ProviderDraft = {
  id: string;
  name: string;
  kind: ApplianceKind;
  contact: string;
  preferred: boolean;
  available: boolean;
  declines: boolean;
  amount: string;
};
function providerDraft(record?: ProviderInput): ProviderDraft {
  return {
    id: record?.id ?? "",
    name: record?.name ?? "",
    kind: record?.serviceKind ?? "other",
    contact: record?.contactNote ?? "",
    preferred: record?.preferred ?? false,
    available: record?.available ?? true,
    declines: record?.simulation?.declines ?? false,
    amount: record?.simulation ? major(record.simulation.amount.minor) : "",
  };
}
function ProviderEditor({
  item,
  simulated,
  onCommand,
  busy,
  onClose,
}: {
  item?: HouseholdSnapshot["providers"][number];
  simulated: boolean;
  onClose: () => void;
} & CommandProps) {
  const [newRecordId] = useState(() => newId("provider"));
  const record = useRecordDraft(
    { ...providerDraft(item?.record), id: item?.id ?? newRecordId },
    item?.revision ?? null,
  );
  const submission = useSubmission();
  const { draft } = record;
  const edit = <K extends keyof ProviderDraft>(
    key: K,
    value: ProviderDraft[K],
  ) => record.edit({ ...draft, [key]: value });
  async function submit(event: FormEvent) {
    event.preventDefault();
    if (
      await submission.run(
        () =>
          submitCommand(onCommand, {
            type: "provider.upsert",
            expectedRevision: record.revision,
            record: {
              id: draft.id,
              name: draft.name,
              serviceKind: draft.kind,
              contactNote: draft.contact.trim() || null,
              preferred: draft.preferred,
              available: draft.available,
              simulation: simulated
                ? { declines: draft.declines, amount: rupees(draft.amount) }
                : null,
            },
          }),
        "Provider saved.",
      )
    )
      onClose();
  }
  return (
    <form className="hd-editor" onSubmit={submit} noValidate>
      <fieldset disabled={busy || submission.pending}>
        <legend>{item ? `Edit ${item.name}` : "Add a provider"}</legend>
        <div className="hd-grid">
          <Field label="Provider name">
            <input
              value={draft.name}
              maxLength={500}
              onChange={(event) => edit("name", event.target.value)}
            />
          </Field>
          <Field label="Service kind">
            <KindSelect
              value={draft.kind}
              onChange={(value) => edit("kind", value)}
            />
          </Field>
          <Field
            label="Contact note (optional)"
            hint="Contact details or instructions you want to keep."
          >
            <textarea
              rows={3}
              value={draft.contact}
              maxLength={1000}
              onChange={(event) => edit("contact", event.target.value)}
            />
          </Field>
        </div>
        <div className="hd-actions">
          <label className="hd-check">
            <input
              type="checkbox"
              checked={draft.preferred}
              onChange={(event) => edit("preferred", event.target.checked)}
            />
            Preferred provider
          </label>
          <label className="hd-check">
            <input
              type="checkbox"
              checked={draft.available}
              onChange={(event) => edit("available", event.target.checked)}
            />
            Available for service
          </label>
        </div>
        {simulated ? (
          <fieldset className="hd-simulation">
            <legend>Demo simulation only</legend>
            <p className="hd-hint">
              These settings control synthetic provider responses. They are not
              actual quotes.
            </p>
            <Field label="Simulated quote amount (INR)">
              <input
                inputMode="decimal"
                value={draft.amount}
                onChange={(event) => edit("amount", event.target.value)}
              />
            </Field>
            <label className="hd-check">
              <input
                type="checkbox"
                checked={draft.declines}
                onChange={(event) => edit("declines", event.target.checked)}
              />
              Simulate a declined request
            </label>
          </fieldset>
        ) : (
          <p className="hd-hint">
            Manual provider. HomeOps will use actual quotes you enter and will
            not contact this provider.
          </p>
        )}
        <RevisionNotice stale={record.stale} onReload={record.reload} />
        <div className="hd-actions">
          <button className="hd-primary" disabled={record.stale}>
            Save provider
          </button>
          <button type="button" onClick={onClose}>
            Cancel
          </button>
        </div>
      </fieldset>
      <Feedback error={submission.error} notice={submission.notice} />
    </form>
  );
}

export function HouseholdRecords({
  snapshot,
  onCommand,
  busy,
}: { snapshot: HouseholdSnapshot } & CommandProps) {
  const [asset, setAsset] = useState<string | null>(null);
  const [provider, setProvider] = useState<string | null>(null);
  const exported = useSubmission();
  if (snapshot.workspace.status !== "ready") return null;
  const simulated = snapshot.workspace.providerMode === "simulated";
  async function download() {
    await exported.run(async () => {
      const response = await fetch("/api/homeops/export", {
        credentials: "same-origin",
      });
      if (!response.ok)
        throw new Error(
          "Could not export household data. Check the connection and try again.",
        );
      const parsed = HouseholdDatasetSchema.safeParse(await response.json());
      if (!parsed.success)
        throw new Error(
          "The server returned an invalid household export. No file was downloaded.",
        );
      const url = URL.createObjectURL(
        new Blob([`${JSON.stringify(parsed.data, null, 2)}\n`], {
          type: "application/json",
        }),
      );
      const link = document.createElement("a");
      link.href = url;
      link.download = "homeops-household.json";
      document.body.append(link);
      link.click();
      link.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      return true;
    }, "Household JSON download started.");
  }
  return (
    <section className="hd-panel hd-records" aria-label="Household records">
      <HouseholdEditor snapshot={snapshot} onCommand={onCommand} busy={busy} />
      <section className="hd-section">
        <div className="hd-section-heading">
          <h3>Appliances & household assets</h3>
          <button type="button" disabled={busy} onClick={() => setAsset("new")}>
            Add appliance
          </button>
        </div>
        {!snapshot.appliances.length && (
          <p className="hd-hint">
            No appliances yet. Add anything you maintain, including an asset of
            kind Other.
          </p>
        )}
        <ul className="hd-record-list">
          {snapshot.appliances.map((item) => (
            <li key={item.id}>
              <div>
                <strong>{item.name}</strong>
                <span>
                  {item.location} ·{" "}
                  {kinds.find((kind) => kind.value === item.kind)?.label}
                </span>
              </div>
              <button
                type="button"
                disabled={busy}
                onClick={() => setAsset(item.id)}
                aria-label={`Edit appliance ${item.name}`}
              >
                Edit
              </button>
            </li>
          ))}
        </ul>
        {asset !== null && (
          <AssetEditor
            key={asset}
            item={snapshot.appliances.find((item) => item.id === asset)}
            onCommand={onCommand}
            busy={busy}
            onClose={() => setAsset(null)}
          />
        )}
      </section>
      <section className="hd-section">
        <div className="hd-section-heading">
          <h3>Trusted providers</h3>
          <button
            type="button"
            disabled={busy}
            onClick={() => setProvider("new")}
          >
            Add provider
          </button>
        </div>
        <p className="hd-hint">
          {simulated
            ? "Demo providers use simulated responses."
            : "Provider quotes and appointment confirmations must be entered from your actual contact."}
        </p>
        {!snapshot.providers.length && <p>No providers yet.</p>}
        <ul className="hd-record-list">
          {snapshot.providers.map((item) => (
            <li key={item.id}>
              <div>
                <strong>{item.name}</strong>
                <span>
                  {
                    kinds.find((kind) => kind.value === item.record.serviceKind)
                      ?.label
                  }{" "}
                  · {item.preferred ? "Preferred" : "Alternative"} ·{" "}
                  {item.available ? "Available" : "Unavailable"}
                </span>
              </div>
              <button
                type="button"
                disabled={busy}
                onClick={() => setProvider(item.id)}
                aria-label={`Edit provider ${item.name}`}
              >
                Edit
              </button>
            </li>
          ))}
        </ul>
        {provider !== null && (
          <ProviderEditor
            key={provider}
            item={snapshot.providers.find((item) => item.id === provider)}
            simulated={simulated}
            onCommand={onCommand}
            busy={busy}
            onClose={() => setProvider(null)}
          />
        )}
      </section>
      <section className="hd-section">
        <h3>Take your household data with you</h3>
        <p>
          Export master records and recorded expenses as JSON. This is not a
          workflow backup. Approvals, conversations, active cases and booking
          history are not included.
        </p>
        <button
          type="button"
          disabled={busy || exported.pending}
          onClick={download}
        >
          {exported.pending ? "Preparing download..." : "Export household JSON"}
        </button>
        <Feedback error={exported.error} notice={exported.notice} />
      </section>
    </section>
  );
}

export function ManualQuoteForm(
  props: { snapshot: HouseholdSnapshot; item: CaseCard } & CommandProps,
) {
  return <ManualQuoteEditor key={props.item.id} {...props} />;
}

function ManualQuoteEditor({
  snapshot,
  item,
  onCommand,
  busy,
}: { snapshot: HouseholdSnapshot; item: CaseCard } & CommandProps) {
  const [draft, setDraft] = useState({
    providerId: "",
    kind: "fixed" as "fixed" | "inspection",
    amount: "",
    date: "",
    start: "",
    end: "",
    expires: "",
    source: "",
  });
  const submission = useSubmission();
  if (
    snapshot.workspace.status !== "ready" ||
    snapshot.workspace.providerMode !== "manual"
  )
    return null;
  if (
    item.purpose === "warranty" || [
      "planned",
      "booked",
      "awaiting_completion",
      "completed",
      "cancelled",
    ].includes(item.state)
  )
    return null;
  const appliance = snapshot.appliances.find(
    (asset) => asset.id === item.applianceId,
  );
  const providers = snapshot.providers.filter(
    (provider) => provider.record.serviceKind === appliance?.kind,
  );
  const edit = (key: keyof typeof draft, value: string) =>
    setDraft((current) => ({ ...current, [key]: value }));
  async function submit(event: FormEvent) {
    event.preventDefault();
    await submission.run(() => {
      const start = `${draft.date}T${draft.start}:00+05:30`;
      const end = `${draft.date}T${draft.end}:00+05:30`;
      if (
        !Number.isFinite(Date.parse(start)) ||
        !Number.isFinite(Date.parse(end)) ||
        Date.parse(end) - Date.parse(start) !== 3600000
      )
        throw new Error(
          "Enter a visit date and an exact one-hour window within that day.",
        );
      if (!draft.expires)
        throw new Error(
          "Enter the quote expiry date and time supplied by the provider.",
        );
      return submitCommand(onCommand, {
        type: "case.recordQuote",
        caseId: item.id,
        providerId: draft.providerId,
        slot: { start, end },
        expiresAt: `${draft.expires}:00+05:30`,
        sourceId: draft.source.trim(),
        charge:
          draft.kind === "fixed"
            ? { kind: "fixed", total: rupees(draft.amount) }
            : {
                kind: "inspection",
                fee: rupees(draft.amount),
                parts: "unknown",
              },
      });
    }, "Entered quote saved. Review its terms before approving a service plan.");
  }
  return (
    <form className="hd-panel hd-quote" onSubmit={submit} noValidate>
      <fieldset disabled={busy || submission.pending}>
        <legend>Enter a provider quote</legend>
        <p>
          Use terms from your actual conversation or document. HomeOps does not
          contact providers.
        </p>
        {!providers.length && (
          <p className="hd-hint">
            Add a provider with the matching service kind in Household first.
          </p>
        )}
        <div className="hd-grid">
          <Field label="Provider">
            <select
              value={draft.providerId}
              onChange={(event) => edit("providerId", event.target.value)}
            >
              <option value="">Choose a provider</option>
              {providers.map((provider) => (
                <option key={provider.id} value={provider.id}>
                  {provider.name}
                  {provider.available ? "" : " (marked unavailable)"}
                </option>
              ))}
            </select>
          </Field>
          <Field label="Quote type">
            <select
              value={draft.kind}
              onChange={(event) => edit("kind", event.target.value)}
            >
              <option value="fixed">Fixed total</option>
              <option value="inspection">Inspection fee, parts unknown</option>
            </select>
          </Field>
          <Field
            label={
              draft.kind === "fixed"
                ? "Fixed total (INR)"
                : "Inspection fee (INR)"
            }
          >
            <input
              inputMode="decimal"
              value={draft.amount}
              onChange={(event) => edit("amount", event.target.value)}
            />
          </Field>
          <Field label="Visit date">
            <input
              type="date"
              value={draft.date}
              onChange={(event) => edit("date", event.target.value)}
            />
          </Field>
          <Field label="Visit window starts">
            <input
              type="time"
              value={draft.start}
              onChange={(event) => edit("start", event.target.value)}
            />
          </Field>
          <Field label="Visit window ends">
            <input
              type="time"
              value={draft.end}
              onChange={(event) => edit("end", event.target.value)}
            />
          </Field>
          <Field label="Quote expires at">
            <input
              type="datetime-local"
              value={draft.expires}
              onChange={(event) => edit("expires", event.target.value)}
            />
          </Field>
          <Field
            label="Quote source"
            hint="Reference your actual message, call note or document. Do not enter a made-up quote."
          >
            <input
              value={draft.source}
              maxLength={160}
              onChange={(event) => edit("source", event.target.value)}
            />
          </Field>
        </div>
        <p className="hd-hint">
          All times use Asia/Kolkata. Visits use one-hour windows within your saved availability.{" "}
          {draft.kind === "inspection"
            ? "The final repair cost remains unknown. Parts are not included in this fee."
            : "Record the complete total quoted by the provider."}
        </p>
        <button className="hd-primary" disabled={!providers.length}>
          Save entered quote
        </button>
      </fieldset>
      <Feedback error={submission.error} notice={submission.notice} />
    </form>
  );
}

export function ManualPlanConfirmation(
  props: { item: CaseCard } & CommandProps,
) {
  return <ManualPlanEditor key={props.item.id} {...props} />;
}

function ManualPlanEditor({
  item,
  onCommand,
  busy,
}: { item: CaseCard } & CommandProps) {
  const [source, setSource] = useState("");
  const submission = useSubmission();
  if (item.servicePlan?.status === "user_confirmed")
    return (
      <section
        className="hd-panel hd-plan"
        aria-label="Appointment confirmation"
      >
        <h3>Appointment confirmed by you</h3>
        <p>Confirmation source: {item.servicePlan.sourceId}</p>
        <p className="hd-hint">
          Your confirmation was recorded separately from service completion and
          actual expense.
        </p>
      </section>
    );
  if (item.state !== "planned" || item.servicePlan?.status !== "needs_contact")
    return null;
  async function submit(event: FormEvent) {
    event.preventDefault();
    await submission.run(
      () =>
        submitCommand(onCommand, {
          type: "case.confirmManualPlan",
          caseId: item.id,
          sourceId: source.trim(),
        }),
      "Your sourced appointment confirmation was recorded. Service completion and actual expense are recorded separately.",
    );
  }
  return (
    <form className="hd-panel hd-plan" onSubmit={submit} noValidate>
      <fieldset disabled={busy || submission.pending}>
        <legend>Awaiting your contact</legend>
        <p>
          This is an approved local service plan. Contact the provider yourself,
          then record their actual appointment confirmation.
        </p>
        <Field
          label="Appointment confirmation source"
          hint="Reference the actual message, call note or document confirming the appointment."
        >
          <input
            value={source}
            maxLength={160}
            onChange={(event) => setSource(event.target.value)}
          />
        </Field>
        <button className="hd-primary">Record provider confirmation</button>
        <p className="hd-hint">
          This records your confirmation. It does not mark the service complete
          or record an expense.
        </p>
      </fieldset>
      <Feedback error={submission.error} notice={submission.notice} />
    </form>
  );
}
