import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type FormEvent,
  type KeyboardEvent,
  type ReactNode,
} from "react";
import {
  Activity,
  ArrowRight,
  Bell,
  CalendarDays,
  Check,
  ChevronRight,
  CircleHelp,
  Droplets,
  Home,
  LayoutDashboard,
  Leaf,
  LoaderCircle,
  MessageCircle,
  Plug,
  Plus,
  Settings2,
  ShieldCheck,
  Snowflake,
  Sparkles,
  Wallet,
  WashingMachine,
  Wrench,
  X,
} from "lucide-react";
import type {
  ApplianceCard,
  ActivityRow,
  CaseCard,
  CommandResult,
  Evidence,
  HouseholdSnapshot,
  Money,
  PublicCommand,
} from "../../../../packages/contracts/src/index";
import { AgentChat } from "./agent-chat";
import { HouseAtlas } from "./house-atlas";
import { McpPanel } from "./mcp-panel";
import {
  HouseholdSetup,
  HouseholdRecords,
  ManualQuoteForm,
  ManualPlanConfirmation,
} from "./household-data";
import {
  AppointmentPreferences,
  appointmentSummary,
} from "./appointment-preferences";

type Tab = "Overview" | "Household" | "Activity" | "Expenses" | "MCP";
const icons = {
  ac: Snowflake,
  purifier: Droplets,
  washer: WashingMachine,
  garden: Leaf,
  sink: Wrench,
  other: Home,
};
const labels = {
  due: "Needs attention",
  requesting_offers: "Finding providers",
  awaiting_approval: "Your decision",
  booking: "Booking",
  booked: "Visit booked",
  planned: "Awaiting your contact",
  awaiting_completion: "Awaiting completion",
  completed: "Completed",
  denied: "Declined",
  unavailable: "Unavailable",
  cancelled: "Cancelled",
  failed: "Needs a retry",
};
export const money = (value: Money) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: value.currency,
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(value.minor / 100);
export const date = (value: string, includeTime = false) =>
  new Intl.DateTimeFormat("en-IN", {
    day: "numeric",
    month: "short",
    ...(includeTime ? { hour: "numeric", minute: "2-digit" } : {}),
    timeZone: "Asia/Kolkata",
  }).format(new Date(value));
const dayInIndia = (value: string) => {
  if (/^\d{4}-\d{2}-\d{2}$/.test(value)) return value;
  const parts = new Intl.DateTimeFormat("en-CA", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    timeZone: "Asia/Kolkata",
  }).formatToParts(new Date(value));
  const part = (type: string) =>
    parts.find((item) => item.type === type)?.value;
  return `${part("year")}-${part("month")}-${part("day")}`;
};

async function request<T>(url: string, init?: RequestInit): Promise<T> {
  const response = await fetch(url, init);
  const body = await response.json().catch(() => null);
  if (!response.ok)
    throw new Error(
      body?.error?.message ?? `Request failed (${response.status}).`,
    );
  return body as T;
}

export function HomeOps({ initialSessionId }: { initialSessionId?: string }) {
  const [auth, setAuth] = useState<{ authenticated: boolean; csrf?: string }>();
  const [snapshot, setSnapshot] = useState<HouseholdSnapshot>();
  const [tab, setTab] = useState<Tab>("Overview");
  const [atlasFocus, setAtlasFocus] = useState(false);
  const [atlasAssetId, setAtlasAssetId] = useState<string>();
  const [mobilePane, setMobilePane] = useState<"assistant" | "records">("assistant");
  const [selectedId, setSelectedId] = useState<string>();
  const [sessionId, setSessionId] = useState(initialSessionId);
  const [chatEpoch, setChatEpoch] = useState(0);
  const [error, setError] = useState<string>();
  const [connectionError, setConnectionError] = useState<string>();
  const [busy, setBusy] = useState(false);
  const [settings, setSettings] = useState(false);
  const [notice, setNotice] = useState<string>();
  const assistantRef = useRef<HTMLElement>(null);
  const settingsOpener = useRef<HTMLElement | null>(null);
  const knownCases = useRef<Set<string> | null>(null);

  const showAssistant = () => {
    setAtlasFocus(true);
    setTab("Overview");
    setMobilePane("assistant");
    assistantRef.current?.scrollIntoView({
      behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches
        ? "auto"
        : "smooth",
      block: "start",
    });
    window.requestAnimationFrame(() =>
      assistantRef.current
        ?.querySelector<HTMLElement>("textarea")
        ?.focus({ preventScroll: true }),
    );
  };

  useEffect(() => {
    if (!settings) return;
    return () => settingsOpener.current?.focus();
  }, [settings]);

  useEffect(() => {
    if (!initialSessionId)
      setSessionId(localStorage.getItem("homeops:native:session") ?? undefined);
  }, [initialSessionId]);

  const refresh = useCallback(async () => {
    try {
      setSnapshot(await request<HouseholdSnapshot>("/api/homeops/snapshot"));
      setConnectionError(undefined);
    } catch (problem) {
      setConnectionError(errorText(problem));
    }
  }, []);
  useEffect(() => {
    void request<{ authenticated: boolean; csrf?: string }>("/api/auth/session")
      .then(setAuth)
      .catch((problem) => setError(errorText(problem)));
  }, []);
  useEffect(() => {
    if (!auth?.authenticated) return;
    void refresh();
    const timer = window.setInterval(refresh, 4000);
    return () => window.clearInterval(timer);
  }, [auth?.authenticated, refresh]);
  const selected =
    snapshot?.cases.find((item) => item.id === selectedId) ??
    snapshot?.cases.toReversed().find((item) => item.urgent && !["completed", "cancelled", "denied"].includes(item.state)) ??
    snapshot?.cases
      .toReversed()
      .find(
        (item) => !["completed", "cancelled", "denied"].includes(item.state),
      ) ??
    snapshot?.cases.at(-1);
  useEffect(() => {
    if (selected && selected.id !== selectedId) setSelectedId(selected.id);
  }, [selected, selectedId]);
  useEffect(() => {
    if (!snapshot) return;
    const incident = snapshot.cases.toReversed().find((item) => item.urgent &&
      !["completed", "cancelled", "denied"].includes(item.state) &&
      snapshot.appliances.some((appliance) => appliance.id === item.applianceId && appliance.kind === "sink") &&
      !knownCases.current?.has(item.id));
    if (incident) {
      setAtlasFocus(true);
      setSelectedId(incident.id);
      setTab("Overview");
    }
    knownCases.current = new Set(snapshot.cases.map((item) => item.id));
  }, [snapshot]);
  const mutate = useCallback(
    async (command: PublicCommand): Promise<boolean> => {
      setBusy(true);
      setError(undefined);
      setNotice(undefined);
      try {
        const result = await request<CommandResult>("/api/homeops/commands", {
          method: "POST",
          headers: {
            "content-type": "application/json",
            "x-homeops-csrf": auth?.csrf ?? "",
          },
          body: JSON.stringify({ commandId: crypto.randomUUID(), command }),
        });
        await refresh();
        if (command.type === "clock.set") setSelectedId(undefined);
        if (command.type === "case.openUrgent" && result.affectedIds[0])
          setSelectedId(result.affectedIds[0]);
        return true;
      } catch (problem) {
        setError(errorText(problem));
        return false;
      } finally {
        setBusy(false);
      }
    },
    [auth?.csrf, refresh],
  );
  const discuss = async (caseId?: string) => {
    if (!caseId) {
      showAssistant();
      return;
    }
    setBusy(true);
    setError(undefined);
    try {
      const result = await request<{ sessionId: string }>(
        "/api/homeops/discuss",
        {
          method: "POST",
          headers: {
            "content-type": "application/json",
            "x-homeops-csrf": auth?.csrf ?? "",
          },
          body: JSON.stringify({ caseId }),
        },
      );
      localStorage.setItem("homeops:native:session", result.sessionId);
      setSessionId(result.sessionId);
      showAssistant();
      await refresh();
    } catch (problem) {
      setError(errorText(problem));
    } finally {
      setBusy(false);
    }
  };
  const choose = async (caseId: string, offerId: string, revision: number) => {
    if (await mutate({ type: "case.chooseOffer", caseId, offerId, revision }))
      await discuss(caseId);
  };
  const nextDue = () => {
    if (!snapshot) return;
    const current = snapshot.clock.effectiveNow;
    const next = snapshot.appliances
      .map((item) => item.nextDue.value)
      .filter(
        (value): value is string =>
          value !== null &&
          new Date(value).getTime() > new Date(current).getTime(),
      )
      .sort()[0];
    const day = next
      ? dayInIndia(next)
      : dayInIndia(
          new Date(new Date(current).getTime() + 86400000).toISOString(),
        );
    void mutate({ type: "clock.set", now: `${day}T09:00:00+05:30` });
  };

  if (!auth)
    return (
      <div className="homeops-loading">
        <HomeMark />
        <LoaderCircle className="spin" />
        <p>{error ?? "Opening your home…"}</p>
        {error && (
          <button onClick={() => window.location.reload()}>Try again</button>
        )}
      </div>
    );
  if (!auth.authenticated) return <Login onLogin={setAuth} />;
  if (!snapshot)
    return (
      <div className="homeops-loading">
        <HomeMark />
        <LoaderCircle className="spin" />
        <p>{connectionError ?? "Gathering household records…"}</p>
        {connectionError && (
          <button onClick={() => void refresh()}>Try again</button>
        )}
      </div>
    );
  if (snapshot.workspace.status === "empty")
    return (
      <div className="homeops-setup-shell">
        <header className="setup-heading">
          <a href="/" className="brand">
            <HomeMark />
            <span>
              homeops<span className="brand-dot">.</span>
            </span>
          </a>
          <span className="eyebrow">YOUR HOUSEHOLD WORKSPACE</span>
        </header>
        {connectionError && (
          <div className="error-banner" role="alert">
            {connectionError}
            <button onClick={() => void refresh()}>Retry connection</button>
          </div>
        )}
        {error && (
          <div className="error-banner" role="alert">
            {error}
          </div>
        )}
        <HouseholdSetup
          busy={busy}
          onInitialize={(dataset) =>
            mutate({ type: "dataset.initialize", dataset })
          }
        />
      </div>
    );
  const simulated =
    snapshot.workspace.dataKind === "synthetic" &&
    snapshot.workspace.providerMode === "simulated";
  const manual = snapshot.workspace.providerMode === "manual";
  const active = snapshot.cases.filter(
    (item) => !["completed", "cancelled", "denied"].includes(item.state),
  );
  const due = snapshot.inbox.filter((item) => !item.readAt);
  const sinkIncident = selected?.purpose === "urgent" && snapshot.appliances.some((appliance) =>
    appliance.id === selected.applianceId && appliance.kind === "sink") ? selected : undefined;

  const atlasAsset = snapshot.appliances.find(item => item.id === selected?.applianceId)
    ?? snapshot.appliances.find(item => item.id === atlasAssetId)
    ?? snapshot.appliances[0];
  const atlasTerms = selected?.approval?.terms ?? selected?.offers.find(offer => offer.status === "available" && offer.withinBudget)?.terms;
  const completedInspection = selected?.state === "completed" && atlasTerms?.charge.kind === "inspection";
  const selectAtlasAsset = (id: string) => {
    setAtlasAssetId(id);
    const linked = snapshot.cases.toReversed().find(item => item.applianceId === id && !["completed", "cancelled", "denied"].includes(item.state))
      ?? snapshot.cases.toReversed().find(item => item.applianceId === id);
    if (linked) {
      setSelectedId(linked.id);
      setAtlasFocus(true);
      setMobilePane("records");
    } else {
      setTab("Household");
      const asset = snapshot.appliances.find(item => item.id === id);
      setNotice(asset ? `Selected ${asset.name}. Its saved record is in Appliances below.` : undefined);
    }
  };

  return (
    <div className={`homeops-shell atlas-production ${atlasFocus ? "atlas-focus" : "atlas-home-mode"} ${tab === "Overview" ? "assistant-view" : "records-view"} mobile-${mobilePane}`}>
      <header className="home-header">
        <a href="/" className="brand" aria-label="HomeOps home">
          <HomeMark />
          <span>homeops<span className="brand-dot">.</span></span>
        </a>
        <nav className="workspace-nav" aria-label="Main navigation">
          {([
            ["Overview", Home, "House atlas"],
            ["Household", Home, "Household"],
            ["Activity", Activity, "Activity"],
            ["Expenses", Wallet, "Expenses"],
            ["MCP", Plug, "MCP"],
          ] as const).map(([name, Icon, label]) => (
            <button key={name} className={tab === name ? "nav-item active" : "nav-item"}
              aria-current={tab === name ? "page" : undefined}
              onClick={() => { setTab(name); if (name === "Overview") { setAtlasFocus(false); setMobilePane("records"); } }}>
              <Icon size={16} /><span>{label}</span>
              {name === "Overview" && due.length > 0 && <span className="nav-count">{due.length}</span>}
            </button>
          ))}
        </nav>
        <button className="atlas-speak-button" onClick={showAssistant}><MessageCircle size={16} /><span>Speak / Type</span><ArrowRight size={15}/></button>
        <button className="header-settings" aria-label={simulated ? "Demo settings and appointment preferences" : "Appointment preferences"}
          onClick={(event) => { settingsOpener.current = event.currentTarget; setSettings(true); }}>
          <Settings2 size={18} /><span>Preferences</span>
        </button>
      </header>
      <div className="workspace-content">
        <div className="workspace-intro">
          <div className="household-identity"><span className="online-dot" /><strong>{snapshot.household.name}</strong>
            <span className={`data-badge ${simulated ? "demo" : ""}`}>{snapshot.workspace.dataKind === "synthetic" ? "Demo workspace" : "Personal workspace"}</span>
          </div>
          <span className="workspace-status">{manual ? "You contact your providers" : "Provider interactions are simulated"}</span>
          <div className="mobile-pane-switch" aria-label="Workspace pane">
            <button aria-pressed={mobilePane === "assistant"} onClick={() => { setAtlasFocus(true); setMobilePane("assistant"); }}>Assistant</button>
            <button aria-pressed={mobilePane === "records"} onClick={() => setMobilePane("records")}>Case & records <span>{active.length}</span></button>
          </div>
        </div>
        <div className="home-workspace">
          <div className="workspace-body">
            {tab === "Overview" && <section className="atlas-home" aria-label="Your household workspace">
              <div className="atlas-house-region"><div className="atlas-house-title"><div><p className="eyebrow">YOUR HOUSE, REMEMBERED</p><h1>{snapshot.household.name}</h1></div><span>{date(snapshot.clock.effectiveNow)}<small>Asia/Kolkata</small></span></div>
                <HouseAtlas snapshot={snapshot} selectedApplianceId={atlasAsset?.id} onSelectAppliance={selectAtlasAsset}/>
              </div>
              <div className="atlas-home-actions">
                <div className="atlas-action-label"><span>{selected && !["completed", "cancelled", "denied"].includes(selected.state) ? "YOUR NEXT STEP" : "HOUSEHOLD MEMORY"}</span><span>{String(active.length).padStart(2,"0")} OPEN</span></div>
                <div className="atlas-next-case"><p className="atlas-home-location">{atlasAsset?.location ?? "Household"}</p><h2>{selected?.title ?? atlasAsset?.name ?? "Start with your household."}</h2>
                  <p className="atlas-next-status">{completedInspection ? "Inspection complete · repair not performed" : selected ? labels[selected.state] : "No open case"}</p>
                  <p>{completedInspection ? "The inspection is recorded. Repair work and its final cost still need a separate sourced decision." : selected?.reason ?? "Saved appliances, service history and source records live here. Speak or type to ask HomeOps for help."}</p>
                  {atlasTerms && <div className="atlas-home-amount"><span>{atlasTerms.charge.kind === "inspection" ? "Inspection fee" : "Quoted amount"}</span><strong>{money(atlasTerms.charge.kind === "inspection" ? atlasTerms.charge.fee : atlasTerms.charge.total)}</strong><small>{atlasTerms.charge.kind === "inspection" ? "Final repair cost unknown" : "Quotes are not confirmed spending"}</small></div>}
                  <button className="atlas-primary-action" onClick={() => { if (selected?.approval?.status === "pending") void discuss(selected.id); else if (selected) { setAtlasFocus(true); setMobilePane("records"); } else setTab("Household"); }}>{selected ? selected.state === "completed" ? completedInspection ? "View inspection & charges" : "View service record" : selected.approval?.status === "pending" ? "Review exact approval" : selected.offers.length ? "Compare providers" : "Open care plan" : "Explore household records"}<ArrowRight size={18}/></button>
                </div>
                <div className="atlas-open-matters"><h3>Elsewhere in your house</h3>{active.filter(item => item.id !== selected?.id).slice(0,3).map(item => <button key={item.id} onClick={() => { setSelectedId(item.id); setAtlasAssetId(item.applianceId); setAtlasFocus(true); setMobilePane("records"); }}><span>{item.title}<small>{labels[item.state]}</small></span><ArrowRight size={16}/></button>)}{active.filter(item => item.id !== selected?.id).length === 0 && <p>No other open cases.</p>}</div>
                <button className="atlas-talk-callout" onClick={showAssistant}><MessageCircle size={22}/><span><strong>Something happened?</strong><small>Speak or type. Review before sending.</small></span><ArrowRight size={18}/></button>
              </div>
              <div className="atlas-house-journal"><button onClick={() => setTab("Activity")}>Household journal <ArrowRight size={14}/></button>{snapshot.activity.toReversed().slice(0,2).map(event => <div key={event.id}><time>{date(event.at)}</time><p>{event.summary}</p>{event.simulated && <small>Simulated</small>}</div>)}{snapshot.activity.length === 0 && <p>Saved activity will appear as you use HomeOps.</p>}</div>
            </section>}
            <main className="dashboard-main">
              {tab === "Overview" && <div className="atlas-focused-context"><button onClick={() => setAtlasFocus(false)}><Home size={14}/> Back to house atlas</button><HouseAtlas snapshot={snapshot} selectedApplianceId={selected?.applianceId} onSelectAppliance={selectAtlasAsset} compact/></div>}
              <div className="page-heading">
                <div>
                  <p className="eyebrow">WORKSPACE / {tab.toUpperCase()}</p>
                  <h1>
                    {tab === "Overview"
                      ? "Around your home"
                      : tab === "Household"
                        ? "Household records"
                        : tab === "MCP"
                          ? "MCP console"
                          : tab === "Expenses"
                            ? "Expense ledger"
                            : "Activity history"}
                  </h1>
                  <p>
                    {tab === "Overview"
                      ? sinkIncident ? "Your current incident, decisions and source records." : "The things you’re looking after."
                      : tab === "Household"
                        ? "Keep appliances, providers and their source records current."
                        : tab === "Expenses"
                          ? "Confirmed charges, kept separate from quotes and reservations."
                          : tab === "Activity"
                            ? "A persistent record of decisions, service and follow-through."
                            : "Inspect the actual Model Context Protocol journey."}
                  </p>
                </div>
              </div>
              {connectionError && (
                <div className="error-banner" role="alert">
                  <CircleHelp size={18} />
                  <span>
                    Household connection interrupted. {connectionError}
                  </span>
                  <button onClick={() => void refresh()}>
                    Retry connection
                  </button>
                </div>
              )}
              {error && (
                <div className="error-banner" role="alert">
                  <CircleHelp size={18} />
                  <span>{error}</span>
                  <button
                    aria-label="Dismiss error"
                    onClick={() => setError(undefined)}
                  >
                    <X size={16} />
                  </button>
                </div>
              )}
              {notice && (
                <div className="notice" role="status">
                  {notice}
                </div>
              )}
              {tab === "Overview" && (
                <>
                  {sinkIncident && <details className="rail-disclosure"><summary><Droplets size={16} /> Incident record & charges</summary><SinkIncidentFocus item={sinkIncident} snapshot={snapshot} onExpenses={() => setTab("Expenses")} /></details>}
                  <details className="overview-context rail-disclosure">
                    <summary><CalendarDays size={16} /> Household summary & scheduling</summary>
                  <div className="overview-grid">
                    <Stat
                      label="NEEDS YOUR ATTENTION"
                      value={String(active.length).padStart(2, "0")}
                      detail={
                        active.length
                          ? "Open household cases"
                          : "No open household cases"
                      }
                      icon={<Bell size={19} />}
                      accent
                    />
                    <Stat
                      label="LOOKING AFTER"
                      value={String(snapshot.appliances.length).padStart(
                        2,
                        "0",
                      )}
                      detail="Appliances & home services"
                      icon={<Home size={19} />}
                    />
                    <Stat
                      label="CONFIRMED SPENDING"
                      value={
                        snapshot.expenseTotals.map(money).join(" + ") || "₹0"
                      }
                      detail="Actual charges, all time"
                      icon={<Wallet size={19} />}
                    />
                  </div>
                  <div className="overview-controls">
                    {simulated && (
                      <section
                        className="clock-strip"
                        aria-label="Business clock"
                      >
                        <div className="clock-icon">
                          <CalendarDays size={19} />
                        </div>
                        <div>
                          <strong>
                            {new Intl.DateTimeFormat("en-IN", {
                              weekday: "long",
                              day: "numeric",
                              month: "long",
                              year: "numeric",
                              timeZone: "Asia/Kolkata",
                            }).format(new Date(snapshot.clock.effectiveNow))}
                          </strong>
                          <span>Demo clock · Asia/Kolkata</span>
                        </div>
                        <label className="sr-only" htmlFor="demo-date">
                          Set demo date
                        </label>
                        <input
                          id="demo-date"
                          type="date"
                          value={dayInIndia(snapshot.clock.effectiveNow)}
                          disabled={busy}
                          onChange={(event) =>
                            event.target.value &&
                            void mutate({
                              type: "clock.set",
                              now: `${event.target.value}T09:00:00+05:30`,
                            })
                          }
                        />
                        <button
                          className="quiet-button"
                          onClick={nextDue}
                          disabled={busy}
                        >
                          Next due day <ArrowRight size={15} />
                        </button>
                      </section>
                    )}
                    <section
                      className="schedule-strip"
                      aria-label="Saved appointment preferences"
                    >
                      <CalendarDays size={18} aria-hidden="true" />
                      <div>
                        <strong>Appointment preferences</strong>
                        <span>
                          {appointmentSummary(snapshot.schedulingPreferences)}
                        </span>
                      </div>
                      <button
                        className="quiet-button"
                        onClick={(event) => {
                          settingsOpener.current = event.currentTarget;
                          setSettings(true);
                        }}
                      >
                        Edit preferences
                      </button>
                    </section>
                  </div>
                  </details>
                  <section className="attention-section">
                    <div className="section-heading">
                      <h2>
                        <span className="accent-dot" />
                        Service cases{" "}
                        <span className="section-count">{active.length}</span>
                      </h2>
                      <span>Decisions and next steps</span>
                    </div>
                    {active.length === 0 ? (
                      <div className="clear-card">
                        <ShieldCheck size={28} />
                        <div>
                          <strong>Room to breathe.</strong>
                          <p>
                            {simulated
                              ? "No open cases. Advance the demo clock to evaluate the next service."
                              : "No open cases. Due work will appear from your service records and maintenance policies."}
                          </p>
                        </div>
                      </div>
                    ) : (
                      <div className="case-tabs" aria-label="Household cases">
                        {active.map((item) => (
                          <button
                            key={item.id}
                            className={
                              selected?.id === item.id
                                ? "case-tab selected"
                                : "case-tab"
                            }
                            onClick={() => { setSelectedId(item.id); setAtlasFocus(true); }}
                          >
                            <span
                              className={
                                item.urgent ? "tiny-dot urgent" : "tiny-dot"
                              }
                            />
                            {item.title}
                            <span>{labels[item.state]}</span>
                          </button>
                        ))}
                      </div>
                    )}
                    {selected && (
                      <CaseDetail
                        item={selected}
                        snapshot={snapshot}
                        onCommand={mutate}
                        manual={manual}
                        completion={snapshot.activity
                          .toReversed()
                          .find(
                            (event) =>
                              event.caseId === selected.id &&
                              event.kind === "service.completed",
                          )}
                        busy={busy}
                        onRequest={() =>
                          void mutate({
                            type: "case.requestOffers",
                            caseId: selected.id,
                          })
                        }
                        onDiscuss={() => void discuss(selected.id)}
                        onChoose={choose}
                        onComplete={() =>
                          void mutate({
                            type: "case.complete",
                            caseId: selected.id,
                            completedAt: dayInIndia(
                              snapshot.clock.effectiveNow,
                            ),
                            sourceId: `operator-completion-${crypto.randomUUID()}`,
                          })
                        }
                        onConfirm={(confirmed) =>
                          void mutate({
                            type: "case.confirmAppointment",
                            caseId: selected.id,
                            confirmed,
                          })
                        }
                      />
                    )}
                  </section>
                  <details className="rail-disclosure appliance-disclosure">
                    <summary><Home size={16} /> Appliances & services <span>{snapshot.appliances.length}</span></summary>
                    <div className="section-heading">
                      <h2>Appliances & services</h2>
                      <span>
                        {snapshot.appliances.length} things looked after
                      </span>
                    </div>
                    <div className="appliance-table-wrap">
                      <table className="appliance-table">
                        <caption className="sr-only">
                          Appliance maintenance and warranty records
                        </caption>
                        <thead>
                          <tr>
                            <th scope="col">Appliance</th>
                            <th scope="col">Status</th>
                            <th scope="col">Last service</th>
                            <th scope="col">Next care</th>
                            <th scope="col">Warranty</th>
                            <th scope="col">
                              <span className="sr-only">Action</span>
                            </th>
                          </tr>
                        </thead>
                        <tbody>
                          {snapshot.appliances.map((appliance) => (
                            <Appliance
                              key={appliance.id}
                              appliance={appliance}
                              clock={snapshot.clock.effectiveNow}
                              activeCase={active.find(
                                (item) => item.applianceId === appliance.id,
                              )}
                              onOpen={() => {
                                const item = active.find(
                                  (item) => item.applianceId === appliance.id,
                                );
                                if (item) setSelectedId(item.id);
                                else if (appliance.kind === "sink")
                                  void mutate({
                                    type: "case.openUrgent",
                                    applianceId: appliance.id,
                                    description:
                                      "The kitchen sink is leaking. Please arrange a prompt inspection; final parts cost is unknown.",
                                  });
                                else
                                  setNotice(
                                    simulated
                                      ? "No active case. Change the demo clock or maintenance policy to evaluate the next due date."
                                      : "No active case. Edit service records or maintenance policy in Household to update the next due date.",
                                  );
                              }}
                            />
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </details>
                  <section className="inbox-section">
                    <div className="section-heading">
                      <h2>
                        Proactive inbox{" "}
                        <span className="section-count">
                          {snapshot.inbox.length}
                        </span>
                      </h2>
                      <span>Saved even when you’re away</span>
                    </div>
                    {snapshot.inbox.length === 0 ? (
                      <p className="empty-text">
                        Future reminders will appear here automatically.
                      </p>
                    ) : (
                      snapshot.inbox
                        .toReversed()
                        .slice(0, 6)
                        .map((item) => (
                          <button
                            className={`inbox-row ${!item.readAt ? "unread" : ""}`}
                            key={item.id}
                            onClick={() => {
                              setSelectedId(item.caseId);
                              void mutate({
                                type: "inbox.read",
                                inboxId: item.id,
                              });
                              if (item.sessionId) {
                                setSessionId(item.sessionId);
                                showAssistant();
                              }
                            }}
                          >
                            <span className="inbox-dot" />
                            <div>
                              <strong>{item.title}</strong>
                              <p>{item.body}</p>
                            </div>
                            <time>{date(item.createdAt)}</time>
                            <ChevronRight size={16} />
                          </button>
                        ))
                    )}
                  </section>
                </>
              )}
              {tab === "Household" && (
                <HouseholdRecords
                  snapshot={snapshot}
                  onCommand={mutate}
                  busy={busy}
                />
              )}
              {tab === "Activity" && (
                <section className="panel activity-list">
                  {snapshot.activity.length === 0 && (
                    <p className="empty-text">
                      Your activity will appear here.
                    </p>
                  )}
                  {snapshot.activity.toReversed().map((item) => (
                    <article key={item.id} className="activity-row">
                      <span className="activity-icon">
                        <Check size={16} />
                      </span>
                      <div>
                        <strong>{item.summary}</strong>
                        <p>
                          {item.kind.replaceAll(".", " · ")}
                          {item.simulated ? " · Simulated" : ""}
                        </p>
                        <details>
                          <summary>Source records</summary>
                          <code>
                            {item.sourceIds.join(", ") || "No source records"}
                          </code>
                        </details>
                      </div>
                      <time>{date(item.at, true)}</time>
                    </article>
                  ))}
                </section>
              )}
              {tab === "Expenses" && (
                <Expenses snapshot={snapshot} busy={busy} mutate={mutate} />
              )}
              {tab === "MCP" && (
                <McpPanel csrf={auth.csrf ?? ""} onChange={refresh} />
              )}
              <footer className="page-footer">
                <Home size={13} />
                <span>
                  Household records · Approval required for every service plan
                </span>
                <span>Record v{snapshot.revision}</span>
              </footer>
            </main>
            <aside
              ref={assistantRef}
              className="assistant-panel"
              aria-label="HomeOps assistant"
            >
              <div className="assistant-heading">
                <div className="assistant-mark">
                  <Sparkles size={19} />
                </div>
                <div>
                  <strong>HomeOps assistant</strong>
                  <span>
                    <ShieldCheck size={13} /> Your records. Your decisions.
                  </span>
                </div>
                <button
                  className="quiet-button new-conversation"
                  aria-label="Start a new assistant conversation"
                  onClick={() => {
                    localStorage.removeItem("homeops:native:session");
                    setSessionId(undefined);
                    setChatEpoch((value) => value + 1);
                  }}
                >
                  <Plus size={16} /><span>New conversation</span>
                </button>
              </div>

              <AgentChat
                key={`${sessionId ?? "general"}:${chatEpoch}`}
                embedded
                sessionId={sessionId}
                csrf={auth.csrf}
                onSession={(id) =>
                  localStorage.setItem("homeops:native:session", id)
                }
              />
              <div className="assistant-footnote">
                {simulated
                  ? "Demo workspace. Provider interactions are simulated."
                  : "Personal workspace. Provider contact is manual. You contact providers."}
              </div>
            </aside>
          </div>
        </div>
      </div>
      {settings && (
        <div className="modal-backdrop" onClick={() => setSettings(false)}>
          <section
            className="settings-modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="settings-title"
            onClick={(event) => event.stopPropagation()}
            onKeyDown={(event) => {
              if (event.key === "Escape") setSettings(false);
              if (event.key !== "Tab") return;
              trapFocus(event);
            }}
          >
            <div className="section-heading">
              <h2 id="settings-title">
                {simulated ? "Demo settings" : "Appointment preferences"}
              </h2>
              <button
                autoFocus
                className="icon-button"
                aria-label="Close settings"
                onClick={() => setSettings(false)}
              >
                <X size={18} />
              </button>
            </div>
            <p className="empty-text">
              {simulated
                ? "Demo controls change stored records. The same evaluator handles scheduled work."
                : "Save the days and times that work for your household. Edit household records in the Household tab."}
            </p>
            <AppointmentPreferences
              saved={snapshot.schedulingPreferences}
              busy={busy}
              onSave={(preferences) =>
                mutate({ type: "preference.setSchedule", preferences })
              }
            />
            {simulated && selected && (
              <form
                className="settings-row"
                onSubmit={(event) => {
                  event.preventDefault();
                  const amount = Number(
                    new FormData(event.currentTarget).get("budget"),
                  );
                  void mutate({
                    type: "fixture.change",
                    change: {
                      kind: "budget",
                      caseId: selected.id,
                      amount: {
                        minor: Math.round(amount * 100),
                        currency: "INR",
                      },
                    },
                  });
                }}
              >
                <label>
                  Budget for {selected.title}
                  <input
                    name="budget"
                    type="number"
                    min="0"
                    step="1"
                    defaultValue={selected.budget.minor / 100}
                    key={selected.id}
                    required
                  />
                </label>
                <button className="primary-button" disabled={busy}>
                  Save budget
                </button>
              </form>
            )}
            {simulated && (
              <>
                <h3>Provider availability</h3>
                {snapshot.providers.map((provider) => (
                  <label className="provider-setting" key={provider.id}>
                    <span>
                      <strong>{provider.name}</strong>
                      <small>
                        {provider.preferred
                          ? "Preferred provider"
                          : "Alternative provider"}{" "}
                        · Simulated
                      </small>
                    </span>
                    <input
                      type="checkbox"
                      checked={provider.available}
                      disabled={busy}
                      onChange={(event) =>
                        void mutate({
                          type: "fixture.change",
                          change: {
                            kind: "provider",
                            providerId: provider.id,
                            available: event.target.checked,
                          },
                        })
                      }
                    />
                  </label>
                ))}
                <h3>Maintenance policies</h3>
                {snapshot.appliances
                  .filter((item) => item.intervalDays !== null)
                  .map((appliance) => (
                    <form
                      key={appliance.id}
                      className="policy-setting"
                      onSubmit={(event) => {
                        event.preventDefault();
                        void mutate({
                          type: "fixture.change",
                          change: {
                            kind: "policy",
                            applianceId: appliance.id,
                            intervalDays: Number(
                              new FormData(event.currentTarget).get("days"),
                            ),
                          },
                        });
                      }}
                    >
                      <label>
                        {appliance.name}
                        <input
                          aria-label={`${appliance.name} interval in days`}
                          name="days"
                          type="number"
                          min="1"
                          max="3650"
                          defaultValue={appliance.intervalDays ?? ""}
                        />
                      </label>
                      <span>days</span>
                      <button className="quiet-button" disabled={busy}>
                        Save
                      </button>
                    </form>
                  ))}
              </>
            )}
          </section>
        </div>
      )}
    </div>
  );
}

function Login({
  onLogin,
}: {
  onLogin: (auth: { authenticated: boolean; csrf?: string }) => void;
}) {
  const [error, setError] = useState<string>();
  const [busy, setBusy] = useState(false);
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError(undefined);
    const password = new FormData(event.currentTarget).get("password");
    try {
      await request("/api/auth/login", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ password }),
      });
      onLogin(await request("/api/auth/session"));
    } catch (problem) {
      setError(errorText(problem));
    } finally {
      setBusy(false);
    }
  }
  return (
    <main className="login-page">
      <div className="login-art">
        <a className="brand" href="/">
          <HomeMark />
          <span>homeops.</span>
        </a>
        <div>
          <p className="eyebrow">A LITTLE AHEAD OF LIFE</p>
          <h1>
            A home that
            <br />
            remembers.
          </h1>
          <p>
            Service dates. Trusted people. The little things.
            <br />
            Kept in one thoughtful place.
          </p>
          <div className="login-house">
            <Home size={100} strokeWidth={0.8} />
            <Leaf size={44} strokeWidth={1} />
            <Sparkles size={24} />
          </div>
        </div>
        <span>YOUR HOME. IN GOOD HANDS.</span>
      </div>
      <div className="login-form-wrap">
        <form className="login-form" onSubmit={submit}>
          <span className="login-symbol">
            <ShieldCheck size={25} />
          </span>
          <p className="eyebrow">WELCOME HOME</p>
          <h2>Let’s get you settled.</h2>
          <p>Sign in to your local household workspace.</p>
          <label htmlFor="operator-password">Operator password</label>
          <input
            id="operator-password"
            name="password"
            type="password"
            autoComplete="current-password"
            autoFocus
            required
            placeholder="Enter your operator password"
          />
          {error && (
            <p className="login-error" role="alert">
              {error}
            </p>
          )}
          <button className="primary-button" disabled={busy}>
            {busy ? "Signing in…" : "Open my home"}
            <ArrowRight size={17} />
          </button>
          <div className="login-note">
            <ShieldCheck size={16} />A signed local session. Credentials stay on
            this device.
          </div>
        </form>
      </div>
    </main>
  );
}
function Stat({
  label,
  value,
  detail,
  icon,
  accent,
}: {
  label: string;
  value: string;
  detail: string;
  icon: ReactNode;
  accent?: boolean;
}) {
  return (
    <div className={`stat-card ${accent ? "stat-attention" : ""}`}>
      <div>
        <span>{label}</span>
        {icon}
      </div>
      <strong>{value}</strong>
      <p>{detail}</p>
    </div>
  );
}
function HomeMark() {
  return (
    <span className="home-mark">
      <Home size={23} strokeWidth={1.7} />
    </span>
  );
}
function EvidenceView({
  label,
  evidence,
}: {
  label: string;
  evidence: Evidence<string>;
}) {
  return (
    <details className="evidence">
      <summary>
        <span>{label}</span>
        <strong>
          {evidence.value === null ? "Not recorded" : date(evidence.value)}
        </strong>
        {evidence.value === null && <CircleHelp size={12} />}
      </summary>
      <small>
        {evidence.value === null
          ? evidence.reason
          : `Source · ${evidence.sourceId}`}
      </small>
    </details>
  );
}
function Appliance({
  appliance,
  clock,
  activeCase,
  onOpen,
}: {
  appliance: ApplianceCard;
  clock: string;
  activeCase?: CaseCard;
  onOpen: () => void;
}) {
  const Icon = icons[appliance.kind] ?? Home;
  const isDue =
    appliance.nextDue.value !== null &&
    new Date(appliance.nextDue.value) <= new Date(clock);
  return (
    <tr className="appliance-row">
      <td>
        <div className="appliance-identity">
          <span className={`appliance-illustration ${appliance.kind}`}>
            <Icon size={21} strokeWidth={1.5} />
          </span>
          <div>
            <strong>{appliance.name}</strong>
            <span>{appliance.location}</span>
          </div>
        </div>
      </td>
      <td>
        <span className={`status-tag ${activeCase || isDue ? "warm" : ""}`}>
          {activeCase
            ? labels[activeCase.state]
            : isDue
              ? "Due for care"
              : appliance.nextDue.value === null
                ? appliance.intervalDays === null ? "As needed" : "Next care unknown"
                : "On track"}
        </span>
      </td>
      <td>
        <EvidenceView label="Last serviced" evidence={appliance.lastService} />
      </td>
      <td>
        <EvidenceView label="Next care" evidence={appliance.nextDue} />
      </td>
      <td>
        <EvidenceView
          label="Warranty until"
          evidence={appliance.warrantyEnds}
        />
      </td>
      <td>
        <button className="appliance-action" onClick={onOpen}>
          {activeCase
            ? "View care plan"
            : appliance.kind === "sink"
              ? "Report a leak"
              : "View status"}
          <ArrowRight size={13} />
        </button>
      </td>
    </tr>
  );
}
function SinkIncidentFocus({ item, snapshot, onExpenses }: {
  item: CaseCard;
  snapshot: HouseholdSnapshot;
  onExpenses: () => void;
}) {
  const appliance = snapshot.appliances.find((record) => record.id === item.applianceId);
  const history = snapshot.activity.filter((event) => event.caseId === item.id);
  const completion = history.toReversed().find((event) => event.kind === "service.completed");
  const charges = snapshot.expenses.filter((expense) => expense.caseId === item.id);
  const offer = item.offers.find((candidate) => candidate.id === item.approval?.terms.offerId) ??
    item.offers.find((candidate) => candidate.status === "available" && candidate.withinBudget);
  const terms = item.approval?.terms ?? offer?.terms;
  const charge = terms?.charge;
  const arranged = Boolean(item.booking || item.servicePlan?.status === "user_confirmed");
  const completed = item.state === "completed" && Boolean(completion);
  const next = completed ? "Inspection recorded. Keep the repair decision separate."
    : arranged ? "Your next step is to confirm the appointment and record the inspection."
    : item.servicePlan ? "Contact the provider to confirm your approved local plan."
    : item.approval?.status === "pending" ? "Review the exact visit and inspection fee, then decide."
    : item.offers.length ? "Compare the providers below and review a visit."
    : "Find a provider to inspect the leak.";
  return (
    <section className="sink-incident-focus" aria-label="Sink incident decision and record" data-incident-case-id={item.id}>
      <div className="incident-intro">
        <span className="incident-icon"><Droplets size={25} strokeWidth={1.5} /></span>
        <div><p className="eyebrow">{completed ? "INSPECTION RECORD" : "FOCUSED INCIDENT"}</p>
          <h2>{item.title}</h2><p>{item.reason}</p></div>
        <span className={`status-tag ${completed ? "" : "warm"}`}>{labels[item.state]}</span>
      </div>
      <div className="incident-decision">
        <div><span className="eyebrow">{completed ? "WHAT IS RECORDED" : "YOUR NEXT DECISION"}</span><h3>{next}</h3>
          <p>{snapshot.workspace.status === "ready" && snapshot.workspace.providerMode === "simulated" ? "Provider interactions are simulated. " : "Provider contact is manual. "}
            Approval is limited to the displayed quote. An inspection does not authorize unknown repair work.</p></div>
        <div className="incident-fee"><span>{charge?.kind === "inspection" ? "Inspection fee" : charge?.kind === "fixed" ? "Quoted visit" : "Inspection quote"}</span>
          <strong>{charge ? money(charge.kind === "inspection" ? charge.fee : charge.total) : "Not quoted"}</strong>
          <small>{offer?.providerName ?? "Provider not selected"}</small><small>Budget {money(item.budget)}</small></div>
      </div>
      <ol className="incident-progress" aria-label="Recorded incident progress">
        {[
          ["Issue reported", true],
          ["Options received", item.offers.length > 0],
          [item.servicePlan && !arranged ? "Local plan approved" : "Visit arranged", arranged || Boolean(item.servicePlan)],
          ["Inspection recorded", completed],
        ].map(([label, done], index) => <li key={String(label)} className={done ? "recorded" : ""}>
          <span>{done ? <Check size={12} /> : String(index + 1).padStart(2, "0")}</span>{label}
        </li>)}
      </ol>
      <div className="incident-record-grid">
        <div className="incident-memory"><span className="eyebrow">HOUSEHOLD MEMORY</span>
          <p><strong>Last recorded service</strong> {appliance?.lastService.value ? date(appliance.lastService.value) : "Not recorded"}</p>
          <small>{appliance && appliance.lastService.value !== null ? `Source · ${appliance.lastService.sourceId}` : appliance?.lastService.value === null ? appliance.lastService.reason : "No service source available."}</small>
          <p><strong>Final repair cost</strong> Unknown</p>
          <small>Parts and repair work require a separate sourced quote.</small>
        </div>
        <div className="incident-charges"><span className="eyebrow">CONFIRMED INCIDENT CHARGES</span>
          <strong>{money({ minor: charges.reduce((sum, expense) => sum + expense.amount.minor, 0), currency: "INR" })}</strong>
          <p>{charges.length ? `${charges.length} confirmed charge record${charges.length === 1 ? "" : "s"}` : "No confirmed charge recorded. A quote or booking is not an expense."}</p>
          <button type="button" className="text-button" onClick={onExpenses}>Open expense ledger <ArrowRight size={13} /></button>
          {charges.map((expense) => <details key={expense.id}><summary>{expense.description} · {money(expense.amount)}</summary><small>{date(expense.chargedOn)} · {expense.sourceId} · Revision {expense.revision}</small></details>)}
        </div>
      </div>
      <details className="incident-source-history"><summary>Incident activity & sources <span>{history.length} events</span></summary>
        {history.length ? <ol>{history.toReversed().slice(0, 6).map((event) => <li key={event.id}>
          <time>{date(event.at, true)}</time><div><p>{event.summary}</p><small>{event.simulated ? "Simulated · " : ""}{event.kind} · {event.sourceIds.length ? event.sourceIds.join(", ") : "No source reference recorded"}</small></div>
        </li>)}</ol> : <p>No activity event has been recorded for this case.</p>}
      </details>
    </section>
  );
}

function CaseDetail({
  item,
  snapshot,
  onCommand,
  manual,
  completion,
  busy,
  onRequest,
  onDiscuss,
  onChoose,
  onComplete,
  onConfirm,
}: {
  item: CaseCard;
  snapshot: HouseholdSnapshot;
  onCommand: (command: PublicCommand) => Promise<boolean>;
  manual: boolean;
  completion?: ActivityRow;
  busy: boolean;
  onRequest: () => void;
  onDiscuss: () => void;
  onChoose: (
    caseId: string,
    offerId: string,
    revision: number,
  ) => Promise<void>;
  onComplete: () => void;
  onConfirm: (confirmed: boolean) => void;
}) {
  const warrantyWarning = item.purpose === "warranty";
  const inspectionOnly = item.purpose === "urgent" && (
    item.approval?.terms.charge.kind === "inspection" ||
    item.offers.some((offer) => offer.terms?.charge.kind === "inspection")
  );
  return (
    <article className="case-detail">
      <div className="case-heading">
        <span className={`case-symbol ${item.urgent && item.state !== "completed" ? "urgent" : ""}`}>
          <Wrench size={22} />
        </span>
        <div>
          <div className="case-kicker">
            {item.state === "completed" ? inspectionOnly ? "INSPECTION COMPLETE · REPAIR NOT PERFORMED" : "SERVICE RECORDED" : item.urgent ? "URGENT CARE" : "YOUR NEXT STEP"} ·{" "}
            {manual ? "MANUAL SERVICE" : "SIMULATED SERVICE"}
          </div>
          <h3>{item.title}</h3>
          <p>{item.reason}</p>
        </div>
        <span className="status-tag warm">{labels[item.state]}</span>
      </div>
      <div className="case-meta">
        <span>
          <Wallet size={14} />
          Budget <strong>{money(item.budget)}</strong>
        </span>
        <span>
          <ShieldCheck size={14} />
          {manual
            ? "You approve, then contact the provider"
            : "You approve before we book"}
        </span>
      </div>
      {item.offers.length > 0 ? (
        <div className="quote-grid">
          {item.offers.map((offer) => {
            const terms = offer.terms;
            const charge = terms?.charge;
            const amount =
              charge?.kind === "fixed" ? charge.total : charge?.fee;
            const recommended =
              offer.status === "available" && offer.withinBudget === true;
            return (
              <div
                className={`quote-card ${recommended ? "recommended" : ""}`}
                key={offer.id}
              >
                {recommended && (
                  <span className="recommended-label">
                    <Sparkles size={12} />
                    WITHIN YOUR BUDGET
                  </span>
                )}
                <span className="quote-origin">
                  {offer.simulated ? "Simulated quote" : "Entered quote"}
                </span>
                <div className="quote-provider">
                  <strong>{offer.providerName}</strong>
                  {offer.status === "declined" ? (
                    <X size={15} />
                  ) : offer.status === "available" ? (
                    <Check size={15} />
                  ) : null}
                </div>
                <p className="quote-price">
                  {amount ? money(amount) : "Unavailable"}
                  {charge?.kind === "inspection" && (
                    <small>inspection fee</small>
                  )}
                </p>
                <p className="quote-explanation">{offer.explanation}</p>
                {terms?.sourceId && (
                  <p className="quote-source">Source · {terms.sourceId}</p>
                )}
                {terms && (
                  <p className="quote-slot">
                    <CalendarDays size={13} />
                    {date(terms.slot.start, true)}
                    {" to "}
                    {new Intl.DateTimeFormat("en-IN", {
                      hour: "numeric",
                      minute: "2-digit",
                      timeZone: "Asia/Kolkata",
                    }).format(new Date(terms.slot.end))}
                  </p>
                )}
                {charge?.kind === "inspection" && (
                  <p className="unknown-warning">
                    Final repair cost is unknown. Parts are extra.
                  </p>
                )}
                <div className="quote-bottom">
                  <span>
                    {offer.status !== "available"
                      ? offer.status === "declined"
                        ? "Preferred · declined"
                        : "Not available"
                      : offer.withinBudget
                        ? "Within budget"
                        : "Over budget"}
                  </span>
                  {terms && <small>Quote v{offer.revision}</small>}
                </div>
                {offer.status === "available" && terms && (
                  <button
                    className={recommended ? "primary-button" : "quiet-button"}
                    disabled={
                      busy ||
                      offer.withinBudget !== true ||
                      !["requesting_offers", "awaiting_approval"].includes(
                        item.state,
                      ) ||
                      [
                        "booked",
                        "awaiting_completion",
                        "completed",
                        "booking",
                      ].includes(item.state)
                    }
                    onClick={() =>
                      void onChoose(item.id, offer.id, offer.revision)
                    }
                  >
                    {offer.withinBudget === true
                      ? "Review & approve"
                      : "Above budget"}{" "}
                    <ArrowRight size={14} />
                  </button>
                )}
              </div>
            );
          })}
        </div>
      ) : (
        <div className="case-empty">
          <div>
            <strong>
              {warrantyWarning
                ? "Review your warranty."
                : "A little care goes a long way."}
            </strong>
            <p>
              {warrantyWarning
                ? "Check coverage and any missing warranty records with your assistant. This warning does not arrange a service visit."
                : manual
                  ? "Contact a provider and enter their quote with its source. HomeOps will compare it against your budget."
                  : "We’ll check the preferred provider, then compare alternatives against your budget."}
            </p>
          </div>
          {(!manual || warrantyWarning) && (
            <button
              className="primary-button"
              onClick={warrantyWarning ? onDiscuss : onRequest}
              disabled={busy || item.state === "completed"}
            >
              {busy
                ? "Working…"
                : warrantyWarning
                  ? "Review warranty"
                  : "Find service options"}
              <ArrowRight size={15} />
            </button>
          )}
        </div>
      )}
      {manual &&
        !warrantyWarning &&
        ![
          "planned",
          "awaiting_completion",
          "completed",
          "cancelled",
          "denied",
        ].includes(item.state) && (
          <ManualQuoteForm
            key={item.id}
            snapshot={snapshot}
            item={item}
            onCommand={onCommand}
            busy={busy}
          />
        )}
      {item.approval && (
        <div className="approval-summary">
          <ShieldCheck size={17} />
          <div>
            <strong>Approval {item.approval.status}</strong>
            <p>
              {item.approval.status === "invalidated"
                ? "Terms changed. Open the assistant and cancel the outdated request, then review the current quote."
                : item.approval.status === "pending"
                  ? manual
                    ? "Review the exact quote and appointment in your assistant. Approval creates a local plan awaiting your contact."
                    : "Review the exact quote and appointment in your assistant. Booking waits for your decision."
                  : "Your decision is saved against these exact quote terms."}
            </p>
          </div>
          {["pending", "invalidated"].includes(item.approval.status) && (
            <button
              className="quiet-button"
              onClick={onDiscuss}
              disabled={busy}
            >
              {item.approval.status === "invalidated"
                ? "Review changed terms"
                : "Open approval"}{" "}
              <ArrowRight size={14} />
            </button>
          )}
        </div>
      )}
      {item.servicePlan && (
        <ManualPlanConfirmation
          key={item.id}
          item={item}
          onCommand={onCommand}
          busy={busy}
        />
      )}
      {manual && item.state === "completed" && (
        <div className="booking-summary">
          <Check size={22} />
          <div>
            <strong>Service completion recorded</strong>
            <p>
              {completion?.summary ?? "Completion saved in household history."}
            </p>
            {completion && (
              <details>
                <summary>Completion source records</summary>
                <code>{completion.sourceIds.join(", ")}</code>
              </details>
            )}
          </div>
        </div>
      )}
      {manual &&
        item.servicePlan?.status === "user_confirmed" &&
        item.state === "awaiting_completion" && (
          <form
            className="panel completion-form"
            onSubmit={async (event) => {
              event.preventDefault();
              const data = new FormData(event.currentTarget);
              await onCommand({
                type: "case.complete",
                caseId: item.id,
                completedAt: String(data.get("completedAt")),
                sourceId: String(data.get("sourceId")),
              });
            }}
          >
            <h4>Record completed service</h4>
            <label>
              Completion date
              <input
                type="date"
                name="completedAt"
                defaultValue={dayInIndia(snapshot.clock.effectiveNow)}
                required
              />
            </label>
            <label>
              Completion source
              <input
                name="sourceId"
                placeholder="Invoice or service confirmation reference"
                maxLength={160}
                required
              />
            </label>
            <button className="primary-button" disabled={busy}>
              Save completion
            </button>
            <p className="empty-text">
              Record any confirmed charge separately in Expenses.
            </p>
          </form>
        )}
      {item.booking && (
        <div className="booking-summary">
          <Check size={22} />
          <div>
            <strong>
              {item.state === "completed"
                ? inspectionOnly ? "Inspection completion recorded" : "Service completed"
                : item.booking.providerName}{" "}
              ·{" "}
              {item.state === "completed"
                ? item.booking.providerName
                : date(item.booking.start, true)}
            </strong>
            <p>Simulated reservation · {item.booking.receiptId}</p>
            {item.state === "completed" ? (
              <>
                <p>
                  {completion?.summary ??
                    "Completion saved in household history."}
                </p>
                {inspectionOnly && <p className="unknown-warning">The inspection is recorded. Final repair scope and parts cost remain unknown. Any repair needs a separate quote and approval.</p>}
                {completion && (
                  <details>
                    <summary>Completion source records</summary>
                    <code>{completion.sourceIds.join(", ")}</code>
                  </details>
                )}
              </>
            ) : (
              <p>
                {item.booking.confirmed === null
                  ? "Appointment confirmation not recorded."
                  : item.booking.confirmed
                    ? "Appointment confirmed."
                    : "Appointment was not confirmed."}{" "}
                Service is completed separately.
              </p>
            )}
          </div>
        </div>
      )}
      {item.booking && !["completed", "cancelled"].includes(item.state) && (
        <div className="case-actions">
          <button
            className="quiet-button"
            disabled={busy}
            onClick={() => onConfirm(true)}
          >
            Confirm appointment
          </button>
          <button
            className="quiet-button"
            disabled={busy}
            onClick={() => onConfirm(false)}
          >
            Report missed confirmation
          </button>
          <button
            className="primary-button"
            disabled={busy}
            onClick={onComplete}
          >
            {inspectionOnly ? "Mark inspection completed" : "Mark service completed"} <Check size={14} />
          </button>
        </div>
      )}
      <button className="text-button" onClick={onDiscuss} disabled={busy}>
        <MessageCircle size={14} />
        Discuss this with HomeOps
        <ArrowRight size={14} />
      </button>
    </article>
  );
}
function Expenses({
  snapshot,
  busy,
  mutate,
}: {
  snapshot: HouseholdSnapshot;
  busy: boolean;
  mutate: (command: PublicCommand) => Promise<boolean>;
}) {
  const [recording, setRecording] = useState(false);
  const [editing, setEditing] = useState<string>();
  const [formError, setFormError] = useState<string>();
  const [applianceId, setApplianceId] = useState("");
  const [month, setMonth] = useState("");
  const expenses = snapshot.expenses.filter(
    (item) =>
      (!applianceId || item.applianceId === applianceId) &&
      (!month || item.chargedOn.startsWith(month)),
  );
  const total: Money = {
    currency: "INR",
    minor: expenses.reduce((sum, item) => sum + item.amount.minor, 0),
  };
  return (
    <>
      <div className="expense-overview">
        <Stat
          label="CONFIRMED SPENDING"
          value={money(total)}
          detail={`${expenses.length} confirmed charge records · ${month || "All time"}`}
          icon={<Wallet size={20} />}
        />
        <div className="expense-note">
          <ShieldCheck size={25} />
          <div>
            <strong>Quotes aren’t expenses.</strong>
            <p>
              Only confirmed charges count here. Booking a visit never adds to
              your spending.
            </p>
          </div>
          <button
            className="primary-button"
            onClick={() => setRecording(!recording)}
          >
            Record a charge
          </button>
        </div>
      </div>
      {recording && (
        <form
          className="panel expense-form"
          onSubmit={async (event) => {
            event.preventDefault();
            setFormError(undefined);
            const data = new FormData(event.currentTarget);
            const caseId = String(data.get("caseId")) || null;
            const linked = snapshot.cases.find((item) => item.id === caseId);
            const relatedApplianceId =
              linked?.applianceId ?? String(data.get("applianceId"));
            if (!relatedApplianceId) {
              setFormError(
                "Choose an appliance or a case to link this confirmed charge.",
              );
              return;
            }
            if (
              await mutate({
                type: "expense.record",
                charge: {
                  applianceId: relatedApplianceId,
                  caseId,
                  serviceEventId: null,
                  amount: {
                    minor: Math.round(Number(data.get("amount")) * 100),
                    currency: "INR",
                  },
                  chargedOn: String(data.get("date")),
                  description: String(data.get("description")),
                  sourceId: String(data.get("source")),
                },
              })
            )
              setRecording(false);
          }}
        >
          <h3>Record a confirmed charge</h3>
          <label>
            Related case
            <select name="caseId">
              <option value="">No case, historical charge</option>
              {snapshot.cases.map((item) => (
                <option value={item.id} key={item.id}>
                  {item.title}
                </option>
              ))}
            </select>
          </label>
          <label>
            Appliance for a historical charge
            <select name="applianceId">
              <option value="">Choose an appliance</option>
              {snapshot.appliances.map((item) => (
                <option key={item.id} value={item.id}>
                  {item.name}
                </option>
              ))}
            </select>
          </label>
          <label>
            Amount paid (₹)
            <input type="number" name="amount" min="0" step="0.01" required />
          </label>
          <label>
            Date charged
            <input
              type="date"
              name="date"
              defaultValue={dayInIndia(snapshot.clock.effectiveNow)}
              required
            />
          </label>
          <label>
            Description
            <input name="description" maxLength={500} required />
          </label>
          <label>
            Receipt or source reference
            <input
              name="source"
              maxLength={160}
              required
              placeholder="e.g. receipt-2026-001"
            />
          </label>
          {formError && <p role="alert">{formError}</p>}
          <button className="primary-button" disabled={busy}>
            Save confirmed charge
          </button>
        </form>
      )}
      <div
        className="panel expense-filters"
        role="group"
        aria-label="Filter confirmed expenses"
      >
        <label>
          Appliance or service
          <select
            value={applianceId}
            onChange={(event) => setApplianceId(event.target.value)}
          >
            <option value="">All appliances and services</option>
            {snapshot.appliances.map((item) => (
              <option key={item.id} value={item.id}>
                {item.name}
              </option>
            ))}
          </select>
        </label>
        <label>
          Month charged
          <input
            type="month"
            value={month}
            onChange={(event) => setMonth(event.target.value)}
          />
        </label>
        <button
          className="quiet-button"
          onClick={() => {
            setApplianceId("");
            setMonth("");
          }}
          disabled={!applianceId && !month}
        >
          Clear filters
        </button>
      </div>
      <section className="panel expense-list" aria-live="polite">
        {expenses.length === 0 && (
          <p className="empty-text">
            {snapshot.expenses.length === 0
              ? "No confirmed charges yet. Your service quotes stay in the care plan."
              : "No confirmed charges match these filters."}
          </p>
        )}
        {expenses.map((item) => (
          <article key={item.id} className="expense-row">
            <span className="expense-icon">
              <Wallet size={19} />
            </span>
            <div>
              <strong>{item.description}</strong>
              <p>
                {
                  snapshot.appliances.find(
                    (appliance) => appliance.id === item.applianceId,
                  )?.name
                }{" "}
                · {date(item.chargedOn)}
              </p>
              <details>
                <summary>Source & corrections</summary>
                <code>
                  {item.sourceId} · Revision {item.revision}
                </code>
                <button
                  className="text-button"
                  onClick={() =>
                    setEditing(editing === item.id ? undefined : item.id)
                  }
                >
                  Correct this charge
                </button>
                {editing === item.id && (
                  <form
                    className="correction-form"
                    onSubmit={async (event) => {
                      event.preventDefault();
                      const data = new FormData(event.currentTarget);
                      const voiding = data.get("void") === "on";
                      if (
                        await mutate({
                          type: "expense.correct",
                          expenseId: item.id,
                          expectedRevision: item.revision,
                          replacement: voiding
                            ? null
                            : {
                                ...item,
                                amount: {
                                  minor: Math.round(
                                    Number(data.get("amount")) * 100,
                                  ),
                                  currency: "INR",
                                },
                              },
                          reason: String(data.get("reason")),
                        })
                      )
                        setEditing(undefined);
                    }}
                  >
                    <label>
                      Correct amount (₹)
                      <input
                        name="amount"
                        type="number"
                        step="0.01"
                        min="0"
                        defaultValue={item.amount.minor / 100}
                        required
                      />
                    </label>
                    <label>
                      Reason
                      <input name="reason" maxLength={500} required />
                    </label>
                    <label className="checkbox-label">
                      <input name="void" type="checkbox" />
                      Void this charge instead
                    </label>
                    <button className="quiet-button" disabled={busy}>
                      Save correction
                    </button>
                  </form>
                )}
              </details>
            </div>
            <strong>{money(item.amount)}</strong>
          </article>
        ))}
      </section>
    </>
  );
}
function errorText(problem: unknown) {
  return problem instanceof Error
    ? problem.message
    : "Something went wrong. Please try again.";
}
function trapFocus(event: KeyboardEvent<HTMLElement>) {
  const controls = Array.from(
    event.currentTarget.querySelectorAll<HTMLElement>(
      "button:not(:disabled), input:not(:disabled), select:not(:disabled), textarea:not(:disabled), a[href], [tabindex='0']",
    ),
  ).filter((element) => element.getClientRects().length > 0);
  const first = controls[0];
  const last = controls.at(-1);
  if (event.shiftKey && document.activeElement === first) {
    event.preventDefault();
    last?.focus();
  } else if (!event.shiftKey && document.activeElement === last) {
    event.preventDefault();
    first?.focus();
  }
}
