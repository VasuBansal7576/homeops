import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type FormEvent,
} from "react";
import {
  ArrowRight,
  Check,
  LoaderCircle,
  Plug,
  RefreshCw,
  ShieldCheck,
  Terminal,
} from "lucide-react";

type InputRequest = {
  requestId: string;
  prompt: string;
  kind: string;
  allowFreeform?: boolean;
  options?: {
    id: string;
    label: string;
    style?: string;
    description?: string;
  }[];
};
type Invocation = {
  invocationId: string;
  status:
    | "working"
    | "input_required"
    | "authorization_required"
    | "completed"
    | "failed"
    | "cancelled";
  pollAfterMs?: number;
  inputRequests?: Record<string, InputRequest>;
  result?: unknown;
  error?: { message: string };
  authorizations?: {
    description: string;
    authorization?: { url?: string; userCode?: string; instructions?: string };
  }[];
};
type Receipt = {
  id: number;
  method: string;
  at: string;
  status: "ok" | "error";
  body: unknown;
};
type Tool = { name: string; description?: string };
type RpcEnvelope = {
  result?: Record<string, unknown>;
  error?: { message: string };
};
const storageKey = "homeops:mcp:invocation";
const ambiguousKey = "homeops:mcp:ambiguous-start";
const nextPollKey = "homeops:mcp:next-poll-at";
const maxReadFailures = 3;

export function McpPanel({
  csrf,
  onChange,
}: {
  csrf: string;
  onChange: () => Promise<void>;
}) {
  const [version, setVersion] = useState<string>();
  const [tools, setTools] = useState<Tool[]>([]);
  const [receipts, setReceipts] = useState<Receipt[]>([]);
  const [invocation, setInvocation] = useState<Invocation>();
  const [savedId, setSavedId] = useState<string>();
  const [ambiguous, setAmbiguous] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string>();
  const [readError, setReadError] = useState<string>();
  const [readFailures, setReadFailures] = useState(0);
  const [answers, setAnswers] = useState<
    Record<string, { optionId?: string; text?: string }>
  >({});
  const sequence = useRef(0);
  const nextPollAt = useRef(0);
  const mounted = useRef(true);
  useEffect(() => {
    mounted.current = true;
    setSavedId(localStorage.getItem(storageKey) ?? undefined);
    setAmbiguous(localStorage.getItem(ambiguousKey) === "true");
    nextPollAt.current = Number(localStorage.getItem(nextPollKey)) || 0;
    return () => {
      mounted.current = false;
    };
  }, []);
  const rpc = useCallback(
    async (
      method: string,
      params: Record<string, unknown> = {},
      notification = false,
    ): Promise<Record<string, unknown>> => {
      const id = ++sequence.current;
      try {
        const response = await fetch("/eve/v1/mcp", {
          method: "POST",
          headers: {
            accept: "application/json, text/event-stream",
            "content-type": "application/json",
            "mcp-protocol-version": "2025-11-25",
            "x-homeops-csrf": csrf,
          },
          body: JSON.stringify({
            jsonrpc: "2.0",
            ...(notification ? {} : { id }),
            method,
            params,
          }),
        });
        if (!response.ok)
          throw new Error(`MCP ${method} returned HTTP ${response.status}.`);
        const body = await response.text();
        if (notification && !body.trim()) {
          setReceipts((items) =>
            [
              {
                id,
                method,
                at: new Date().toISOString(),
                status: "ok" as const,
                body: { accepted: response.status },
              },
              ...items,
            ].slice(0, 40),
          );
          return {};
        }
        const messages = response.headers
          .get("content-type")
          ?.includes("text/event-stream")
          ? body.split(/\r?\n\r?\n/).flatMap((event) => {
              const data = event
                .split(/\r?\n/)
                .filter((line) => line.startsWith("data:"))
                .map((line) => line.slice(5).trim())
                .join("\n");
              if (!data) return [];
              try {
                return [JSON.parse(data) as RpcEnvelope & { id?: number }];
              } catch {
                return [];
              }
            })
          : [JSON.parse(body) as RpcEnvelope & { id?: number }];
        const envelope =
          messages.find((message) => message.id === id) ?? messages.at(-1);
        if (!envelope)
          throw new Error("The MCP endpoint returned no JSON-RPC response.");
        if (envelope.error) throw new Error(envelope.error.message);
        const result = envelope.result ?? {};
        setReceipts((items) =>
          [
            {
              id,
              method: method === "tools/call" ? String(params.name) : method,
              at: new Date().toISOString(),
              status: "ok" as const,
              body: result,
            },
            ...items,
          ].slice(0, 40),
        );
        if (result.isError) {
          const structured = result.structuredContent as
            { error?: { message?: string } } | undefined;
          throw new Error(
            structured?.error?.message ?? "The MCP tool rejected this request.",
          );
        }
        return result;
      } catch (problem) {
        const message =
          problem instanceof Error ? problem.message : "MCP request failed.";
        setReceipts((items) =>
          [
            {
              id,
              method,
              at: new Date().toISOString(),
              status: "error" as const,
              body: { error: message },
            },
            ...items,
          ].slice(0, 40),
        );
        throw problem;
      }
    },
    [csrf],
  );
  const acceptInvocation = useCallback(
    (result: Record<string, unknown>) => {
      let value = result.structuredContent as Invocation | undefined;
      if (!value && Array.isArray(result.content)) {
        const block = (
          result.content as { type: string; text?: string }[]
        ).find((item) => item.type === "text" && item.text);
        if (block?.text) value = JSON.parse(block.text) as Invocation;
      }
      if (!value?.invocationId || !value.status)
        throw new Error(
          "The MCP tool returned no invocation identity. Inspect its receipt before continuing.",
        );
      localStorage.setItem(storageKey, value.invocationId);
      localStorage.removeItem(ambiguousKey);
      nextPollAt.current =
        Date.now() + Math.max(1000, value.pollAfterMs ?? 2000);
      localStorage.setItem(nextPollKey, String(nextPollAt.current));
      if (mounted.current) {
        setInvocation(value);
        setSavedId(value.invocationId);
        setAmbiguous(false);
        setAnswers({});
        setReadError(undefined);
        setReadFailures(0);
      }
      void onChange();
    },
    [onChange],
  );
  const get = useCallback(
    async (id: string) => {
      acceptInvocation(
        await rpc("tools/call", {
          name: "agent_get",
          arguments: { invocationId: id },
        }),
      );
    },
    [acceptInvocation, rpc],
  );
  useEffect(() => {
    if (
      !version ||
      !savedId ||
      busy ||
      readFailures >= maxReadFailures ||
      (invocation &&
        !["working", "authorization_required"].includes(invocation.status))
    )
      return;
    const timer = window.setTimeout(
      () => {
        void get(savedId).catch((problem) => {
          if (!mounted.current) return;
          setReadError(
            problem instanceof Error
              ? problem.message
              : "Could not read invocation.",
          );
          nextPollAt.current = Date.now() + 2000 * 2 ** readFailures;
          localStorage.setItem(nextPollKey, String(nextPollAt.current));
          setReadFailures((count) => count + 1);
        });
      },
      Math.max(0, nextPollAt.current - Date.now()),
    );
    return () => window.clearTimeout(timer);
  }, [version, savedId, invocation, get, busy, readFailures]);
  const run = async (action: () => Promise<void>) => {
    setBusy(true);
    setError(undefined);
    try {
      await action();
    } catch (problem) {
      setError(
        problem instanceof Error ? problem.message : "MCP request failed.",
      );
    } finally {
      setBusy(false);
    }
  };
  const readCurrent = () => {
    if (!savedId) return;
    setReadFailures(0);
    void run(async () => {
      try {
        await get(savedId);
      } catch (problem) {
        setReadError(
          problem instanceof Error
            ? problem.message
            : "Could not read invocation.",
        );
        nextPollAt.current = Date.now() + 2000;
        localStorage.setItem(nextPollKey, String(nextPollAt.current));
        setReadFailures(1);
      }
    });
  };
  const connect = () =>
    void run(async () => {
      const result = await rpc("initialize", {
        protocolVersion: "2025-11-25",
        capabilities: {},
        clientInfo: { name: "homeops-web", version: "1.0.0" },
      });
      const negotiated = String(result.protocolVersion ?? "unknown");
      if (negotiated !== "2025-11-25")
        throw new Error(`Unexpected negotiated protocol ${negotiated}.`);
      await rpc("notifications/initialized", {}, true);
      const listing = await rpc("tools/list");
      setTools(Array.isArray(listing.tools) ? (listing.tools as Tool[]) : []);
      setVersion(negotiated);
      setReadFailures(0);
      setReadError(undefined);
    });
  const start = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!canStart) return;
    const message = String(new FormData(event.currentTarget).get("message"));
    void run(async () => {
      localStorage.setItem(ambiguousKey, "true");
      localStorage.removeItem(storageKey);
      localStorage.removeItem(nextPollKey);
      setSavedId(undefined);
      setInvocation(undefined);
      setAmbiguous(true);
      const result = await rpc("tools/call", {
        name: "agent_start",
        arguments: { message },
      });
      acceptInvocation(result);
    });
  };
  const inputs = Object.values(invocation?.inputRequests ?? {});
  const canStart =
    !busy &&
    !ambiguous &&
    (!invocation ||
      ["completed", "failed", "cancelled"].includes(invocation.status)) &&
    (!savedId || !!invocation);
  return (
    <div className="mcp-console">
      <section className="panel mcp-connect">
        <span className="mcp-logo">
          <Plug size={25} />
        </span>
        <div>
          <h2>Streamable HTTP</h2>
          <p>
            Authenticated same-origin endpoint <code>/eve/v1/mcp</code>
          </p>
          <span className={`status-tag ${version ? "" : "warm"}`}>
            {version ? `Connected · ${version}` : "Not connected"}
          </span>
        </div>
        <button className="primary-button" onClick={connect} disabled={busy}>
          {busy ? (
            <LoaderCircle className="spin" size={15} />
          ) : version ? (
            <RefreshCw size={15} />
          ) : (
            <Plug size={15} />
          )}
          {version ? "Reconnect" : "Connect & list tools"}
        </button>
      </section>
      {error && (
        <div className="error-banner" role="alert">
          {error}
        </div>
      )}
      {readError && (
        <div className="error-banner" role="alert">
          <span>
            Could not read the saved journey. {readError}{" "}
            {readFailures >= maxReadFailures
              ? "Automatic reads paused after three failed attempts."
              : !invocation ||
                  ["working", "authorization_required"].includes(
                    invocation.status,
                  )
                ? "Retrying the same invocation automatically."
                : "Use Resume reads to check this invocation again."}
          </span>
          <button disabled={busy || !savedId} onClick={readCurrent}>
            Resume reads
          </button>
        </div>
      )}
      {version && (
        <>
          <section className="panel">
            <div className="section-heading">
              <h2>Published tools</h2>
              <span>{tools.length} discovered</span>
            </div>
            <div className="mcp-tools">
              {tools.map((tool) => (
                <details key={tool.name}>
                  <summary>
                    <Terminal size={13} />
                    <code>{tool.name}</code>
                  </summary>
                  <p>{tool.description ?? "No description published."}</p>
                </details>
              ))}
            </div>
          </section>
          <section className="panel mcp-invocation">
            <div className="section-heading">
              <h2>Durable agent journey</h2>
              {invocation && (
                <span className="status-tag warm">
                  {invocation.status.replaceAll("_", " ")}
                </span>
              )}
            </div>
            <p className="empty-text">
              MCP calls below invoke Eve directly. This console and the
              assistant use the same household records through separate
              transports.
            </p>
            {savedId && (
              <div className="invocation-identity">
                <span>Saved invocation</span>
                <code>{savedId}</code>
                <button
                  className="quiet-button"
                  disabled={busy}
                  onClick={readCurrent}
                >
                  Read current state
                </button>
              </div>
            )}
            {ambiguous && (
              <div className="unknown-warning">
                <strong>Start response is unresolved.</strong>
                <p>
                  A task may already be running. Starting again could create a
                  duplicate. Reconcile the invocation from server evidence, then
                  enter its ID below.
                </p>
              </div>
            )}
            <details className="mcp-attach" open={ambiguous || undefined}>
              <summary>Attach a known invocation</summary>
              <p className="empty-text">
                Read an existing journey by its invocation ID. This does not
                start a new task.
              </p>
              <form
                onSubmit={(event) => {
                  event.preventDefault();
                  const id = String(
                    new FormData(event.currentTarget).get("invocationId"),
                  ).trim();
                  void run(() => get(id));
                }}
              >
                <label>
                  Known invocation ID
                  <input name="invocationId" required />
                </label>
                <button className="quiet-button" disabled={busy}>
                  Attach & read
                </button>
              </form>
            </details>
            {invocation?.status === "input_required" && (
              <form
                className="mcp-approval"
                onSubmit={(event) => {
                  event.preventDefault();
                  void run(async () =>
                    acceptInvocation(
                      await rpc("tools/call", {
                        name: "agent_update",
                        arguments: {
                          invocationId: invocation.invocationId,
                          responses: inputs.map((input) => ({
                            requestId: input.requestId,
                            ...answers[input.requestId],
                          })),
                        },
                      }),
                    ),
                  );
                }}
              >
                <div className="approval-banner">
                  <ShieldCheck size={19} />
                  <strong>Your decision is needed</strong>
                </div>
                {inputs.map((input) => (
                  <fieldset key={input.requestId}>
                    <legend>{input.prompt}</legend>
                    {input.options?.map((option) => (
                      <label
                        className={`mcp-option ${option.style === "danger" ? "danger" : ""}`}
                        key={option.id}
                      >
                        <input
                          type="radio"
                          name={input.requestId}
                          required={!input.allowFreeform}
                          checked={
                            answers[input.requestId]?.optionId === option.id
                          }
                          onChange={() =>
                            setAnswers((previous) => ({
                              ...previous,
                              [input.requestId]: { optionId: option.id },
                            }))
                          }
                        />
                        <span>
                          <strong>{option.label}</strong>
                          {option.description && (
                            <small>{option.description}</small>
                          )}
                        </span>
                      </label>
                    ))}
                    {(input.allowFreeform || !input.options?.length) && (
                      <label>
                        Your answer
                        <input
                          value={answers[input.requestId]?.text ?? ""}
                          required={!input.options?.length}
                          onChange={(event) =>
                            setAnswers((previous) => ({
                              ...previous,
                              [input.requestId]: { text: event.target.value },
                            }))
                          }
                        />
                      </label>
                    )}
                  </fieldset>
                ))}
                <button
                  className="primary-button"
                  disabled={
                    busy ||
                    inputs.some(
                      (input) =>
                        !answers[input.requestId]?.optionId &&
                        !answers[input.requestId]?.text?.trim(),
                    )
                  }
                >
                  Send complete decision batch
                  <ArrowRight size={15} />
                </button>
              </form>
            )}
            {invocation?.status === "authorization_required" &&
              invocation.authorizations?.map((item, index) => (
                <div className="unknown-warning" key={index}>
                  <strong>{item.description}</strong>
                  <p>{item.authorization?.instructions}</p>
                  {item.authorization?.url && (
                    <a
                      href={item.authorization.url}
                      target="_blank"
                      rel="noreferrer"
                    >
                      Continue authorization
                    </a>
                  )}
                  {item.authorization?.userCode && (
                    <code>{item.authorization.userCode}</code>
                  )}
                </div>
              ))}
            {invocation?.result !== undefined && (
              <div className="mcp-result">
                <span>Agent result</span>
                {typeof invocation.result === "string" ? (
                  <p>{invocation.result}</p>
                ) : (
                  <pre>{JSON.stringify(invocation.result, null, 2)}</pre>
                )}
              </div>
            )}
            {invocation?.error && (
              <div className="error-banner" role="alert">
                {invocation.error.message}
              </div>
            )}
            <form onSubmit={start} className="mcp-start">
              <label htmlFor="mcp-message">Ask the agent via MCP</label>
              <textarea
                id="mcp-message"
                name="message"
                rows={3}
                required
                maxLength={16000}
                placeholder="What needs attention at home? Use household records and ask before booking."
              />
              <button className="primary-button" disabled={!canStart}>
                Start durable work
                <ArrowRight size={15} />
              </button>
            </form>
            {invocation &&
              ["working", "authorization_required"].includes(
                invocation.status,
              ) && (
                <button
                  className="text-button"
                  disabled={busy}
                  onClick={() =>
                    void run(async () =>
                      acceptInvocation(
                        await rpc("tools/call", {
                          name: "agent_cancel",
                          arguments: { invocationId: invocation.invocationId },
                        }),
                      ),
                    )
                  }
                >
                  Request cancellation
                </button>
              )}
          </section>
        </>
      )}
      <section className="panel mcp-receipts">
        <div className="section-heading">
          <h2>Protocol receipts</h2>
          <span>Actual responses · current connection</span>
        </div>
        {receipts.length === 0 && (
          <p className="empty-text">
            Connect to capture the initialize, initialized and tools/list
            exchanges.
          </p>
        )}
        {receipts.map((receipt) => (
          <details key={`${receipt.id}-${receipt.status}`}>
            <summary>
              <span
                className={
                  receipt.status === "ok" ? "receipt-ok" : "receipt-error"
                }
              >
                {receipt.status === "ok" ? <Check size={13} /> : "!"}
              </span>
              <code>{receipt.method}</code>
              <time>{new Date(receipt.at).toLocaleTimeString()}</time>
            </summary>
            <pre>{JSON.stringify(receipt.body, null, 2)}</pre>
          </details>
        ))}
      </section>
    </div>
  );
}
