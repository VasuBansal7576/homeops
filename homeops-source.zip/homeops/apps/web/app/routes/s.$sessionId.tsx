import { createFileRoute } from "@tanstack/react-router";
import { HomeOps } from "@/app/_components/homeops";

export const Route = createFileRoute("/s/$sessionId")({
  component: SessionPage,
});

function SessionPage() {
  const { sessionId } = Route.useParams();
  return <HomeOps initialSessionId={sessionId} />;
}
