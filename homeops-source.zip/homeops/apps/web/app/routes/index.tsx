import { createFileRoute } from "@tanstack/react-router";
import { HomeOps } from "@/app/_components/homeops";

export const Route = createFileRoute("/")({
  component: HomeOps,
});
