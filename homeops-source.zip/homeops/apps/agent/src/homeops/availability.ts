import type { AvailabilityPreferences, QuoteTerms } from '../../../../packages/contracts/src/index.ts';

const hour = 3600000;
const day = 24 * hour;
const indiaOffset = 19800000;
const minutes = (value: string) => Number(value.slice(0, 2)) * 60 + Number(value.slice(3));
const localMidnight = (instant: number) => Math.floor((instant + indiaOffset) / day) * day - indiaOffset;
const isoWeekday = (instant: number) => new Date(instant + indiaOffset).getUTCDay() || 7;

export function allowsSlot(preferences: AvailabilityPreferences, slot: QuoteTerms['slot']): boolean {
  const start = Date.parse(slot.start); const end = Date.parse(slot.end);
  const midnight = localMidnight(start);
  return Number.isFinite(start) && Number.isFinite(end) && end - start === hour
    && preferences.daysOfWeek.includes(isoWeekday(start))
    && start >= midnight + minutes(preferences.startTime) * 60000
    && end <= midnight + minutes(preferences.endTime) * 60000;
}

export function earliestSlot(preferences: AvailabilityPreferences, now: string, urgent: boolean): QuoteTerms['slot'] | null {
  const instant = Date.parse(now);
  const earliest = urgent ? instant + 2 * hour : localMidnight(instant) + day;
  const firstDay = localMidnight(earliest);
  for (let offset = 0; offset < 14; offset++) {
    const midnight = firstDay + offset * day;
    if (!preferences.daysOfWeek.includes(isoWeekday(midnight))) continue;
    const start = Math.max(earliest, midnight + minutes(preferences.startTime) * 60000);
    const slot = { start: new Date(start).toISOString(), end: new Date(start + hour).toISOString() };
    if (allowsSlot(preferences, slot)) return slot;
  }
  return null;
}
