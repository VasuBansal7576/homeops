import { DatabaseSync } from 'node:sqlite';
import { createHash, randomUUID } from 'node:crypto';
import { mkdirSync } from 'node:fs';
import { dirname } from 'node:path';
import { PublicCommandSchema, HouseholdDatasetSchema, DEFAULT_AVAILABILITY_PREFERENCES, type HouseholdDataset, type WorkspaceInfo, type ApplianceInput, type ProviderInput, type ManualServicePlan, type AvailabilityPreferences, type PublicCommand, type HouseholdSnapshot, type CaseState, type CaseCard, type QuoteTerms, type ApprovalCard, type OfferCard, type CommandResult, type ExpenseRow, type Money, type ActivityRow, type InboxItem } from '../../../../packages/contracts/src/index.ts';
import { allowsSlot, earliestSlot } from './availability.ts';

export type Actor = { principalId: string; role: 'operator' | 'scheduler' };
export type HomeCommand = { id: string } & (PublicCommand | { type: 'work.tick' } | { type: 'case.book'; caseId: string; approvalId: string });
type Appliance = { id: string; name: string; kind: ApplianceInput['kind']; revision?: number; location: string; serviceSourceId: string | null };
type ServiceEvent = { id: string; applianceId: string; performedOn: string; sourceId: string; caseId: string | null };
type Case = Omit<CaseCard, 'offers' | 'approval' | 'booking' | 'servicePlan' | 'purpose'> & { approvalId: string | null; cycle: string; purpose?: 'maintenance' | 'warranty' | 'urgent' };
type Approval = ApprovalCard & { requesterId: string; responderId: string | null; callId: string | null; settledAt: string | null };
type Provider = { id: string; name: string; preferred: boolean; available: boolean; declines: boolean; amount: number; serviceKind?: Appliance['kind']; revision?: number; contactNote?: string | null };
export type DueJob = { id: string; caseId: string; address: string; status: 'pending' | 'claimed' | 'dispatched' | 'superseded'; owner: string | null; leaseUntil: number | null; sessionId: string | null; kind?: 'maintenance' | 'warranty' | 'confirmation' | 'urgent'; inboxId?: string };
type Receipt = NonNullable<CaseCard['booking']> & { caseId: string; approvalId: string };
type MemoryDocument = { content: string; version: number };
const money = (minor: number): Money => ({ minor, currency: 'INR' });
const addDays = (day: string, n: number) => new Date(Date.parse(`${day}T00:00:00Z`) + n * 86400000).toISOString().slice(0, 10);
const dayInIndia = (instant: string) => new Date(Date.parse(instant) + 19800000).toISOString().slice(0, 10);
const canonical = (value: unknown): unknown => Array.isArray(value) ? value.map(canonical) : value && typeof value === 'object' ? Object.fromEntries(Object.entries(value).sort(([a], [b]) => a.localeCompare(b)).map(([k, v]) => [k, canonical(v)])) : value;
const hash = (value: unknown) => createHash('sha256').update(JSON.stringify(canonical(value))).digest('hex');
const amount = (terms: QuoteTerms) => terms.charge.kind === 'fixed' ? terms.charge.total.minor : terms.charge.fee.minor;
const terminal = new Set<CaseState>(['completed', 'denied', 'cancelled']);
const transitions: Record<CaseState, readonly CaseState[]> = {
  due: ['requesting_offers', 'cancelled'], requesting_offers: ['awaiting_approval', 'unavailable', 'cancelled'],
  awaiting_approval: ['awaiting_approval', 'requesting_offers', 'booking', 'denied', 'cancelled'],
  booking: ['booked', 'planned', 'failed'], planned: ['awaiting_completion', 'cancelled'], booked: ['awaiting_completion', 'completed', 'cancelled'],
  awaiting_completion: ['completed', 'cancelled'], completed: [], denied: [], unavailable: ['requesting_offers', 'cancelled'],
  cancelled: [], failed: ['booking', 'requesting_offers', 'cancelled'],
};
export class HomeOpsError extends Error {
  constructor(public code: string, message: string, public retryable = false) { super(message); this.name = 'HomeOpsError'; }
}
export class MemoryDocumentConflictError extends Error { constructor() { super('Memory document version conflict'); this.name = 'MemoryDocumentConflictError'; } }

export function openHomeOps(options: { filename: string; faultAfterProviderAcceptance?: () => void; initialDataset?: HouseholdDataset }) {
  if (options.filename !== ':memory:') mkdirSync(dirname(options.filename), { recursive: true });
  const db = new DatabaseSync(options.filename);
  db.exec('PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;');
  const tables = ['households', 'appliances', 'policies', 'service_events', 'warranties', 'providers', 'cases', 'offers', 'approvals', 'bookings', 'due_jobs', 'inbox', 'activity', 'expenses', 'expense_corrections', 'preferences', 'memory_documents', 'provider_operations', 'command_receipts', 'service_plans', 'meta'];
  for (const table of tables) db.exec(`CREATE TABLE IF NOT EXISTS ${table} (id TEXT PRIMARY KEY, data TEXT NOT NULL)`);
  db.exec("CREATE UNIQUE INDEX IF NOT EXISTS one_provider_booking_per_case ON provider_operations(json_extract(data,'$.caseId')); CREATE INDEX IF NOT EXISTS case_appliance ON cases(json_extract(data,'$.applianceId')); CREATE INDEX IF NOT EXISTS due_status ON due_jobs(json_extract(data,'$.status'));");
  function get<T>(table: string, id: string): T | undefined { const row = db.prepare(`SELECT data FROM ${table} WHERE id=?`).get(id); return row ? JSON.parse(String(row.data)) as T : undefined; }
  function all<T>(table: string): T[] { return db.prepare(`SELECT data FROM ${table} ORDER BY rowid`).all().map(row => JSON.parse(String(row.data)) as T); }
  function put(table: string, id: string, value: unknown) { db.prepare(`INSERT INTO ${table}(id,data) VALUES (?,?) ON CONFLICT(id) DO UPDATE SET data=excluded.data`).run(id, JSON.stringify(value)); }
  function required<T>(table: string, id: string): T { const row = get<T>(table, id); if (row === undefined) throw new HomeOpsError('not_found', `${table} record ${id} not found`); return row; }
  function transaction<T>(fn: () => T): T { db.exec('BEGIN IMMEDIATE'); try { const value = fn(); db.exec('COMMIT'); return value; } catch (error) { db.exec('ROLLBACK'); throw error; } }
  const workspace = () => required<WorkspaceInfo>('meta', 'workspace');
  const household = () => all<HouseholdSnapshot['household']>('households')[0]!;
  const manual = () => { const state = workspace(); return state.status === 'ready' && state.providerMode === 'manual'; };
  const now = () => new Date(Date.now() + required<number>('meta', 'clockOffset')).toISOString();
  const revision = () => required<number>('meta', 'revision');
  const schedulingPreferences = () => required<AvailabilityPreferences>('meta', 'schedulingPreferences');
  const bump = () => { const next = revision() + 1; put('meta', 'revision', next); return next; };
  function authorize(actor: Actor, operatorOnly = false) { if (!actor?.principalId || !['operator', 'scheduler'].includes(actor.role) || (operatorOnly && actor.role !== 'operator')) throw new HomeOpsError('unauthorized', 'Unauthorized actor'); }
  function activity(caseId: string | null, kind: string, summary: string, sourceIds: string[] = [], simulated = false) { const id = randomUUID(); put('activity', id, { id, caseId, kind, summary, at: now(), sourceIds, simulated } satisfies ActivityRow); }
  function transition(c: Case, state: CaseState) { if (c.state !== state && !transitions[c.state].includes(state)) throw new HomeOpsError('conflict', `Cannot move case from ${c.state} to ${state}`); c.state = state; put('cases', c.id, c); }
  function nextDue(a: Appliance) { const event = a.serviceSourceId ? required<ServiceEvent>('service_events', a.serviceSourceId) : null; const policy = get<{ intervalDays: number }>('policies', a.id); return event && policy ? addDays(event.performedOn, policy.intervalDays) : null; }
  function invalidate(c: Case, reason: string) { if (!c.approvalId) return; const approval = required<Approval>('approvals', c.approvalId); if (['pending', 'approved'].includes(approval.status)) { approval.status = 'invalidated'; put('approvals', approval.id, approval); if (c.state === 'awaiting_approval') transition(c, 'requesting_offers'); activity(c.id, 'approval.invalidated', reason, [approval.id]); } }
  function notify(c: Case, key: string, kind: NonNullable<DueJob['kind']>, title: string, body: string) {
    const inboxId = `inbox:${key}`; const jobId = `job:${key}`;
    if (get('inbox', inboxId)) return;
    put('inbox', inboxId, { id: inboxId, caseId: c.id, title, body, createdAt: now(), readAt: null, sessionId: null } satisfies InboxItem);
    put('due_jobs', jobId, { id: jobId, caseId: c.id, address: `homeops:${key}`, status: 'pending', owner: null, leaseUntil: null, sessionId: null, kind, inboxId } satisfies DueJob);
  }
  function supersedeJobs(caseId: string, kind?: DueJob['kind']) {
    for (const job of all<DueJob>('due_jobs').filter(j => j.caseId === caseId && (!kind || j.kind === kind) && j.status !== 'dispatched')) { job.status = 'superseded'; put('due_jobs', job.id, job); }
  }
  function evaluate() {
    const day = dayInIndia(now());
    for (const a of all<Appliance>('appliances')) {
      const due = nextDue(a); const cycle = `${a.id}:${a.serviceSourceId}:${get<{ intervalDays: number }>('policies', a.id)?.intervalDays}`;
      for (const c of all<Case>('cases').filter(c => c.applianceId === a.id && (!c.purpose || c.purpose === 'maintenance') && !terminal.has(c.state) && !['booking', 'booked', 'planned', 'awaiting_completion'].includes(c.state))) {
        if (c.cycle !== cycle || !due || due > day) {
          invalidate(c, 'Service history or maintenance policy changed.'); transition(c, 'cancelled');
          supersedeJobs(c.id);
        }
      }
      if (!due || due > day || all<Case>('cases').some(c => c.applianceId === a.id && (!c.purpose || c.purpose === 'maintenance') && (!terminal.has(c.state) || (c.cycle === cycle && c.state !== 'cancelled')))) continue;
      const generation = all<Case>('cases').filter(c => c.cycle === cycle).length + 1;
      const id = `case:${hash(cycle).slice(0, 20)}:${generation}`;
      const c: Case = { id, applianceId: a.id, title: a.kind === 'purifier' ? `${a.name} filter replacement` : a.kind === 'garden' ? `${a.name} recurring care` : `${a.name} maintenance`, reason: `Due ${due} from service history and ${get<{ intervalDays: number }>('policies', a.id)!.intervalDays}-day saved policy.`, state: 'due', budget: household().budget, urgent: false, sessionId: null, approvalId: null, cycle, purpose: 'maintenance' };
      put('cases', id, c);
      notify(c, id, 'maintenance', c.title, c.reason);
      activity(id, 'maintenance.due', c.reason, [a.serviceSourceId!, required<ServiceEvent>('service_events', a.serviceSourceId!).sourceId, get<{ sourceId?: string }>('policies', a.id)?.sourceId ?? `policy:${a.id}`]);
    }
    for (const a of all<Appliance>('appliances')) {
      const warranty = get<{ ends: string; sourceId: string; terms: string }>('warranties', a.id);
      if (!warranty) { for (const previous of all<Case>('cases').filter(c => c.applianceId === a.id && c.purpose === 'warranty' && !terminal.has(c.state))) { invalidate(previous, 'Warranty evidence removed.'); transition(previous, 'cancelled'); supersedeJobs(previous.id); } continue; }
      for (const previous of all<Case>('cases').filter(c => c.applianceId === a.id && c.purpose === 'warranty' && c.cycle !== `warranty:${a.id}:${warranty.sourceId}:${warranty.ends}` && !terminal.has(c.state))) { invalidate(previous, 'Warranty evidence changed.'); transition(previous, 'cancelled'); supersedeJobs(previous.id); }
      const cycle = `warranty:${a.id}:${warranty.sourceId}:${warranty.ends}`;
      const id = `case:${hash(cycle).slice(0, 20)}:warranty`; const previous = all<Case>('cases').filter(c => c.cycle === cycle);
      if (day < addDays(warranty.ends, -household().warrantyNoticeDays)) {
        for (const c of previous.filter(c => !terminal.has(c.state))) { transition(c, 'cancelled'); supersedeJobs(c.id); }
        continue;
      }
      if (previous.some(c => c.state !== 'cancelled')) continue;
      const caseId = previous.length ? `${id}:${previous.length + 1}` : id;
      const c: Case = { id: caseId, applianceId: a.id, title: `${a.name} warranty expiry`, reason: `Stored warranty ends ${warranty.ends}. ${warranty.terms} Coverage for any specific fault is unverified. Check the warranty document before arranging service.`, state: 'due', budget: household().budget, urgent: false, sessionId: null, approvalId: null, cycle, purpose: 'warranty' };
      put('cases', caseId, c); notify(c, caseId, 'warranty', c.title, c.reason); activity(caseId, 'warranty.expiry', c.reason, [warranty.sourceId]);
    }
    for (const c of all<Case>('cases')) {
      const receipt = get<Receipt>('bookings', c.id);
      if (!receipt) continue;
      if (!['booked', 'awaiting_completion'].includes(c.state) || receipt.confirmed === true) { supersedeJobs(c.id, 'confirmation'); continue; }
      if (receipt.confirmed === null && Date.parse(now()) < Date.parse(receipt.end)) { supersedeJobs(c.id, 'confirmation'); continue; }
      const body = receipt.confirmed === false ? 'The appointment was explicitly not confirmed. Follow up with the household and provider. Completion and charges remain unconfirmed.' : 'The appointment ended without confirmation. Ask whether the provider attended before recording completion or any charge.';
      const key = `confirmation:${receipt.receiptId}`;
      if (!get('inbox', `inbox:${key}`)) { notify(c, key, 'confirmation', `${c.title}: appointment follow-up`, body); activity(c.id, 'appointment.followup', body, [receipt.receiptId]); }
      else {
        const job = required<DueJob>('due_jobs', `job:${key}`);
        if (job.status === 'superseded') { job.status = 'pending'; job.owner = null; job.leaseUntil = null; put('due_jobs', job.id, job); }
      }
    }
  }
  function validateTerms(c: Case, approval: Approval) {
    const offer = required<OfferCard>('offers', approval.terms.offerId); const provider = required<Provider>('providers', approval.terms.providerId);
    if (!offer.terms || offer.status !== 'available' || hash(offer.terms) !== approval.termsHash || amount(offer.terms) > c.budget.minor || !provider.available || provider.declines || !allowsSlot(schedulingPreferences(), offer.terms.slot) || Date.parse(offer.terms.expiresAt) <= Date.parse(now()) || Date.parse(offer.terms.slot.start) <= Date.parse(now()) || !['awaiting_approval', 'booking'].includes(c.state)) throw new HomeOpsError('stale_terms', 'Stale approval terms, budget, scheduling preferences, availability, expiry, or case state');
  }
  function command(actor: Actor, id: string, payload: unknown, fn: () => string[], booking = false): CommandResult {
    authorize(actor); if (!id || id.length > 160) throw new HomeOpsError('invalid_input', 'Invalid command identifier');
    const inputHash = hash({ actor, payload });
    const prior = get<{ inputHash: string; result?: CommandResult }>('command_receipts', id);
    if (prior && prior.inputHash !== inputHash) throw new HomeOpsError('conflict', 'Command identifier reused with different input or actor');
    if (prior?.result) return { ...prior.result, status: 'replayed' };
    if (booking) {
      transaction(() => put('command_receipts', id, { inputHash }));
      const affectedIds = fn();
      return transaction(() => { const result: CommandResult = { commandId: id, status: 'applied', affectedIds, revision: bump() }; put('command_receipts', id, { inputHash, result }); return result; });
    }
    return transaction(() => { const affectedIds = fn(); const result: CommandResult = { commandId: id, status: 'applied', affectedIds, revision: bump() }; put('command_receipts', id, { inputHash, result }); return result; });
  }
  function book(actor: Actor, caseId: string, approvalId: string) {
    authorize(actor, true);
    const authority = required<Approval>('approvals', approvalId);
    if (authority.terms.caseId !== caseId || authority.requesterId !== actor.principalId || authority.responderId !== actor.principalId || !authority.requestId) throw new HomeOpsError('unauthorized', 'Exact authenticated approval required');
    const existing = get<Receipt>('bookings', caseId);
    if (existing) { if (existing.approvalId !== approvalId) throw new HomeOpsError('conflict', 'Case already has a booking'); return [caseId, existing.receiptId]; }
    if (authority.terms.fulfillment === 'manual_plan') return transaction(() => {
      const c = required<Case>('cases', caseId); const approval = required<Approval>('approvals', approvalId);
      const existingPlan = get<ManualServicePlan>('service_plans', caseId);
      if (existingPlan) { if (existingPlan.approvalId !== approvalId) throw new HomeOpsError('conflict', 'Case already has a service plan'); return [caseId, existingPlan.id]; }
      if (c.approvalId !== approvalId || approval.status !== 'approved') throw new HomeOpsError('unauthorized', 'Exact authenticated approval required');
      validateTerms(c, approval);
      const plan: ManualServicePlan = { id: `plan:${approvalId}`, caseId, approvalId, terms: approval.terms, status: 'needs_contact', sourceId: null, createdAt: now(), confirmedAt: null };
      put('service_plans', caseId, plan); approval.status = 'consumed'; put('approvals', approval.id, approval); transition(c, 'booking'); transition(c, 'planned');
      activity(caseId, 'plan.created', 'Approved local service plan. Contact the provider and record a sourced confirmation; no provider acceptance or booking has been asserted.', [plan.id, approval.id]); return [caseId, plan.id];
    });
    const operationId = `provider:${approvalId}`;
    const prepare = () => {
      const c = required<Case>('cases', caseId); const approval = required<Approval>('approvals', approvalId);
      if (c.approvalId !== approvalId || approval.terms.caseId !== caseId || approval.status !== 'approved' || approval.requesterId !== actor.principalId || approval.responderId !== actor.principalId || !approval.requestId) throw new HomeOpsError('unauthorized', 'Exact authenticated approval required');
      validateTerms(c, approval); transition(c, 'booking');
      return { c, approval };
    };
    let reservation = get<Receipt>('provider_operations', operationId);
    if (!reservation) {
      transaction(prepare);
      reservation = transaction(() => {
      const { approval } = prepare(); const terms = approval.terms;
      const receipt: Receipt = { caseId, approvalId, operationId, receiptId: `receipt:${approvalId}`, providerName: required<Provider>('providers', terms.providerId).name, start: terms.slot.start, end: terms.slot.end, confirmed: null, simulated: true };
      put('provider_operations', operationId, receipt); activity(caseId, 'provider.accepted', 'Simulated provider accepted the stable reservation operation.', [operationId], true); return receipt;
      });
    }
    options.faultAfterProviderAcceptance?.();
    transaction(() => { const c = required<Case>('cases', caseId); const a = required<Approval>('approvals', approvalId); a.status = 'consumed'; put('approvals', a.id, a); put('bookings', caseId, reservation); transition(c, 'booked'); activity(caseId, 'booking.recorded', 'Simulated reservation recorded. Service completion and charges remain unconfirmed.', [reservation.receiptId], true); });
    return [caseId, reservation.receiptId];
  }
  transaction(() => {
    if (!get('meta', 'revision')) put('meta', 'revision', 1);
    if (!get('meta', 'clockOffset')) put('meta', 'clockOffset', 0);
    if (!get('meta', 'schedulingPreferences')) put('meta', 'schedulingPreferences', DEFAULT_AVAILABILITY_PREFERENCES);
    if (!get('meta', 'workspace')) {
      const legacy = household();
      put('meta', 'workspace', legacy ? { status: 'ready', dataKind: 'synthetic', providerMode: 'simulated', datasetId: 'legacy-household', datasetVersion: 1 } : { status: 'empty' });
    }
    for (const h of all<HouseholdSnapshot['household']>('households')) if (!h.revision || h.warrantyNoticeDays === undefined) put('households', h.id, { ...h, revision: h.revision ?? 1, warrantyNoticeDays: h.warrantyNoticeDays ?? 7 });
    for (const a of all<Appliance>('appliances')) if (!a.revision) put('appliances', a.id, { ...a, revision: 1 });
    for (const p of all<Provider>('providers')) if (!p.revision) put('providers', p.id, { ...p, revision: 1 });
  });
  function assetRecord(a: Appliance): ApplianceInput {
    const service = a.serviceSourceId ? required<ServiceEvent>('service_events', a.serviceSourceId) : null;
    const policy = get<{ intervalDays: number; sourceId?: string }>('policies', a.id);
    return { id: a.id, name: a.name, kind: a.kind, location: a.location, lastService: service ? { performedOn: service.performedOn, sourceId: service.sourceId } : null, maintenance: policy ? { intervalDays: policy.intervalDays, sourceId: policy.sourceId ?? `policy:${a.id}` } : null, warranty: get<ApplianceInput['warranty']>('warranties', a.id) ?? null };
  }
  function providerRecord(p: Provider): ProviderInput {
    return { id: p.id, name: p.name, serviceKind: p.serviceKind ?? 'ac', preferred: p.preferred, available: p.available, contactNote: p.contactNote ?? null, simulation: manual() ? null : { declines: p.declines, amount: money(p.amount) } };
  }
  function saveAsset(record: ApplianceInput, revision: number, commandId: string) {
    const existing = get<Appliance>('appliances', record.id);
    const currentService = existing?.serviceSourceId ? required<ServiceEvent>('service_events', existing.serviceSourceId) : null;
    const unchangedService = currentService && record.lastService && currentService.performedOn === record.lastService.performedOn && currentService.sourceId === record.lastService.sourceId;
    const serviceId = record.lastService ? unchangedService ? currentService.id : `service:record:${commandId}:${record.id}` : null;
    if (!unchangedService && serviceId && record.lastService) put('service_events', serviceId, { id: serviceId, applianceId: record.id, ...record.lastService, caseId: null } satisfies ServiceEvent);
    put('appliances', record.id, { id: record.id, name: record.name, kind: record.kind, location: record.location, revision, serviceSourceId: serviceId } satisfies Appliance);
    for (const [table, value] of [['policies', record.maintenance], ['warranties', record.warranty]] as const) {
      if (value) put(table, record.id, value); else db.prepare(`DELETE FROM ${table} WHERE id=?`).run(record.id);
    }
  }
  function saveProvider(record: ProviderInput, revision: number) {
    if ((record.simulation === null) !== manual()) throw new HomeOpsError('invalid_input', 'Provider simulation must match the workspace mode');
    put('providers', record.id, { id: record.id, name: record.name, serviceKind: record.serviceKind, preferred: record.preferred, available: record.available, contactNote: record.contactNote, revision, declines: record.simulation?.declines ?? false, amount: record.simulation?.amount.minor ?? 0 } satisfies Provider);
  }
  function initialize(raw: HouseholdDataset, commandId: string) {
    const data = HouseholdDatasetSchema.parse(raw);
    if (workspace().status !== 'empty') throw new HomeOpsError('conflict', 'Dataset initialization requires an empty workspace');
    put('meta', 'workspace', { status: 'ready', dataKind: data.metadata.kind, providerMode: data.providerMode, datasetId: data.metadata.id, datasetVersion: data.version } satisfies WorkspaceInfo);
    put('meta', 'datasetMetadata', data.metadata);
    put('meta', 'clockOffset', data.demoNow ? Date.parse(data.demoNow) - Date.now() : 0);
    put('meta', 'schedulingPreferences', data.schedulingPreferences);
    put('households', data.household.id, { ...data.household, revision: 1 });
    for (const a of data.appliances) saveAsset(a, 1, commandId);
    for (const p of data.providers) saveProvider(p, 1);
    for (const e of data.expenses) put('expenses', e.id, { ...e, revision: 1, caseId: null, serviceEventId: null } satisfies ExpenseRow);
    data.notes.forEach((note, i) => put('preferences', `dataset:${i}`, note));
    activity(null, 'dataset.initialized', `Initialized ${data.metadata.name}. ${data.providerMode === 'simulated' ? 'Provider interactions are simulated.' : 'Provider quotes and confirmations must be entered from sources.'}`, [data.metadata.id], data.providerMode === 'simulated');
    return [data.household.id];
  }
  function reconcileAccepted() {
    for (const receipt of all<Receipt>('provider_operations')) {
      if (get('bookings', receipt.caseId)) continue;
      const c = required<Case>('cases', receipt.caseId); const approval = required<Approval>('approvals', receipt.approvalId);
      approval.status = 'consumed'; put('approvals', approval.id, approval); put('bookings', c.id, receipt); transition(c, 'booked');
      activity(c.id, 'booking.recorded', 'Reconciled accepted simulated reservation.', [receipt.receiptId], true);
    }
  }
  function invalidateUnaccepted(c: Case, reason: string) {
    if (terminal.has(c.state) || get('bookings', c.id) || get('service_plans', c.id)) return;
    invalidate(c, reason);
    if (c.state === 'booking') { transition(c, 'failed'); transition(c, 'requesting_offers'); }
    for (const offer of all<OfferCard>('offers').filter(o => o.id.startsWith(`offer:${c.id}:`) && o.status === 'available')) { offer.status = 'unavailable'; offer.revision++; offer.explanation = reason; put('offers', offer.id, offer); }
  }
  if (options.initialDataset && workspace().status === 'empty') transaction(() => { initialize(options.initialDataset!, 'bootstrap'); bump(); });
  async function execute(actor: Actor, input: HomeCommand): Promise<CommandResult> {
    authorize(actor, !['work.tick', 'case.requestOffers'].includes(input.type));
    const { id, ...raw } = input;
    if (!['work.tick', 'case.book'].includes(input.type)) { if (input.type === 'approval.settle' as string) throw new HomeOpsError('unauthorized', 'Approval settlement is private'); input = { id, ...PublicCommandSchema.parse(raw) }; }
    return command(actor, id, raw, () => {
      if (input.type !== 'dataset.initialize' && workspace().status === 'empty') { if (input.type === 'work.tick') return []; throw new HomeOpsError('conflict', 'Initialize an empty workspace before changing household records'); }
      if (['clock.set', 'fixture.change'].includes(input.type) && workspace().status === 'ready' && (workspace() as Extract<WorkspaceInfo, {status: 'ready'}>).dataKind === 'personal') throw new HomeOpsError('invalid_input', 'Personal households use the system clock and ordinary record commands');
      if (!['case.book', 'work.tick'].includes(input.type)) reconcileAccepted();
      switch (input.type) {
        case 'dataset.initialize': return initialize(input.dataset, id);
        case 'household.update': { const h = household(); if (h.revision !== input.expectedRevision) throw new HomeOpsError('conflict', 'Household revision changed'); put('households', h.id, { ...h, name: input.name, budget: input.budget, warrantyNoticeDays: input.warrantyNoticeDays, revision: h.revision + 1 }); evaluate(); return [h.id]; }
        case 'asset.upsert': { const old = get<Appliance>('appliances', input.record.id); if ((old?.revision ?? null) !== input.expectedRevision) throw new HomeOpsError('conflict', 'Appliance revision changed'); if (old && hash(assetRecord(old)) === hash(input.record)) return [old.id]; for (const c of all<Case>('cases').filter(c => c.applianceId === input.record.id)) { invalidateUnaccepted(c, 'Appliance evidence changed. Obtain fresh quotes and approval.'); if (c.purpose === 'warranty' && !terminal.has(c.state) && old && hash(assetRecord(old).warranty) !== hash(input.record.warranty)) { transition(c, 'cancelled'); supersedeJobs(c.id); } } saveAsset(input.record, (old?.revision ?? 0) + 1, id); evaluate(); return [input.record.id]; }
        case 'provider.upsert': { const old = get<Provider>('providers', input.record.id); if ((old?.revision ?? null) !== input.expectedRevision) throw new HomeOpsError('conflict', 'Provider revision changed'); if (old && hash(providerRecord(old)) === hash(input.record)) return [old.id]; for (const c of all<Case>('cases').filter(c => all<OfferCard>('offers').some(o => o.providerId === input.record.id && o.id.startsWith(`offer:${c.id}:`)))) invalidateUnaccepted(c, 'Provider record changed. Obtain fresh quotes and approval.'); saveProvider(input.record, (old?.revision ?? 0) + 1); return [input.record.id]; }
        case 'case.setBudget': { const c = required<Case>('cases', input.caseId); if (terminal.has(c.state) || get('bookings', c.id) || get('service_plans', c.id)) throw new HomeOpsError('conflict', 'Only an unaccepted active case budget can be changed'); if (hash(c.budget) === hash(input.amount)) return [c.id]; invalidateUnaccepted(c, 'Case budget changed. Obtain fresh quotes and approval.'); c.budget = input.amount; put('cases', c.id, c); return [c.id]; }
        case 'case.recordQuote': {
          if (!manual()) throw new HomeOpsError('invalid_input', 'Entered quotes require manual provider mode');
          const c = required<Case>('cases', input.caseId); const p = required<Provider>('providers', input.providerId); const appliance = required<Appliance>('appliances', c.applianceId);
          if (!['due', 'requesting_offers', 'awaiting_approval', 'unavailable'].includes(c.state) || c.purpose === 'warranty') throw new HomeOpsError('conflict', 'Case cannot accept a quote now');
          if ((p.serviceKind ?? 'ac') !== appliance.kind || !p.available) throw new HomeOpsError('invalid_input', 'Provider is unavailable or serves a different appliance kind');
          if (Date.parse(input.slot.end) <= Date.parse(input.slot.start) || Date.parse(input.expiresAt) <= Date.parse(now()) || Date.parse(input.slot.start) <= Date.parse(now()) || Date.parse(input.expiresAt) > Date.parse(input.slot.start) || !allowsSlot(schedulingPreferences(), input.slot)) throw new HomeOpsError('invalid_input', 'Quote needs a future valid slot, unexpired source and saved household availability');
          invalidate(c, 'Entered quote changed.'); if (c.state !== 'requesting_offers') transition(c, 'requesting_offers');
          const offerId = `offer:${c.id}:${p.id}`; const quoteRevision = (get<OfferCard>('offers', offerId)?.revision ?? 0) + 1;
          const terms: QuoteTerms = { caseId: c.id, providerId: p.id, offerId, revision: quoteRevision, slot: input.slot, expiresAt: input.expiresAt, charge: input.charge, fulfillment: 'manual_plan', sourceId: input.sourceId };
          put('offers', offerId, { id: offerId, providerId: p.id, providerName: p.name, revision: quoteRevision, status: 'available', terms, withinBudget: amount(terms) <= c.budget.minor, simulated: false, explanation: 'User-entered sourced quote. Approval creates a local service plan; provider acceptance remains unconfirmed.' } satisfies OfferCard);
          activity(c.id, 'quote.recorded', 'Recorded a sourced manual provider quote.', [offerId, input.sourceId]); return [c.id, offerId];
        }
        case 'case.confirmManualPlan': { const c = required<Case>('cases', input.caseId); const plan = required<ManualServicePlan>('service_plans', c.id); if (plan.status === 'user_confirmed') { if (plan.sourceId !== input.sourceId) throw new HomeOpsError('conflict', 'Plan confirmation already has a source'); return [c.id, plan.id]; } if (c.state !== 'planned') throw new HomeOpsError('conflict', 'Only a planned service can be confirmed'); plan.status = 'user_confirmed'; plan.sourceId = input.sourceId; plan.confirmedAt = now(); put('service_plans', c.id, plan); transition(c, 'awaiting_completion'); activity(c.id, 'plan.userConfirmed', 'User confirmed provider arrangements from a source. Completion and charges remain separate.', [plan.id, input.sourceId]); return [c.id, plan.id]; }
        case 'work.tick': reconcileAccepted(); evaluate(); return all<DueJob>('due_jobs').filter(j => j.status === 'pending').map(j => j.id);
        case 'clock.set': put('meta', 'clockOffset', Date.parse(input.now) - Date.now()); evaluate(); activity(null, 'clock.changed', `Business clock set to ${input.now}.`); return [];
        case 'case.requestOffers': {
          const c = required<Case>('cases', input.caseId); if (!['due', 'requesting_offers', 'unavailable', 'awaiting_approval'].includes(c.state)) throw new HomeOpsError('conflict', 'Case cannot request offers now');
          if (c.purpose === 'warranty') throw new HomeOpsError('conflict', 'Warranty warning needs document review, not a service booking');
          const appliance = required<Appliance>('appliances', c.applianceId);
          invalidate(c, 'Offers requested again.'); transition(c, 'requesting_offers');
          if (manual()) { activity(c.id, 'quote.requested', 'Enter a provider quote with its source, amount, appointment and expiry. No provider was contacted and no response or price was generated.'); return [c.id]; }
          const requestedAt = now(); const slot = earliestSlot(schedulingPreferences(), requestedAt, c.urgent);
          const timing = !slot ? 'No full one-hour appointment fits the saved availability in the next 14 local days.' : c.urgent && Date.parse(slot.start) > Date.parse(requestedAt) + 2 * 3600000 ? 'Urgent inspection is delayed to the next full one-hour appointment allowed by saved household availability.' : 'Appointment respects saved household availability.';
          for (const p of all<Provider>('providers').filter(p => (p.serviceKind ?? 'ac') === appliance.kind)) {
            const id = `offer:${c.id}:${p.id}`; const previous = get<OfferCard>('offers', id); const revision = (previous?.revision ?? 0) + 1;
            const status = !p.available || !slot ? 'unavailable' : p.declines ? 'declined' : 'available';
            const terms: QuoteTerms | null = status === 'available' && slot ? { caseId: c.id, providerId: p.id, offerId: id, revision, slot, expiresAt: new Date(Date.parse(slot.start) - 3600000).toISOString(), charge: c.urgent ? { kind: 'inspection', fee: money(p.amount), parts: 'unknown' } : { kind: 'fixed', total: money(p.amount) } } : null;
            put('offers', id, { id, providerId: p.id, providerName: p.name, revision, status, terms, withinBudget: terms ? amount(terms) <= c.budget.minor : null, simulated: true, explanation: status === 'declined' ? 'Preferred provider declined this simulated appointment.' : status === 'unavailable' ? !slot ? timing : 'Provider unavailable.' : `${timing} ${c.urgent ? `Inspection fee only${p.amount > c.budget.minor ? ', above budget' : ''}. Parts and final repair cost are unknown; further work needs a separate quote and approval.` : p.amount > c.budget.minor ? 'Quote exceeds the case budget.' : 'Fixed service quote within the case budget.'}` } satisfies OfferCard & { caseId?: string });
            activity(c.id, `provider.${status}`, `${p.name} ${status === 'available' ? `quoted ₹${p.amount / 100}` : status}. Simulated.`, [id], true);
          }
          if (!all<OfferCard>('offers').some(o => o.terms?.caseId === c.id && o.status === 'available' && amount(o.terms) <= c.budget.minor)) transition(c, 'unavailable'); return [c.id];
        }
        case 'case.chooseOffer': {
          const c = required<Case>('cases', input.caseId); const offer = required<OfferCard>('offers', input.offerId);
          if (!offer.terms || offer.terms.caseId !== c.id || offer.revision !== input.revision || offer.status !== 'available') throw new HomeOpsError('stale_terms', 'Offer revision is stale or unavailable');
          const provider = required<Provider>('providers', offer.providerId);
          if (!provider.available || provider.declines || !allowsSlot(schedulingPreferences(), offer.terms.slot) || Date.parse(offer.terms.expiresAt) <= Date.parse(now()) || Date.parse(offer.terms.slot.start) <= Date.parse(now())) throw new HomeOpsError('stale_terms', 'Offer expired, outside scheduling preferences, or provider unavailable');
          if (amount(offer.terms) > c.budget.minor) throw new HomeOpsError('conflict', 'Offer exceeds budget');
          if (!['requesting_offers', 'awaiting_approval'].includes(c.state)) throw new HomeOpsError('conflict', 'Case cannot choose an offer now');
          const current = c.approvalId ? required<Approval>('approvals', c.approvalId) : null;
          if (current && ['pending', 'approved'].includes(current.status) && current.requesterId === actor.principalId && current.termsHash === hash(offer.terms)) return [c.id, current.id];
          invalidate(c, 'A new offer was selected.');
          const id = `approval:${randomUUID()}`; const a: Approval = { id, status: 'pending', terms: offer.terms, termsHash: hash(offer.terms), sessionId: null, requestId: null, callId: null, requesterId: actor.principalId, responderId: null, settledAt: null };
          put('approvals', id, a); c.approvalId = id; transition(c, 'awaiting_approval'); activity(c.id, 'approval.prepared', 'Exact provider, appointment, quote revision, and amount await approval.', [id, offer.id]); return [c.id, id];
        }
        case 'case.book': return book(actor, input.caseId, input.approvalId);
        case 'fixture.change': {
          const change = input.change;
          if (change.kind === 'budget') { const c = required<Case>('cases', change.caseId); c.budget = change.amount; put('cases', c.id, c); invalidate(c, 'Case budget changed.'); }
          if (change.kind === 'provider') { const p = required<Provider>('providers', change.providerId); p.available = change.available; p.revision = (p.revision ?? 1) + 1; put('providers', p.id, p); for (const c of all<Case>('cases')) if (c.approvalId && required<Approval>('approvals', c.approvalId).terms.providerId === p.id) invalidate(c, 'Provider availability changed.'); }
          if (change.kind === 'policy') { const a = required<Appliance>('appliances', change.applianceId); a.revision = (a.revision ?? 1) + 1; put('appliances', a.id, a); const p = get<{ revision: number }>('policies', change.applianceId); put('policies', change.applianceId, { id: `policy:${change.applianceId}`, intervalDays: change.intervalDays, revision: (p?.revision ?? 0) + 1 }); }
          if (change.kind === 'serviceDate') { const a = required<Appliance>('appliances', change.applianceId); a.revision = (a.revision ?? 1) + 1; a.serviceSourceId = change.performedOn ? `service:correction:${id}` : null; if (a.serviceSourceId) put('service_events', a.serviceSourceId, { id: a.serviceSourceId, applianceId: a.id, performedOn: change.performedOn, sourceId: `operator:${id}`, caseId: null }); put('appliances', a.id, a); }
          if (change.kind === 'quote') { const o = required<OfferCard>('offers', change.offerId); if (!o.terms) throw new HomeOpsError('conflict', 'Declined offers cannot be revised'); const quoteCase = required<Case>('cases', o.terms.caseId); if (terminal.has(quoteCase.state) || get('bookings', quoteCase.id) || get('service_plans', quoteCase.id)) throw new HomeOpsError('conflict', 'Accepted or historical quotes cannot be revised'); o.revision++; o.terms.revision = o.revision; o.terms.charge = o.terms.charge.kind === 'inspection' ? { kind: 'inspection', fee: change.amount, parts: 'unknown' } : { kind: 'fixed', total: change.amount }; if (change.start) { const duration = Date.parse(o.terms.slot.end) - Date.parse(o.terms.slot.start); o.terms.slot = { start: change.start, end: new Date(Date.parse(change.start) + duration).toISOString() }; o.terms.expiresAt = new Date(Date.parse(change.start) - 3600000).toISOString(); } put('offers', o.id, o); invalidate(required<Case>('cases', o.terms.caseId), 'Quote amount or appointment changed.'); }
          evaluate(); activity(null, 'fixture.changed', `Fixture ${change.kind} changed.`, [id]); return [];
        }
        case 'case.confirmAppointment': { const c = required<Case>('cases', input.caseId); if (!['booked', 'awaiting_completion'].includes(c.state)) throw new HomeOpsError('conflict', 'Only an active booked appointment can be confirmed'); const receipt = required<Receipt>('bookings', c.id); receipt.confirmed = input.confirmed; put('bookings', c.id, receipt); transition(c, 'awaiting_completion'); activity(c.id, input.confirmed ? 'appointment.confirmed' : 'appointment.unconfirmed', input.confirmed ? 'Appointment confirmed.' : 'Appointment explicitly not confirmed; follow-up required.', [receipt.receiptId]); evaluate(); return [c.id]; }
        case 'case.complete': { const c = required<Case>('cases', input.caseId); if (!['booked', 'awaiting_completion'].includes(c.state)) throw new HomeOpsError('conflict', 'Only a booked service may be completed'); if (input.completedAt > dayInIndia(now())) throw new HomeOpsError('invalid_input', 'Completion cannot be in the future'); const a = required<Appliance>('appliances', c.applianceId); const eventId = `service:${id}`; put('service_events', eventId, { id: eventId, applianceId: a.id, caseId: c.id, performedOn: input.completedAt, sourceId: input.sourceId } satisfies ServiceEvent); a.serviceSourceId = eventId; a.revision = (a.revision ?? 1) + 1; put('appliances', a.id, a); transition(c, 'completed'); supersedeJobs(c.id, 'confirmation'); activity(c.id, 'service.completed', `Service completed ${input.completedAt}; maintenance cycle recalculated.`, [eventId, input.sourceId]); return [c.id, eventId]; }
        case 'inbox.read': { const item = required<InboxItem>('inbox', input.inboxId); item.readAt = now(); put('inbox', item.id, item); return [item.id]; }
        case 'preference.save': put('preferences', id, input.text); activity(null, 'preference.saved', input.text, [id]); return [id];
        case 'preference.setSchedule': {
          const preferences = { ...input.preferences, daysOfWeek: [...input.preferences.daysOfWeek].sort((a, b) => a - b) };
          if (hash(preferences) === hash(schedulingPreferences())) return ['schedulingPreferences'];
          put('meta', 'schedulingPreferences', preferences);
          for (const c of all<Case>('cases')) {
            if (get('service_plans', c.id) || get('bookings', c.id) || all<Receipt>('provider_operations').some(operation => operation.caseId === c.id)) continue;
            invalidate(c, 'Household scheduling preferences changed. Request fresh offers and approval.');
            if (c.state === 'booking') { transition(c, 'failed'); transition(c, 'requesting_offers'); }
            for (const offer of all<OfferCard>('offers').filter(offer => offer.terms?.caseId === c.id && offer.status === 'available')) {
              offer.revision++; offer.status = 'unavailable'; offer.explanation = 'Scheduling preferences changed. Request fresh offers and approval.'; put('offers', offer.id, offer);
            }
          }
          activity(null, 'preference.scheduleChanged', `Scheduling availability saved for ISO weekdays ${preferences.daysOfWeek.join(', ')}, ${preferences.startTime} to ${preferences.endTime} ${preferences.timezone}. Unaccepted offers require fresh quotes and approval.`, ['schedulingPreferences']);
          return ['schedulingPreferences'];
        }
        case 'expense.record': { validateCharge(input.charge); const expenseId = `expense:${id}`; put('expenses', expenseId, { id: expenseId, revision: 1, ...input.charge } satisfies ExpenseRow); activity(input.charge.caseId, 'expense.recorded', input.charge.description, [expenseId, input.charge.sourceId]); return [expenseId]; }
        case 'expense.correct': { const e = required<ExpenseRow>('expenses', input.expenseId); if (e.revision !== input.expectedRevision) throw new HomeOpsError('conflict', 'Expense revision changed'); if (input.replacement) { validateCharge(input.replacement); put('expenses', e.id, { id: e.id, revision: e.revision + 1, ...input.replacement }); } else db.prepare('DELETE FROM expenses WHERE id=?').run(e.id); put('expense_corrections', id, { previous: e, replacement: input.replacement, reason: input.reason, actor, at: now() }); activity(e.caseId, 'expense.corrected', input.reason, [e.id, id]); return [e.id]; }
        case 'case.openUrgent': {
          const a = required<Appliance>('appliances', input.applianceId);
          const existing = all<Case>('cases').find(c => c.applianceId === a.id && c.urgent && !terminal.has(c.state));
          if (existing) return [existing.id];
          const caseId = `case:urgent:${hash(id).slice(0, 20)}`; const c: Case = { id: caseId, applianceId: a.id, title: `${a.name} urgent inspection`, reason: `${input.description} Inspection only. Parts and final repair cost are unknown.`, state: 'due', budget: household().budget, urgent: true, sessionId: null, approvalId: null, cycle: caseId, purpose: 'urgent' };
          put('cases', c.id, c); notify(c, c.id, 'urgent', c.title, c.reason); activity(c.id, 'repair.urgent', c.reason, [id]); return [c.id];
        }
      }
    }, input.type === 'case.book');
  }
  function validateCharge(charge: Extract<PublicCommand, { type: 'expense.record' }>['charge']) { required('appliances', charge.applianceId); if (charge.caseId && required<Case>('cases', charge.caseId).applianceId !== charge.applianceId) throw new HomeOpsError('invalid_input', 'Charge case belongs to a different appliance'); if (charge.serviceEventId && required<ServiceEvent>('service_events', charge.serviceEventId).applianceId !== charge.applianceId) throw new HomeOpsError('invalid_input', 'Charge service belongs to a different appliance'); }
  function snapshot(actor: Actor): HouseholdSnapshot {
    authorize(actor); const expenses = all<ExpenseRow>('expenses');
    return { schemaVersion: 1, workspace: workspace(), revision: revision(), schedulingPreferences: schedulingPreferences(), clock: { effectiveNow: now(), timezone: 'Asia/Kolkata' }, household: household() ?? { id: 'empty', name: 'Set up your household', budget: money(0), revision: 0, warrantyNoticeDays: 7 },
      appliances: all<Appliance>('appliances').map(a => { const service = a.serviceSourceId ? required<ServiceEvent>('service_events', a.serviceSourceId) : null; const due = nextDue(a); const warranty = get<{ ends: string; sourceId: string }>('warranties', a.id); return { revision: a.revision ?? 1, record: assetRecord(a), id: a.id, name: a.name, kind: a.kind, location: a.location, lastService: service ? { value: service.performedOn, sourceId: service.sourceId } : { value: null, reason: 'Service date unknown' }, nextDue: due ? { value: due, sourceId: `${assetRecord(a).maintenance!.sourceId}+${service!.sourceId}` } : { value: null, reason: 'Service date or maintenance policy unknown' }, warrantyEnds: warranty ? { value: warranty.ends, sourceId: warranty.sourceId } : { value: null, reason: 'Warranty terms unknown or not applicable' }, intervalDays: get<{ intervalDays: number }>('policies', a.id)?.intervalDays ?? null }; }),
      cases: all<Case>('cases').map(c => { const a = c.approvalId ? required<Approval>('approvals', c.approvalId) : null; const receipt = get<Receipt>('bookings', c.id); return { purpose: c.purpose ?? (c.urgent ? 'urgent' : 'maintenance'), id: c.id, applianceId: c.applianceId, title: c.title, state: c.state, reason: c.reason, budget: c.budget, urgent: c.urgent, sessionId: c.sessionId, offers: all<OfferCard>('offers').filter(o => o.id.startsWith(`offer:${c.id}:`)).map(o => ({ ...o, withinBudget: o.terms ? amount(o.terms) <= c.budget.minor : null })), approval: a ? { id: a.id, status: a.status, terms: a.terms, termsHash: a.termsHash, requestId: a.requestId, sessionId: a.sessionId } : null, servicePlan: get<ManualServicePlan>('service_plans', c.id) ?? null, booking: receipt ? { receiptId: receipt.receiptId, operationId: receipt.operationId, providerName: receipt.providerName, start: receipt.start, end: receipt.end, confirmed: receipt.confirmed, simulated: true } : null }; }),
      inbox: all('inbox'), expenses, expenseTotals: [money(expenses.reduce((sum, e) => sum + e.amount.minor, 0))], activity: all('activity'), providers: all<Provider>('providers').map(p => ({ id: p.id, name: p.name, available: p.available, preferred: p.preferred, revision: p.revision ?? 1, record: providerRecord(p) })), preferences: all<string>('preferences').concat(all<MemoryDocument>('memory_documents').map(d => d.content)) };
  }
  function bindApproval(actor: Actor, input: { approvalId: string; callId: string; requestId?: string; sessionId: string }) {
    authorize(actor, true);
    return transaction(() => {
      const a = required<Approval>('approvals', input.approvalId);
      if (a.requesterId !== actor.principalId || !['pending', 'approved', 'consumed'].includes(a.status)) throw new HomeOpsError('unauthorized', 'Approval is stale or belongs to another operator');
      if (!input.callId || !input.sessionId) throw new HomeOpsError('invalid_input', 'Approval needs call and session identifiers');
      if ((a.callId && a.callId !== input.callId) || (a.sessionId && a.sessionId !== input.sessionId) || (a.requestId && input.requestId && a.requestId !== input.requestId)) throw new HomeOpsError('conflict', 'Approval already bound to another Eve request');
      if (a.status !== 'pending') {
        if (!a.requestId || a.callId !== input.callId || a.sessionId !== input.sessionId) throw new HomeOpsError('unauthorized', 'Settled approval requires its original Eve call');
        return;
      }
      a.callId = input.callId; a.sessionId = input.sessionId; a.requestId = input.requestId ?? a.requestId;
      put('approvals', a.id, a); bump();
    });
  }
  async function settleApproval(actor: Actor, input: { id: string; approvalId: string; decision: 'approve' | 'deny'; responderId: string; requestId: string; callId: string; sessionId: string }): Promise<CommandResult> {
    authorize(actor, true); return command(actor, input.id, { type: 'private.approval.settle', ...input }, () => { const a = required<Approval>('approvals', input.approvalId); const c = required<Case>('cases', a.terms.caseId);
      if (a.requesterId !== actor.principalId || input.responderId !== actor.principalId || !input.requestId || !a.callId || a.callId !== input.callId || input.sessionId !== a.sessionId || (a.requestId && a.requestId !== input.requestId)) throw new HomeOpsError('unauthorized', 'Approval responder or Eve request identity mismatch');
      if (a.status === 'invalidated') {
        if (input.decision === 'approve') throw new HomeOpsError('stale_terms', 'Stale approval. Terms changed. Cancel this outdated request and obtain fresh approval.');
        a.requestId = input.requestId; a.responderId = input.responderId; a.settledAt = now(); put('approvals', a.id, a);
        activity(c.id, 'approval.dismissed', 'Operator dismissed an outdated approval. No reservation made. Current terms require separate approval.', [a.id, input.requestId]);
        return [c.id, a.id];
      }
      if (a.status !== 'pending') throw new HomeOpsError('conflict', 'Approval already settled');
      if (input.decision === 'approve') validateTerms(c, a);
      a.status = input.decision === 'approve' ? 'approved' : 'denied'; a.requestId = input.requestId; a.responderId = input.responderId; a.settledAt = now(); put('approvals', a.id, a); if (input.decision === 'deny') transition(c, 'denied'); activity(c.id, `approval.${a.status}`, input.decision === 'approve' ? 'Operator approved the exact displayed terms.' : 'Operator denied the booking. No reservation made.', [a.id, input.requestId]); return [c.id, a.id]; });
  }
  const pendingJobs = (actor: Actor) => { authorize(actor); return all<DueJob>('due_jobs').filter(j => j.status === 'pending' || (j.status === 'claimed' && (j.leaseUntil ?? 0) <= Date.now())); };
  function claimJob(actor: Actor, input: { jobId: string; owner: string; leaseMs?: number }) { authorize(actor); return transaction(() => { const job = required<DueJob>('due_jobs', input.jobId); if (job.status === 'dispatched' || job.status === 'superseded' || (job.status === 'claimed' && (job.leaseUntil ?? 0) > Date.now() && job.owner !== input.owner)) return null; job.status = 'claimed'; job.owner = input.owner; job.leaseUntil = Date.now() + Math.min(Math.max(input.leaseMs ?? 60000, 1), 300000); put('due_jobs', job.id, job); return job; }); }
  function bindJobSession(actor: Actor, input: { jobId: string; owner: string; sessionId: string }) { authorize(actor); return transaction(() => { const job = required<DueJob>('due_jobs', input.jobId); if (job.sessionId) { if (job.sessionId !== input.sessionId) throw new HomeOpsError('conflict', 'Job already has another session'); return; } if (job.status !== 'claimed' || job.owner !== input.owner || (job.leaseUntil ?? 0) <= Date.now()) throw new HomeOpsError('conflict', 'Job lease is not owned'); job.sessionId = input.sessionId; job.status = 'dispatched'; job.leaseUntil = null; put('due_jobs', job.id, job); const c = required<Case>('cases', job.caseId); c.sessionId = input.sessionId; put('cases', c.id, c); for (const item of all<InboxItem>('inbox').filter(i => i.id === (job.inboxId ?? `inbox:${c.id}`))) { item.sessionId = input.sessionId; put('inbox', item.id, item); } bump(); }); }
  function releaseJob(actor: Actor, input: { jobId: string; owner: string }) { authorize(actor); transaction(() => { const job = required<DueJob>('due_jobs', input.jobId); if (job.status === 'claimed' && job.owner === input.owner) { job.status = 'pending'; job.owner = null; job.leaseUntil = null; put('due_jobs', job.id, job); } }); }
  function getMemoryDocument(key: string): MemoryDocument | null { return get<MemoryDocument>('memory_documents', key) ?? null; }
  function putMemoryDocument(key: string, content: string, expectedVersion: number | null): MemoryDocument { return transaction(() => { const previous = getMemoryDocument(key); if ((previous?.version ?? null) !== expectedVersion) throw new MemoryDocumentConflictError(); const document = { content, version: (previous?.version ?? 0) + 1 }; put('memory_documents', key, document); bump(); return document; }); }
  function exportDataset(actor: Actor): HouseholdDataset {
    authorize(actor, true); const state = workspace(); if (state.status !== 'ready') throw new HomeOpsError('conflict', 'Initialize the household before export');
    const h = household();
    return HouseholdDatasetSchema.parse({ format: 'homeops.household', version: 1, metadata: get('meta', 'datasetMetadata') ?? { id: state.datasetId, name: h.name, description: 'Exported household master data and confirmed expenses.', kind: state.dataKind, provenance: 'HomeOps canonical master export' }, providerMode: state.providerMode, demoNow: state.dataKind === 'personal' ? null : now(), household: { id: h.id, name: h.name, budget: h.budget, warrantyNoticeDays: h.warrantyNoticeDays }, schedulingPreferences: schedulingPreferences(), notes: all<string>('preferences'), appliances: all<Appliance>('appliances').map(assetRecord), providers: all<Provider>('providers').map(providerRecord), expenses: all<ExpenseRow>('expenses').map(({ id, applianceId, amount, chargedOn, sourceId, description }) => ({ id, applianceId, amount, chargedOn, sourceId, description })) });
  }
  return { exportDataset, execute, snapshot, bindApproval, settleApproval, pendingJobs, claimJob, bindJobSession, releaseJob, getMemoryDocument, putMemoryDocument, close: () => db.close() };
}
export type HomeOps = ReturnType<typeof openHomeOps>;
