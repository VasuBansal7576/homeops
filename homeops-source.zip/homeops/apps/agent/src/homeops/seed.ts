import { resolve } from 'node:path';
import { rmSync } from 'node:fs';
import { demoDataset } from '../../../../datasets/catalog.ts';
import { openHomeOps } from './index.ts';

const filename = resolve(process.env.HOMEOPS_DB ?? '.local/homeops.sqlite');
if (process.argv.includes('--reset')) for (const suffix of ['', '-wal', '-shm']) rmSync(`${filename}${suffix}`, { force: true });
const home = openHomeOps({ filename, initialDataset: demoDataset });
const snapshot = home.snapshot({ principalId: 'seed', role: 'operator' });
home.close();
console.log(`Seed ready at ${filename}. ${snapshot.appliances.length} appliances; ${snapshot.expenses.length} confirmed historical expenses.`);
