import { credentialPath, getCredential, listModels, object, PlanError, RESOURCE } from './auth.ts';

const OMIT = new Set(['background', 'conversation', 'max_output_tokens', 'max_tool_calls', 'metadata', 'moderation', 'multi_agent', 'prompt', 'prompt_cache_retention', 'safety_identifier', 'temperature', 'top_logprobs', 'top_p', 'truncation', 'user', 'previous_response_id']);
const NAMESPACE = 'homeops';

export function preparePlanRequest(value: unknown): Record<string, unknown> {
  const source = object(value);
  if (!Array.isArray(source.input)) throw new PlanError('plan_input_history_array_required');
  if (typeof source.model !== 'string' || !source.model) throw new PlanError('plan_model_required');
  const body = Object.fromEntries(Object.entries(source).filter(([key]) => !OMIT.has(key)));
  const toolNamespaces = new Map<string, string>();
  if (source.tools !== undefined) {
    if (!Array.isArray(source.tools)) throw new PlanError('invalid_tools');
    const flat: Record<string, unknown>[] = [];
    const tools: Record<string, unknown>[] = [];
    for (const value of source.tools) {
      const tool = object(value);
      if (tool.type === 'function' || tool.type === 'custom') {
        if (typeof tool.name !== 'string') throw new PlanError('invalid_tool_name');
        flat.push(tool);
        toolNamespaces.set(tool.name, NAMESPACE);
      } else if (tool.type === 'namespace') {
        if (typeof tool.name !== 'string' || !Array.isArray(tool.tools)) throw new PlanError('invalid_tool_namespace');
        for (const inner of tool.tools.map(object)) {
          if (!['function', 'custom'].includes(String(inner.type)) || typeof inner.name !== 'string') throw new PlanError('unsupported_namespace_tool');
          toolNamespaces.set(inner.name, tool.name);
        }
        tools.push(tool);
      } else if (tool.type === 'web_search' || tool.type === 'web_search_preview') tools.push(tool);
      else throw new PlanError('unsupported_plan_tool');
    }
    if (flat.length) tools.push({ type: 'namespace', name: NAMESPACE, description: 'HomeOps household tools executed by the application.', tools: flat });
    body.tools = tools;
  }
  body.input = source.input.map(value => {
    const item = object(value);
    if (item.type === 'item_reference') throw new PlanError('full_history_required_item_reference_rejected');
    if (item.role === 'system') return { ...item, role: 'developer' };
    if (item.type === 'function_call' || item.type === 'custom_tool_call') return { ...item, namespace: item.namespace || toolNamespaces.get(String(item.name)) || NAMESPACE };
    return item;
  });
  if (source.tool_choice && typeof source.tool_choice === 'object') {
    const choice = object(source.tool_choice);
    if (choice.type === 'function' || choice.type === 'custom') body.tool_choice = { ...choice, namespace: choice.namespace || toolNamespaces.get(String(choice.name)) || NAMESPACE };
  }
  body.store = false;
  body.stream = true;
  return body;
}

function safeErrorCode(value: unknown): string {
  return typeof value === 'string' && /^[a-zA-Z0-9_]+$/.test(value) ? value : 'unknown';
}

export function createSSEReader(onEvent: (event: Record<string, unknown>) => void): { push: (text: string) => void; finish: () => void } {
  let buffer = '';
  const parse = (block: string) => {
    const data = block.split('\n').filter(line => line.startsWith('data:')).map(line => line.slice(5).trimStart()).join('\n');
    if (data && data !== '[DONE]') onEvent(object(JSON.parse(data)));
  };
  return {
    push(text) {
      buffer += text;
      buffer = buffer.replace(/\r\n/g, '\n');
      if (buffer.length > 16 * 1024 * 1024) throw new PlanError('response_event_too_large');
      let boundary: number;
      while ((boundary = buffer.indexOf('\n\n')) >= 0) { parse(buffer.slice(0, boundary)); buffer = buffer.slice(boundary + 2); }
    },
    finish() { if (buffer.trim()) parse(buffer); },
  };
}

export function requireCompletedStream(response: Response): Response {
  if (!response.body || !response.headers.get('content-type')?.includes('text/event-stream')) throw new PlanError('expected_responses_event_stream');
  let completed = false;
  const decoder = new TextDecoder();
  const parser = createSSEReader(event => {
    if (event.type === 'response.completed') completed = true;
    if (event.type === 'response.failed' || event.type === 'response.incomplete' || event.type === 'error') {
      const data = event.response && typeof event.response === 'object' ? object(event.response) : event;
      const error = data.error && typeof data.error === 'object' ? object(data.error) : data;
      throw new PlanError(`inference_${String(event.type).replace('.', '_')}_${safeErrorCode(error.code)}`);
    }
  });
  const stream = response.body.pipeThrough(new TransformStream<Uint8Array, Uint8Array>({
    transform(chunk, controller) { parser.push(decoder.decode(chunk, { stream: true })); controller.enqueue(chunk); },
    flush() { parser.push(decoder.decode()); parser.finish(); if (!completed) throw new PlanError('stream_ended_without_response_completed'); },
  }));
  return new Response(stream, { status: response.status, statusText: response.statusText, headers: response.headers });
}

export function createPlanFetch(options: { path?: string; fetcher?: typeof fetch; getAccessToken?: () => Promise<string> } = {}): typeof fetch {
  const fetcher = options.fetcher || fetch;
  return async (input, init) => {
    const request = input instanceof Request ? input : undefined;
    const url = new URL(request?.url || String(input));
    if (url.href !== `${RESOURCE}/responses` || (init?.method || request?.method || 'GET').toUpperCase() !== 'POST') throw new PlanError('plan_adapter_responses_endpoint_only');
    const raw = init?.body ?? (request ? await request.clone().text() : undefined);
    if (typeof raw !== 'string') throw new PlanError('plan_adapter_json_body_required');
    const body = preparePlanRequest(JSON.parse(raw));
    const token = options.getAccessToken ? await options.getAccessToken() : (await getCredential(options.path || credentialPath(), fetcher)).tokens.access_token;
    const headers = new Headers(request?.headers);
    new Headers(init?.headers).forEach((value, key) => headers.set(key, value));
    headers.set('Authorization', `Bearer ${token}`);
    headers.set('Content-Type', 'application/json');
    headers.delete('Content-Length');
    const response = await fetcher(url, { ...init, method: 'POST', headers, body: JSON.stringify(body), signal: init?.signal || request?.signal });
    if (!response.ok) throw new PlanError(`responses_http_${response.status}`);
    return requireCompletedStream(response);
  };
}

export async function probe(path = credentialPath(), requestedModel?: string): Promise<{ model: string; completed: true; text: string }> {
  const models = await listModels(path);
  const model = requestedModel ? models.find(value => value.slug === requestedModel)?.slug : models[0]?.slug;
  if (!model) throw new PlanError('requested_model_not_in_account_catalog');
  const response = await createPlanFetch({ path })(`${RESOURCE}/responses`, {
    method: 'POST', body: JSON.stringify({ model, input: [{ role: 'user', content: 'Say exactly: HomeOps inference is connected.' }] }),
  });
  let text = '';
  const parser = createSSEReader(event => { if (event.type === 'response.output_text.delta' && typeof event.delta === 'string') text += event.delta; });
  const decoder = new TextDecoder();
  for await (const chunk of response.body!) parser.push(decoder.decode(chunk, { stream: true }));
  parser.push(decoder.decode());
  parser.finish();
  return { model, completed: true, text };
}
