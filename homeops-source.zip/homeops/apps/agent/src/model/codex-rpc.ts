import { spawn, type ChildProcessWithoutNullStreams } from 'node:child_process';
import { createInterface } from 'node:readline';

export const disabledFeatures = ['shell_tool', 'apps', 'plugins', 'multi_agent', 'multi_agent_v2', 'browser_use', 'computer_use', 'skill_search', 'hooks', 'image_generation', 'view_image', 'sleep_tool', 'workspace_dependencies'];

export type Notification = { method: string; params?: any };
export interface PlannerTransport {
  rpc(method: string, params?: unknown): Promise<any>;
  notify(method: string, params?: unknown): void;
  onNotification(handler: (message: Notification) => void): void;
  readonly failure: Promise<never>;
  close(): Promise<void>;
}

export class StdioPlannerTransport implements PlannerTransport {
  private child: ChildProcessWithoutNullStreams;
  private sequence = 0;
  private pending = new Map<number, { resolve: (value: any) => void; reject: (error: Error) => void }>();
  private handler: (message: Notification) => void = () => {};
  private rejectFailure!: (error: Error) => void;
  private closed = false;
  readonly failure: Promise<never>;

  constructor(cwd: string) {
    this.child = spawn('codex', ['app-server', '--listen', 'stdio://', ...disabledFeatures.flatMap(name => ['--disable', name]), '--enable', 'skip_host_skill_discovery', '-c', 'web_search="disabled"'], { cwd, stdio: ['pipe', 'pipe', 'pipe'] });
    this.failure = new Promise((_, reject) => { this.rejectFailure = reject; });
    void this.failure.catch(() => {});
    const lines = createInterface({ input: this.child.stdout });
    lines.on('line', line => {
      try {
        const message = JSON.parse(line);
        if (message.id !== undefined && message.method) {
          this.write({ id: message.id, error: { code: -32601, message: 'Runtime tools are forbidden. Eve owns execution.' } });
          this.fail(new Error('Codex runtime attempted a server request.'));
        } else if (message.id !== undefined) {
          const pending = this.pending.get(message.id);
          if (!pending) return;
          this.pending.delete(message.id);
          // Do not expose server error payloads, which can contain local configuration.
          message.error ? pending.reject(new Error('Codex app-server RPC failed.')) : pending.resolve(message.result);
        } else if (typeof message.method === 'string') this.handler(message);
      } catch { this.fail(new Error('Invalid app-server protocol output.')); }
    });
    // Drain diagnostics without copying user configuration or credentials to logs.
    this.child.stderr.on('data', () => {});
    this.child.on('error', () => this.fail(new Error('Could not start Codex app-server.')));
    this.child.stdin.on('error', () => this.fail(new Error('Codex app-server input closed.')));
    this.child.on('exit', () => { if (!this.closed) this.fail(new Error('Codex app-server exited before completion.')); });
  }
  private write(value: unknown) { if (!this.closed) this.child.stdin.write(JSON.stringify(value) + '\n'); }
  private fail(error: Error) {
    this.rejectFailure(error);
    for (const pending of this.pending.values()) pending.reject(error);
    this.pending.clear();
  }
  onNotification(handler: (message: Notification) => void) { this.handler = handler; }
  notify(method: string, params = {}) { this.write({ method, params }); }
  rpc(method: string, params: unknown = {}) {
    if (this.closed) return Promise.reject(new Error('Codex transport is closed.'));
    const id = ++this.sequence;
    return new Promise<any>((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.write({ id, method, params });
    });
  }
  async close() {
    if (this.closed) return;
    this.closed = true;
    this.fail(new Error('Codex transport closed.'));
    if (!this.child.pid || this.child.exitCode !== null || this.child.signalCode !== null) return;
    await new Promise<void>(resolve => {
      const timer = setTimeout(() => { this.child.kill('SIGKILL'); }, 1000);
      this.child.once('exit', () => { clearTimeout(timer); resolve(); });
      this.child.stdin.end();
      this.child.kill('SIGTERM');
    });
  }
}
