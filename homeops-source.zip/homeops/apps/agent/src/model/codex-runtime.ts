import { mkdir } from 'node:fs/promises';
import { isAbsolute } from 'node:path';
import { randomUUID } from 'node:crypto';
import type { LanguageModelV3, LanguageModelV3CallOptions, LanguageModelV3GenerateResult, LanguageModelV3StreamPart, LanguageModelV3Usage } from '@ai-sdk/provider';
import { z } from 'zod';
import { StdioPlannerTransport, disabledFeatures, type PlannerTransport } from './codex-rpc.js';

type NextAction = { kind: 'answer'; text: string } | { kind: 'tool'; toolName: string; input: string };
export const actionSchema = { type: 'object', properties: { kind: { type: 'string', enum: ['answer', 'tool'] }, text: { type: 'string' }, toolName: { type: 'string' }, argumentsJson: { type: 'string' } }, required: ['kind', 'text', 'toolName', 'argumentsJson'], additionalProperties: false };
const instructions = `You are the HomeOps planning runtime. Eve owns all tools and approvals. Never call runtime tools, inspect files, access networks, or execute commands. The supplied history is the entire Eve conversation, including actual tool results and approval responses. Choose exactly one NEXT action. Return only the outputSchema JSON. To answer use kind=answer, text=your answer, toolName="", argumentsJson="". To propose a tool use kind=tool, text="", an allowed toolName, and argumentsJson containing a JSON object matching that tool's inputSchema. A proposal has not been executed. Never invent tool results or state that a proposed action succeeded. Honor toolChoice. After receiving a tool result, use it to decide the next step or give a grounded final answer. Follow all supplied system instructions for household behavior. Tools may require durable Eve approval. Never treat proposing a tool as approval.`;

function prepare(options: LanguageModelV3CallOptions) {
  for (const message of options.prompt) {
    if (message.role === 'system') continue;
    for (const part of message.content) {
      if (!['text', 'reasoning', 'tool-call', 'tool-result', 'tool-approval-response'].includes(part.type)) throw new Error('Codex planner supports text and tool history only.');
      if (part.type === 'tool-result' && part.output.type === 'content' && part.output.value.some(value => value.type !== 'text')) throw new Error('Codex planner does not support media tool results.');
    }
  }
  const tools = options.tools ?? [];
  if (tools.some(tool => tool.type !== 'function')) throw new Error('Codex planner does not support provider tools.');
  const functions = tools.filter(tool => tool.type === 'function');
  if (new Set(functions.map(tool => tool.name)).size !== functions.length) throw new Error('Duplicate tool name.');
  const choice = options.toolChoice ?? { type: 'auto' };
  if (choice.type === 'required' && functions.length === 0) throw new Error('Required tool choice has no available tools.');
  if (choice.type === 'tool' && !functions.some(tool => tool.name === choice.toolName)) throw new Error('Forced tool is unavailable.');
  if (options.responseFormat?.type === 'json') throw new Error('Codex planner does not support caller JSON response formats.');
  const validators = new Map(functions.map(tool => [tool.name, z.fromJSONSchema(tool.inputSchema as Parameters<typeof z.fromJSONSchema>[0])]));
  return { functions, validators, choice, prompt: JSON.stringify({ history: options.prompt, tools: functions, toolChoice: choice }) };
}

function parseAction(text: string, prepared: ReturnType<typeof prepare>): NextAction {
  let action: any;
  try { action = JSON.parse(text); } catch { throw new Error('Planner returned invalid action JSON.'); }
  if (!action || typeof action !== 'object' || Array.isArray(action) || Object.keys(action).sort().join(',') !== 'argumentsJson,kind,text,toolName' || ['text', 'toolName', 'argumentsJson'].some(key => typeof action[key] !== 'string')) throw new Error('Planner returned invalid action shape.');
  if (action.kind === 'answer') {
    if (action.toolName !== '' || action.argumentsJson !== '' || ['required', 'tool'].includes(prepared.choice.type)) throw new Error('Planner answer violates tool choice or action shape.');
    return { kind: 'answer', text: action.text };
  }
  if (action.kind !== 'tool' || action.text !== '' || prepared.choice.type === 'none') throw new Error('Planner tool proposal violates action shape or tool choice.');
  if (prepared.choice.type === 'tool' && prepared.choice.toolName !== action.toolName) throw new Error('Planner ignored forced tool.');
  if (!prepared.functions.some(tool => tool.name === action.toolName)) throw new Error('Planner proposed an unknown tool.');
  let input: unknown;
  try { input = JSON.parse(action.argumentsJson); } catch { throw new Error('Planner returned invalid tool argument JSON.'); }
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('Tool arguments must be a JSON object.');
  if (!prepared.validators.get(action.toolName)!.safeParse(input).success) throw new Error('Planner arguments violate tool input schema.');
  return { kind: 'tool', toolName: action.toolName, input: JSON.stringify(input) };
}

const unknownUsage = (): LanguageModelV3Usage => ({ inputTokens: { total: undefined, noCache: undefined, cacheRead: undefined, cacheWrite: undefined }, outputTokens: { total: undefined, text: undefined, reasoning: undefined } });
export interface CodexRuntimeOptions {
  modelId?: string;
  cwd?: string;
  timeoutMs?: number;
  /** Dependency injection for isolated protocol tests. Production uses stdio. */
  transportFactory?: (cwd: string) => PlannerTransport;
}

export function createCodexRuntimeModel({ modelId, cwd = '/private/tmp/homeops-planner', timeoutMs = 120_000, transportFactory = dir => new StdioPlannerTransport(dir) }: CodexRuntimeOptions = {}): LanguageModelV3 {
  if (!isAbsolute(cwd)) throw new Error('Planner cwd must be absolute.');
  async function generate(options: LanguageModelV3CallOptions): Promise<LanguageModelV3GenerateResult> {
    const prepared = prepare(options);
    options.abortSignal?.throwIfAborted();
    await mkdir(cwd, { recursive: true });
    const transport = transportFactory(cwd);
    let timer: ReturnType<typeof setTimeout> | undefined;
    let abort: (() => void) | undefined;
    const interrupted = new Promise<never>((_, reject) => {
      timer = setTimeout(() => reject(new Error('Codex planner timed out.')), timeoutMs);
      abort = () => reject(options.abortSignal?.reason ?? new DOMException('Aborted', 'AbortError'));
      options.abortSignal?.addEventListener('abort', abort, { once: true });
      if (options.abortSignal?.aborted) abort();
    });
        let complete!: (value: any) => void;
    let fail!: (error: Error) => void;
    const completed = new Promise<any>((resolve, reject) => { complete = resolve; fail = reject; });
    void completed.catch(() => {});
    const eventFailure = completed.then(() => new Promise<never>(() => {}));
    void eventFailure.catch(() => {});
    const rpc = (method: string, params?: unknown) => Promise.race([transport.rpc(method, params), transport.failure, interrupted, eventFailure]);
    const messages: string[] = [];
    let threadId: string | undefined;
    transport.onNotification(message => {
      const params = message.params;
      if (params?.threadId && threadId && params.threadId !== threadId) return;
      if (message.method === 'item/started' || message.method === 'item/completed') {
        const item = params?.item;
        if (!item || !['userMessage', 'agentMessage', 'reasoning'].includes(item.type)) fail(new Error('Codex attempted an unsupported runtime item.'));
        else if (message.method === 'item/completed' && item.type === 'agentMessage') messages.push(item.text);
      }
      if (message.method === 'turn/completed') complete(params?.turn);
      if (message.method === 'error') fail(new Error('Codex inference failed.'));
      if (message.method === 'mcpServer/startupStatus/updated' && params?.status !== 'disabled') fail(new Error('Codex planner unexpectedly initialized an MCP server.'));
    });
    try {
      await rpc('initialize', { clientInfo: { name: 'homeops-planner', title: 'HomeOps local planner', version: '0.1.0' } });
      transport.notify('initialized');
      const auth = await rpc('account/read', { refreshToken: false });
      if (auth.account?.type !== 'chatgpt') throw new Error('A managed ChatGPT Codex login is required.');
      const catalog = await rpc('model/list', { limit: 100 });
      const models = catalog.data ?? catalog.models;
      if (!Array.isArray(models) || !models.length) throw new Error('No Codex runtime models are available.');
      const selected = modelId ? models.find(model => (model.model ?? model.id) === modelId) : models.find(model => model.isDefault) ?? models[0];
      if (!selected) throw new Error('Requested Codex runtime model is unavailable.');
      const selectedId = selected.model ?? selected.id;
      // Read only key names in memory. Never log or persist the configuration payload.
      const { config } = await rpc('config/read', { includeLayers: false });
      const disabledFeatureFlags = disabledFeatures.every(name => config?.features?.[name] === false);
      const hostSkillDiscoveryDisabled = config?.features?.skip_host_skill_discovery === true;
      if (!disabledFeatureFlags || !hostSkillDiscoveryDisabled || config?.web_search !== 'disabled') throw new Error('Codex planner capability restrictions were not applied.');
      const configOverrides: Record<string, unknown> = { web_search: 'disabled' };
      for (const name of Object.keys(config?.mcp_servers ?? {})) configOverrides[`mcp_servers.${name}.enabled`] = false;
      for (const name of Object.keys(config?.plugins ?? {})) configOverrides[`plugins.${name}.enabled`] = false;
      const started = await rpc('thread/start', { model: selectedId, cwd, sandbox: 'read-only', approvalPolicy: 'never', ephemeral: true, baseInstructions: instructions, config: configOverrides });
      threadId = started.thread.id;
      await rpc('turn/start', { threadId, input: [{ type: 'text', text: prepared.prompt }], effort: 'low', outputSchema: actionSchema });
      const turn = await Promise.race([completed, transport.failure, interrupted]);
      if (turn?.status !== 'completed') throw new Error('Codex planner turn did not complete.');
      if (messages.length !== 1) throw new Error('Expected one completed planner action.');
      const action = parseAction(messages[0], prepared);
      const warnings: LanguageModelV3GenerateResult['warnings'] = [];
      for (const key of ['temperature', 'topP', 'topK', 'seed', 'presencePenalty', 'frequencyPenalty', 'maxOutputTokens', 'stopSequences'] as const) if (options[key] !== undefined) warnings.push({ type: 'unsupported', feature: key });
      return {
        content: action.kind === 'answer' ? [{ type: 'text', text: action.text }] : [{ type: 'tool-call', toolCallId: randomUUID(), toolName: action.toolName, input: action.input }],
        finishReason: { unified: action.kind === 'answer' ? 'stop' : 'tool-calls', raw: 'completed' },
        usage: unknownUsage(), warnings, response: { id: turn.id, modelId: selectedId, timestamp: new Date() },
        providerMetadata: { codexRuntime: { buffered: true, disabledFeatureFlags, hostSkillDiscoveryDisabled, mcpDisabledCount: Object.keys(config?.mcp_servers ?? {}).length, pluginDisabledCount: Object.keys(config?.plugins ?? {}).length, unexpectedMcpStartup: false } },
      };
    } finally {
      clearTimeout(timer);
      if (abort) options.abortSignal?.removeEventListener('abort', abort);
      await transport.close();
    }
  }
  return {
    specificationVersion: 'v3', provider: 'codex-runtime', modelId: modelId ?? 'account-default', supportedUrls: {}, doGenerate: generate,
    async doStream(options) {
      const result = await generate(options);
      return { stream: new ReadableStream<LanguageModelV3StreamPart>({ start(controller) {
        controller.enqueue({ type: 'stream-start', warnings: result.warnings });
        controller.enqueue({ type: 'response-metadata', ...result.response });
        for (const content of result.content) {
          if (content.type === 'text') {
            const id = randomUUID();
            controller.enqueue({ type: 'text-start', id });
            controller.enqueue({ type: 'text-delta', id, delta: content.text });
            controller.enqueue({ type: 'text-end', id });
          } else if (content.type === 'tool-call') controller.enqueue(content);
        }
        controller.enqueue({ type: 'finish', finishReason: result.finishReason, usage: result.usage, providerMetadata: result.providerMetadata });
        controller.close();
      } }) };
    },
  };
}
