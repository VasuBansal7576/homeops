import { createHash, randomBytes, randomUUID, timingSafeEqual } from 'node:crypto';
import { createServer } from 'node:http';
import { existsSync } from 'node:fs';
import { chmod, mkdir, open, readFile, rename, rm } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRemoteJWKSet, jwtVerify } from 'jose';
import type { JWTVerifyGetKey } from 'jose';

export const ISSUER = 'https://auth.openai.com';
export const RESOURCE = 'https://api.openai.com/v1';
export const AUTHORIZE = `${ISSUER}/api/accounts/authorize`;
export const TOKEN = `${ISSUER}/api/accounts/oauth/token`;
export const JWKS = `${ISSUER}/.well-known/jwks.json`;
export const SCOPES = ['openid', 'profile', 'email', 'offline_access', 'resource.invoke', 'chatgpt.tokens.use.direct'];
export const DYNAMIC_CLIENT = 'dynamic_agent_client';

export class PlanError extends Error {
  code: string;
  constructor(code: string) { super(code); this.name = 'PlanError'; this.code = code; }
}

export interface Credential {
  client_id: string;
  host_id: string;
  issuer: string;
  subject: string;
  email?: string;
  tokens: { access_token: string; refresh_token?: string; id_token: string; token_type: 'Bearer' };
  scopes: string[];
  expires_at: number;
  saved_at: string;
}

export interface AuthStore {
  version: 1;
  host_id: string;
  accounts: Credential[];
  active_client_id?: string;
  pending_registration?: { client_id: string };
}

export interface PendingAuth {
  state: string;
  nonce: string;
  verifier: string;
  redirectURI: string;
  clientId: string;
  hostId: string;
  expectedSubject?: string;
}

export interface Discovery {
  issuer: string;
  authorization_endpoint: string;
  token_endpoint: string;
  jwks_uri: string;
  id_token_signing_alg_values_supported: string[];
}

type ObjectValue = Record<string, unknown>;
export function object(value: unknown): ObjectValue {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new PlanError('invalid_object');
  return value as ObjectValue;
}

function requiredString(value: unknown): string {
  if (typeof value !== 'string' || !value) throw new PlanError('missing_token_field');
  return value;
}

export function credentialPath(): string {
  if (process.env.HOMEOPS_AUTH_FILE) return resolve(process.env.HOMEOPS_AUTH_FILE);
  if (process.env.HOMEOPS_PROJECT_ROOT) return resolve(process.env.HOMEOPS_PROJECT_ROOT, '.local/auth.json');
  let directory = dirname(fileURLToPath(import.meta.url));
  while (true) {
    if (existsSync(resolve(directory, 'HOMEOPS_BUILD.md'))) return resolve(directory, '.local/auth.json');
    const parent = dirname(directory);
    if (parent === directory) throw new PlanError('set_HOMEOPS_AUTH_FILE_or_HOMEOPS_PROJECT_ROOT');
    directory = parent;
  }
}

export async function saveStore(path: string, store: AuthStore): Promise<void> {
  await mkdir(dirname(path), { recursive: true, mode: 0o700 });
  const temporary = `${path}.${randomUUID()}.tmp`;
  const file = await open(temporary, 'wx', 0o600);
  try {
    await file.writeFile(`${JSON.stringify(store, null, 2)}\n`);
    await file.sync();
    await file.close();
    await rename(temporary, path);
    await chmod(path, 0o600);
  } catch (error) {
    await file.close().catch(() => {});
    await rm(temporary, { force: true });
    throw error;
  }
}

export async function loadStore(path: string, create = false): Promise<AuthStore> {
  try {
    const value = object(JSON.parse(await readFile(path, 'utf8')));
    if (value.version !== 1 || typeof value.host_id !== 'string' || !/^urn:uuid:[0-9a-f-]{36}$/.test(value.host_id) || !Array.isArray(value.accounts)) throw new PlanError('invalid_auth_store');
    for (const entry of value.accounts) {
      const account = object(entry);
      const tokens = object(account.tokens);
      if (typeof account.client_id !== 'string' || account.client_id === DYNAMIC_CLIENT || typeof account.subject !== 'string' || account.host_id !== value.host_id || account.issuer !== ISSUER || !Array.isArray(account.scopes) || typeof account.expires_at !== 'number' || typeof tokens.access_token !== 'string' || typeof tokens.id_token !== 'string' || tokens.token_type !== 'Bearer') throw new PlanError('invalid_auth_store');
    }
    return value as unknown as AuthStore;
  } catch (error) {
    if (!create || (error as NodeJS.ErrnoException).code !== 'ENOENT') throw error;
    const store: AuthStore = { version: 1, host_id: `urn:uuid:${randomUUID()}`, accounts: [] };
    await saveStore(path, store);
    return store;
  }
}

export function activeAccount(store: AuthStore): Credential {
  const account = store.accounts.find(value => value.client_id === store.active_client_id);
  if (!account) throw new PlanError('homeops_login_required');
  return account;
}

export function createAttempt(hostId: string, port: number, account?: Credential, clientId = DYNAMIC_CLIENT): PendingAuth {
  return {
    state: randomBytes(32).toString('base64url'), nonce: randomBytes(32).toString('base64url'),
    verifier: randomBytes(48).toString('base64url'), redirectURI: `http://127.0.0.1:${port}/auth/callback`,
    clientId: account?.client_id || clientId, hostId, expectedSubject: account?.subject,
  };
}

export function authorizationURL(pending: PendingAuth, account?: Credential): string {
  const params = new URLSearchParams({
    client_id: pending.clientId, ext_agent_host_id: pending.hostId, response_type: 'code',
    redirect_uri: pending.redirectURI, scope: SCOPES.join(' '), resource: RESOURCE,
    state: pending.state, nonce: pending.nonce, code_challenge_method: 'S256',
    code_challenge: createHash('sha256').update(pending.verifier).digest('base64url'),
  });
  if (pending.clientId === DYNAMIC_CLIENT) params.set('agent_name_hint', 'HomeOps');
  if (account) {
    if (account.email) params.set('login_hint', account.email);
  }
  return `${AUTHORIZE}?${params}`;
}

export function validateCallback(url: URL, pending: PendingAuth): { code: string; clientId: string } {
  if (url.origin + url.pathname !== pending.redirectURI) throw new PlanError('invalid_callback_uri');
  for (const name of ['state', 'code', 'client_id', 'error']) {
    if (url.searchParams.getAll(name).length > 1) throw new PlanError('duplicate_callback_parameter');
  }
  const state = url.searchParams.get('state') || '';
  if (Buffer.byteLength(state) !== Buffer.byteLength(pending.state) || !timingSafeEqual(Buffer.from(state), Buffer.from(pending.state))) throw new PlanError('invalid_oauth_state');
  if (url.searchParams.has('error')) throw new PlanError(url.searchParams.get('error') === 'access_denied' ? 'oauth_access_denied' : 'oauth_authorization_failed');
  const clientId = url.searchParams.get('client_id') || (pending.clientId !== DYNAMIC_CLIENT ? pending.clientId : '');
  if (!clientId || clientId === DYNAMIC_CLIENT) throw new PlanError('missing_issued_client_id');
  if (pending.clientId !== DYNAMIC_CLIENT && clientId !== pending.clientId) throw new PlanError('oauth_client_changed');
  const code = url.searchParams.get('code');
  if (!code) throw new PlanError('missing_authorization_code');
  return { code, clientId };
}

export async function discover(fetcher: typeof fetch = fetch): Promise<Discovery> {
  const response = await fetcher(`${ISSUER}/.well-known/openid-configuration`, { signal: AbortSignal.timeout(15_000) });
  if (!response.ok) throw new PlanError('oidc_discovery_failed');
  const value = object(await response.json());
  if (value.issuer !== ISSUER || value.authorization_endpoint !== AUTHORIZE || value.token_endpoint !== TOKEN || value.jwks_uri !== JWKS || !Array.isArray(value.id_token_signing_alg_values_supported) || !value.id_token_signing_alg_values_supported.includes('RS256')) throw new PlanError('unexpected_oidc_metadata');
  return value as unknown as Discovery;
}

export async function validateIdentity(idToken: string, clientId: string, expected: { nonce?: string; subject?: string }, key: JWTVerifyGetKey = createRemoteJWKSet(new URL(JWKS))): Promise<{ subject: string; email?: string }> {
  const { payload } = await jwtVerify(idToken, key, { issuer: ISSUER, audience: clientId, algorithms: ['RS256'], requiredClaims: ['sub', 'exp', 'iat'] });
  if (expected.nonce && payload.nonce !== expected.nonce) throw new PlanError('invalid_oidc_nonce');
  if (expected.subject && payload.sub !== expected.subject) throw new PlanError('oauth_account_changed');
  if (!payload.sub) throw new PlanError('missing_identity_subject');
  return { subject: payload.sub, email: typeof payload.email === 'string' ? payload.email : undefined };
}

async function tokenGrant(params: URLSearchParams, fetcher: typeof fetch): Promise<ObjectValue> {
  const response = await fetcher(TOKEN, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: params, signal: AbortSignal.timeout(30_000) });
  const data = object(await response.json());
  if (!response.ok) {
    const code = typeof data.error === 'string' && /^[a-z_]+$/.test(data.error) ? data.error : 'token_exchange_failed';
    throw new PlanError(code);
  }
  return data;
}

function tokensFromResponse(data: ObjectValue, previous?: Credential): Pick<Credential, 'tokens' | 'scopes' | 'expires_at' | 'saved_at'> {
  if (typeof data.expires_in !== 'number' || data.expires_in <= 0 || String(data.token_type).toLowerCase() !== 'bearer') throw new PlanError('invalid_token_response');
  const scopes = typeof data.scope === 'string' ? data.scope.split(/\s+/).filter(Boolean) : previous?.scopes;
  if (!scopes) throw new PlanError('missing_granted_scopes');
  return {
    tokens: {
      access_token: requiredString(data.access_token), id_token: requiredString(data.id_token || previous?.tokens.id_token),
      refresh_token: typeof data.refresh_token === 'string' ? data.refresh_token : previous?.tokens.refresh_token, token_type: 'Bearer',
    }, scopes, expires_at: Date.now() + data.expires_in * 1000, saved_at: new Date().toISOString(),
  };
}

export function requirePlanScope(credential: Credential): void {
  if (!credential.scopes.includes('chatgpt.tokens.use.direct') || !credential.scopes.includes('resource.invoke')) throw new PlanError('chatgpt_plan_consent_required');
}

function replaceAccount(store: AuthStore, credential: Credential): AuthStore {
  const existing = store.accounts.find(value => value.client_id === credential.client_id);
  if (existing && existing.subject !== credential.subject) throw new PlanError('oauth_account_changed');
  return { version: 1, host_id: store.host_id, accounts: [...store.accounts.filter(value => value.client_id !== credential.client_id), credential], active_client_id: credential.client_id };
}

export async function login(options: { path?: string; port?: number; newAccount?: boolean; onURL: (url: string) => void; timeoutMs?: number; fetcher?: typeof fetch }): Promise<Credential> {
  const path = options.path || credentialPath();
  let store = await loadStore(path, true);
  const selected = options.newAccount ? undefined : store.accounts.find(value => value.client_id === store.active_client_id);
  await discover(options.fetcher);
  let pending: PendingAuth;
  let resolveCallback!: (value: { code: string; clientId: string }) => void;
  let rejectCallback!: (reason: unknown) => void;
  const callback = new Promise<{ code: string; clientId: string }>((resolve, reject) => { resolveCallback = resolve; rejectCallback = reject; });
  let consumed = false;
  const server = createServer((request, response) => {
    response.setHeader('Cache-Control', 'no-store');
    response.setHeader('Content-Type', 'text/plain; charset=utf-8');
    response.setHeader('Referrer-Policy', 'no-referrer');
    if (request.method !== 'GET' || !request.url?.startsWith('/auth/callback?') || consumed) { response.writeHead(404).end('Not found.'); return; }
    try {
      const url = new URL(request.url, pending.redirectURI);
      const result = validateCallback(url, pending);
      consumed = true;
      response.end('HomeOps received the authorization. Return to your terminal.');
      resolveCallback(result);
    } catch (error) {
      response.writeHead(400).end('HomeOps rejected this callback.');
      if (error instanceof PlanError && error.code !== 'invalid_oauth_state' && error.code !== 'invalid_callback_uri') { consumed = true; rejectCallback(error); }
    }
  });
  await new Promise<void>((resolveListen, reject) => { server.once('error', reject); server.listen(options.port || 0, '127.0.0.1', resolveListen); });
  const address = server.address();
  if (!address || typeof address === 'string') throw new PlanError('loopback_listener_failed');
  pending = createAttempt(store.host_id, address.port, selected, options.newAccount ? DYNAMIC_CLIENT : store.pending_registration?.client_id);
  const timer = setTimeout(() => rejectCallback(new PlanError('oauth_callback_timed_out')), options.timeoutMs || 300_000);
  try {
    options.onURL(authorizationURL(pending, selected));
    const { code, clientId } = await callback;
    if (!selected) {
      store = { ...store, pending_registration: { client_id: clientId } };
      await saveStore(path, store);
    }
    const data = await tokenGrant(new URLSearchParams({ grant_type: 'authorization_code', client_id: clientId, code, code_verifier: pending.verifier, redirect_uri: pending.redirectURI, resource: RESOURCE }), options.fetcher || fetch);
    const tokenData = tokensFromResponse(data);
    const identity = await validateIdentity(tokenData.tokens.id_token, clientId, { nonce: pending.nonce, subject: pending.expectedSubject });
    const credential: Credential = { client_id: clientId, host_id: store.host_id, issuer: ISSUER, ...identity, ...tokenData };
    await saveStore(path, replaceAccount(store, credential));
    return credential;
  } finally {
    clearTimeout(timer);
    await new Promise<void>(resolveClose => { server.close(() => resolveClose()); server.closeAllConnections(); });
  }
}

const refreshing = new Map<string, Promise<Credential>>();
export async function getCredential(path = credentialPath(), fetcher: typeof fetch = fetch): Promise<Credential> {
  const store = await loadStore(path);
  const credential = activeAccount(store);
  requirePlanScope(credential);
  if (credential.expires_at > Date.now() + 60_000) return credential;
  let operation = refreshing.get(path);
  if (!operation) {
    operation = (async () => {
      if (!credential.tokens.refresh_token) throw new PlanError('homeops_reauthorization_required');
      await discover(fetcher);
      const data = await tokenGrant(new URLSearchParams({ grant_type: 'refresh_token', client_id: credential.client_id, refresh_token: credential.tokens.refresh_token, resource: RESOURCE }), fetcher);
      const tokenData = tokensFromResponse(data, credential);
      if (data.id_token) await validateIdentity(tokenData.tokens.id_token, credential.client_id, { subject: credential.subject });
      const renewed = { ...credential, ...tokenData };
      await saveStore(path, replaceAccount(store, renewed));
      requirePlanScope(renewed);
      return renewed;
    })().finally(() => refreshing.delete(path));
    refreshing.set(path, operation);
  }
  return operation;
}

export async function listModels(path = credentialPath(), fetcher: typeof fetch = fetch): Promise<Array<{ slug: string; display_name: string }>> {
  const credential = await getCredential(path, fetcher);
  const response = await fetcher(`${RESOURCE}/models`, { headers: { Authorization: `Bearer ${credential.tokens.access_token}` }, signal: AbortSignal.timeout(30_000) });
  if (!response.ok) throw new PlanError(`model_catalog_http_${response.status}`);
  const data = object(await response.json());
  if (!Array.isArray(data.models)) throw new PlanError('invalid_account_model_catalog');
  return data.models.map(object).filter(model => model.visibility === 'list' && typeof model.slug === 'string' && typeof model.display_name === 'string').map(model => ({ slug: model.slug as string, display_name: model.display_name as string }));
}
