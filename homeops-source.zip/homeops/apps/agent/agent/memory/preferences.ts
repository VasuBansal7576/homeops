import { defineMemory } from 'eve/memory';
import { byPrincipal } from 'eve/memory/scope';
import { fileMemory, MemoryDocumentConflictError } from 'eve/memory/file';
import { home } from '../lib/home';

export default defineMemory({
  description: 'Remember stable household notes. Appointment availability must be saved through household_command preference.setSchedule. Memory notes do not enforce scheduling. Structured household records remain authoritative and memory never authorizes a booking.',
  scope: byPrincipal,
  provider: fileMemory({ backend: {
    async read({ key }) {
      const row = home.getMemoryDocument(key);
      return row ? { content: row.content, version: String(row.version) } : null;
    },
    async write({ key, content, expectedVersion }) {
      try {
        const row = home.putMemoryDocument(key, content, expectedVersion === null ? null : Number(expectedVersion));
        return { content: row.content, version: String(row.version) };
      } catch (error) {
        if (error instanceof Error && error.name === 'MemoryDocumentConflictError') throw new MemoryDocumentConflictError(key);
        throw error;
      }
    },
  } }),
});
