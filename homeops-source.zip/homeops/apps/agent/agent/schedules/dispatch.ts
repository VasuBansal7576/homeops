import { defineSchedule } from 'eve/schedules';

export default defineSchedule({
  cron: '* * * * *',
  async run() {
    const response = await fetch(`${process.env.HOMEOPS_AGENT_URL ?? 'http://127.0.0.1:43111'}/api/homeops/dispatch`, { method: 'POST', headers: { authorization: `Bearer ${process.env.HOMEOPS_SERVICE_SECRET}`, 'content-type': 'application/json' }, body: '{}' });
    if (!response.ok) throw new Error(`HomeOps scheduled dispatch failed with ${response.status}`);
  },
});
