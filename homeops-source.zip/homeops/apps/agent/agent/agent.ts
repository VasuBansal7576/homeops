import { defineAgent } from 'eve';
import { existsSync, readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { createCodexRuntimeModel } from '../src/model/codex-runtime.ts';

const root = process.env.HOMEOPS_ROOT ?? resolve(process.cwd(), '../..');
const settings = resolve(root, '.local/model.json');
const model = existsSync(settings) ? JSON.parse(readFileSync(settings, 'utf8')).model : undefined;

export default defineAgent({
  model: createCodexRuntimeModel({ modelId: model, cwd: resolve(root, '.local/planner') }),
  modelContextWindowTokens: 128000,
  defaultTools: false,
  experimental: { workflow: { retention: 'default' } },
});
