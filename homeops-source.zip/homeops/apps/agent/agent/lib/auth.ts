import { timingSafeEqual } from 'node:crypto';
import type { AuthFn } from 'eve/channels/auth';

export const operator = { authenticator: 'homeops', principalId: 'operator', principalType: 'user' as const, attributes: {} };
export const serviceAuth: AuthFn<Request> = request => {
  const secret = process.env.HOMEOPS_SERVICE_SECRET;
  if (!secret) return null;
  const provided = Buffer.from(request.headers.get('authorization') ?? '');
  const expected = Buffer.from(`Bearer ${secret}`);
  return provided.length === expected.length && timingSafeEqual(provided, expected) ? operator : null;
};
