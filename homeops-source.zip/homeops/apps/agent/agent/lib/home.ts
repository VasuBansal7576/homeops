import { resolve } from 'node:path';
import { openHomeOps, type Actor } from '../../src/homeops/index.ts';

export const home = openHomeOps({ filename: process.env.HOMEOPS_DB ?? resolve(process.env.HOMEOPS_ROOT ?? '../..', '.local/homeops.sqlite') });
export const operatorActor: Actor = { principalId: 'operator', role: 'operator' };
export const schedulerActor: Actor = { principalId: 'homeops-scheduler', role: 'scheduler' };
export function actorFor(principal: { principalId: string } | null | undefined): Actor {
  if (principal?.principalId !== 'operator') throw new Error('Authenticated household operator required');
  return operatorActor;
}
