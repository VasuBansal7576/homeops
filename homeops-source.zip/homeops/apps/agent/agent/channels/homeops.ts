import { randomUUID } from 'node:crypto';
import { defineChannel, GET, POST, type RouteHandlerArgs } from 'eve/channels';
import { z } from 'zod';
import { datasetCatalog } from '../../../../datasets/catalog.ts';
import { CommandEnvelopeSchema } from '../../../../packages/contracts/src/index.ts';
import { HomeOpsError } from '../../src/homeops/index.ts';
import { home, operatorActor, schedulerActor } from '../lib/home';
import { operator, serviceAuth } from '../lib/auth';

function failure(error: unknown) {
  const code = error instanceof HomeOpsError ? error.code : error instanceof z.ZodError ? 'invalid_input' : 'internal';
  const status = code === 'unauthorized' ? 401 : code === 'not_found' ? 404 : code === 'invalid_input' ? 400 : code === 'internal' ? 500 : 409;
  return Response.json({ error: { code, message: error instanceof Error ? error.message : 'HomeOps request failed.', retryable: error instanceof HomeOpsError && error.retryable } }, { status });
}
const authenticate = async (request: Request) => Boolean(await serviceAuth(request));
async function dispatch(ctx: RouteHandlerArgs) {
  await home.execute(schedulerActor, { id: `tick:${randomUUID()}`, type: 'work.tick' });
  const sessionIds: string[] = [];
  for (const pending of home.pendingJobs(schedulerActor)) {
    const owner = randomUUID();
    const job = home.claimJob(schedulerActor, { jobId: pending.id, owner });
    if (!job) continue;
    try {
      let session = await ctx.resolveSession(job.address);
      if (!session) {
        const item = home.snapshot(operatorActor).cases.find(c => c.id === job.caseId);
        const inbox = home.snapshot(operatorActor).inbox.find(i => i.id === job.inboxId);
        const providerMode = home.snapshot(operatorActor).workspace;
        const simulated = providerMode.status === 'ready' && providerMode.providerMode === 'simulated';
        const nextStep = job.kind === 'warranty' ? 'Review the stored warranty. Fault-specific coverage is unverified. A warning does not arrange a service visit.' : job.kind === 'confirmation' ? 'Ask whether the provider attended. Do not assume confirmation, completion, or payment.' : simulated ? 'Compare simulated providers against the budget and request permission before booking.' : 'Use only sourced entered quotes. Approval creates a local service plan awaiting contact; ask for a sourced confirmation of actual arrangements.';
        session = await ctx.from(job.address).send(`HomeOps noticed ${inbox?.title ?? item?.title ?? 'household care'} needs attention. ${inbox?.body ?? item?.reason ?? 'Check the saved household records.'} ${nextStep} ${simulated ? 'Provider interactions are simulated.' : 'No provider interaction is performed by HomeOps.'}`, { auth: operator });
      }
      home.bindJobSession(schedulerActor, { jobId: job.id, owner, sessionId: session.id });
      sessionIds.push(session.id);
    } catch (error) {
      home.releaseJob(schedulerActor, { jobId: job.id, owner });
      throw error;
    }
  }
  return sessionIds;
}
export default defineChannel({
  routes: [
    GET('/api/homeops/datasets', async request => {
      if (!await authenticate(request)) return Response.json({ error: { code: 'unauthorized' } }, { status: 401 });
      return Response.json({ datasets: datasetCatalog });
    }),
    GET('/api/homeops/export', async request => {
      if (!await authenticate(request)) return Response.json({ error: { code: 'unauthorized' } }, { status: 401 });
      try { return Response.json(home.exportDataset(operatorActor)); } catch (error) { return failure(error); }
    }),
    GET('/api/homeops/snapshot', async request => {
      if (!await authenticate(request)) return Response.json({ error: { code: 'unauthorized' } }, { status: 401 });
      return Response.json(home.snapshot(operatorActor));
    }),
    POST('/api/homeops/commands', async (request, ctx) => {
      if (!await authenticate(request)) return Response.json({ error: { code: 'unauthorized' } }, { status: 401 });
      try {
        const input = CommandEnvelopeSchema.parse(await request.json());
        const result = await home.execute(operatorActor, { id: input.commandId, ...input.command });
        if (['clock.set', 'fixture.change', 'case.openUrgent', 'case.confirmAppointment', 'asset.upsert', 'household.update'].includes(input.command.type)) await dispatch(ctx);
        return Response.json(result);
      } catch (error) { return failure(error); }
    }),
    POST('/api/homeops/dispatch', async (request, ctx) => {
      if (!await authenticate(request)) return Response.json({ error: { code: 'unauthorized' } }, { status: 401 });
      try { return Response.json({ sessionIds: await dispatch(ctx) }); } catch (error) { return failure(error); }
    }),
    POST('/api/homeops/discuss', async (request, ctx) => {
      if (!await authenticate(request)) return Response.json({ error: { code: 'unauthorized' } }, { status: 401 });
      try {
        const { caseId } = z.object({ caseId: z.string().min(1) }).parse(await request.json());
        const item = home.snapshot(operatorActor).cases.find(c => c.id === caseId);
        if (!item) throw new HomeOpsError('not_found', 'Case not found');
        if (item.sessionId) {
          if (item.approval?.status === 'pending' && !item.approval.sessionId) await ctx.attachSession(item.sessionId).send(`Please review my selected current quote for ${item.title} and request fresh approval before booking. Dismiss any outdated request first.`, { auth: operator });
          return Response.json({ sessionId: item.sessionId });
        }
        const address = `homeops:${item.id}`;
        const current = await ctx.resolveSession(address);
        const session = current ?? await ctx.from(address).send(`Help me with ${item.title}. Review the saved case and its current next step.`, { auth: operator });
        return Response.json({ sessionId: session.id });
      } catch (error) { return failure(error); }
    }),
  ],
});
