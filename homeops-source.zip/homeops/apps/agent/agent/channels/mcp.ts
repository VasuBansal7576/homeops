import { mcpChannel } from 'eve/channels/mcp';
import { serviceAuth } from '../lib/auth';

export default mcpChannel({ auth: serviceAuth });
