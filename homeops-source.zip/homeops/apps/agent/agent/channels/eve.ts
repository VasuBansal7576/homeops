import { eveChannel } from "eve/channels/eve";
import { serviceAuth } from '../lib/auth';

export default eveChannel({
  auth: serviceAuth,
});
