import { defineTool } from 'eve/tools';
import { z } from 'zod';
import { PublicCommandSchema } from '../../../../packages/contracts/src/index.ts';
import { home, actorFor } from '../lib/home';

export default defineTool({
  description: 'Update household records, initialize an empty workspace, edit revision-checked records, request offers according to workspace mode, enter sourced manual quotes and confirm manual plans, choose a stored offer by expected revision, confirm completion separately, or record and correct confirmed charges. Use preference.setSchedule for scheduling requests with ISO weekdays 1 Monday through 7 Sunday, one HH:mm daily window at least one hour long, Asia/Kolkata. It enforces availability and invalidates unaccepted quotes and consent when changed. preference.save stores notes only and does not enforce scheduling. Choosing an offer prepares approval and never books. Never record a quote as paid spending. Use book_service after choosing an affordable offer.',
  inputSchema: z.object({ command: PublicCommandSchema }),
  async execute({ command }, ctx) {
    const actor = actorFor(ctx.session.auth.current);
    const result = await home.execute(actor, { id: `tool:${ctx.callId}`, ...command });
    const caseId = 'caseId' in command ? command.caseId : undefined;
    for (const job of home.pendingJobs(actor)) {
      if (caseId && job.caseId !== caseId) continue;
      if (!caseId && !['clock.set', 'fixture.change', 'case.openUrgent'].includes(command.type)) continue;
      const owner = `session:${ctx.session.id}`;
      if (home.claimJob(actor, { jobId: job.id, owner })) home.bindJobSession(actor, { jobId: job.id, owner, sessionId: ctx.session.id });
    }
    return { result, household: home.snapshot(actor) };
  },
});
