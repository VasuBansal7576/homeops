import { defineTool } from 'eve/tools';
import { z } from 'zod';
import { home, actorFor } from '../lib/home';

export default defineTool({
  description: 'Read authoritative household history, policies, cases, quotes, actual confirmed expenses, preferences, and sources. Unknown facts remain unknown. Call before answering factual household questions.',
  inputSchema: z.object({}),
  execute(_input, ctx) { return home.snapshot(actorFor(ctx.session.auth.current)); },
});
