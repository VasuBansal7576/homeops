import { defineTool } from 'eve/tools';
import { z } from 'zod';
import { home, actorFor } from '../lib/home';
import { HomeOpsError } from '../../src/homeops/index';

function selected(approvalId: string) {
  const item = home.snapshot({ principalId: 'operator', role: 'operator' }).cases.find(c => c.approval?.id === approvalId);
  if (!item?.approval) throw new Error('Stored approval not found');
  return { item, approval: item.approval };
}
export default defineTool({
  description: 'Book the exact stored provider quote and appointment. Always requests durable human approval. Supply caseId and approvalId returned by choosing an offer. Simulated mode creates an unpaid simulated reservation. Manual mode creates a local service plan needing provider contact and sourced confirmation, with no provider acceptance. Neither records completion or payment.',
  inputSchema: z.object({ caseId: z.string(), approvalId: z.string() }),
  approval: {
    request: ({ session, callId, toolInput }) => {
      if (!toolInput) return { type: 'denied', reason: 'Missing stored approval.' };
      const actor = actorFor(session.auth.current);
      const { item, approval } = selected(toolInput.approvalId);
      if (item.id !== toolInput.caseId) return { type: 'denied', reason: 'Approval belongs to another case.' };
      try { home.bindApproval(actor, { approvalId: approval.id, callId, sessionId: session.id }); }
      catch (error) { if (error instanceof HomeOpsError) return { type: 'denied', reason: error.message }; throw error; }
      return 'user-approval';
    },
    prompt: ({ input }) => {
      const { item, approval } = selected(input.approvalId);
      const terms = approval.terms;
      const offer = item.offers.find(o => o.id === terms.offerId);
      const amount = terms.charge.kind === 'fixed' ? terms.charge.total.minor : terms.charge.fee.minor;
      const price = new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 2, minimumFractionDigits: 0 }).format(amount / 100);
      const date = new Intl.DateTimeFormat('en-IN', { dateStyle: 'medium', timeStyle: 'short', timeZone: 'Asia/Kolkata' });
      return `Approve ${offer?.providerName} for ${price}, ${date.format(new Date(terms.slot.start))} to ${date.format(new Date(terms.slot.end))} IST? Quote revision ${terms.revision}. ${terms.charge.kind === 'inspection' ? 'Inspection fee only. Parts and final cost unknown.' : 'Fixed service total.'} ${terms.fulfillment === 'manual_plan' ? `Source ${terms.sourceId}. Approval creates a local plan awaiting provider contact, not a confirmed booking. Record a separate sourced confirmation after contacting the provider.` : 'Provider interaction is simulated.'}`;
    },
    response: async ({ request, response, session }) => {
      try {
        if (!request.toolInput) return { status: 'rejected', reason: 'Missing stored approval input.' };
        const actor = actorFor(request.principal);
        actorFor(response.principal);
        await home.settleApproval(actor, { id: `consent:${request.requestId}:${response.decision}`, approvalId: request.toolInput.approvalId, decision: response.decision === 'approve' ? 'approve' : 'deny', responderId: response.principal.principalId, requestId: request.requestId, callId: request.callId, sessionId: session.id });
        return { status: 'allowed' };
      } catch (error) { return { status: 'rejected', reason: error instanceof Error ? error.message : 'Exact approval is no longer valid.' }; }
    },
  },
  async execute({ caseId, approvalId }, ctx) {
    const actor = actorFor(ctx.session.auth.current);
    const result = await home.execute(actor, { id: `booking:${ctx.callId}`, type: 'case.book', caseId, approvalId });
    return { result, household: home.snapshot(actor) };
  },
});
