# Run HomeOps locally

HomeOps connects household maintenance, warranty evidence, quotes, exact approval, service history and confirmed expenses. It implements an Alexa+ simulated experience with a real local agent and MCP interface. It does not connect to an Alexa device. Voice input and spoken responses use local speech processing with explicit recording and transcript review.

The portable-data revision introduces explicit demo or personal setup, shared validated datasets and record editing. Acceptance verification is tracked separately from this source snapshot.

## Start

Use Node.js 26.12.0, pinned in `.nvmrc`. Install the [Codex CLI](https://developers.openai.com/codex/cli/) and sign in with your own supported account. HomeOps does not read or copy Codex credential files.

```sh
node --version
codex login
codex login status
npm ci
npm run build
npm start
```

Open http://127.0.0.1:43110 and enter `homeops-demo`. Choose **Try a demo**, **Set up my household**, or import household JSON. Startup creates empty storage without inserting or restoring demo records. One workspace contains one household. The supported region is INR and Asia/Kolkata.

The gateway uses port 43110, Eve 43111 and web 43112. Keep the terminal running for scheduled work. Ctrl+C stops the services. Set `PORT` to move all three ports and `HOMEOPS_PASSWORD` to choose the local password. Keep the subscription-backed application local.

Model access is separate from the application password. The adapter discovers your app-server model catalog; optional `.local/model.json` can select an available `model`. Unavailable inference returns an error. Household facts and messages supplied during inference are sent to the configured model. Inherited runtime tools are disabled. Eve executes validated household actions and owns durable approval waits. Output is buffered until structured generation completes.

Free evaluator inference through November 20 remains unverified. The owner's account is not proof of another account's entitlement or quota. The alternate direct HomeOps Sign in with ChatGPT adapter remains inactive after consent-service timeouts. `npm run login` belongs to that alternate route.

## Local voice setup

Speech input uses actual Whisper base.en through `whisper-cli`. Speech output uses macOS `say`, or installed `espeak-ng` on Linux. `ffmpeg` decodes supported audio. No cloud speech API or speech account is required. Model reasoning still sends the reviewed transcript and household context to the configured model, as described above.

On macOS, install the speech binaries from Homebrew, then download and verify the model:

```sh
brew install whisper-cpp ffmpeg
node scripts/setup-voice.mjs
```

On Linux, install ffmpeg and espeak-ng with your package manager and build/install whisper.cpp from its [official instructions](https://github.com/ggml-org/whisper.cpp). Then run the same setup script. The script downloads about142MiB of model weights and verifies SHA256 `a03779c86df3323075f5e796cb2ce5029f00ec8869eee3fdfb897afe36c6d002`. `.local/voice` is excluded from source. Set `HOMEOPS_WHISPER_MODEL` to use an explicit existing model, and `HOMEOPS_WHISPER_BIN` / `HOMEOPS_FFMPEG_BIN` if the binaries are outside PATH. Missing speech prerequisites return a visible unavailable state; typed chat remains usable.

In the assistant, start the microphone explicitly, stop recording, review/edit the transcript, then press Send. A labeled recorded-audio input uses the same transcriber. Clips are limited to30seconds and8MiB. Silence, unsupported formats and permission failures return recoverable errors. Raw audio is processed in temporary files and removed after the response. No microphone starts on page load. Transcription alone changes no household records or approvals.

If the browser has not returned capture access after20seconds, the app restores its controls and reports that no recording started. Finish the normal browser permission prompt and try Record again. Microphone details shows the observed browser permission, API support and last capture stage. A permission report alone does not prove recording works. After a real microphone clip, its normal audio preview and optional download use the exact captured audio. The preview remains only in the current tab until a new recording, discard or unmount. Nothing downloads automatically.

Use the reply playback controls to hear the actual assistant text. New replies speak only after the operator enables read-aloud. Stop and ordinary audio controls remain available. An uploaded test utterance proves real audio transcription, not a live microphone recording. All service approval still uses the durable explicit approval card.

Run `node scripts/verify-voice-capture.cjs` for controlled component lifecycle checks. These exercise pending permission recovery, late streams, error states and exact recording-preview cleanup with substituted browser APIs. They do not establish a physical microphone or a live spoken end-to-end request; test that separately in the browser.

## Data and everyday use

`datasets/maple-demo.json` contains all six required scenarios and historical expenses. `datasets/cedar-2032.json` uses different IDs, dates and a generic appliance. Both are synthetic. Reproduce their deterministic bytes with `npm run data:generate`. To initialize Maple explicitly through the CLI on an empty workspace, run `npm run seed` before startup instead of using the browser chooser. Ordinary startup and seed do not overwrite an existing household.

Personal setup starts without demo appliances, providers or invoices. In **Household**, add an appliance, known service date and source, optional maintenance policy and warranty terms. Unknown facts can stay blank. Add providers and contact notes. Edit household budget and warranty-warning lead time. New cases use the household budget. **Edit preferences** stores weekdays and one daily appointment window. Visits use exact one-hour slots inside that window. Multiple daily windows and alternating weeks are unsupported.

Import uses version 1 of `homeops.household`, validated by `HouseholdDatasetSchema`. It initializes only an empty workspace. The same input shapes serve generated data and entry forms. Export contains current master records and confirmed expenses. It is not a backup of conversations, pending approvals or workflows. Start another isolated workspace to use a different household rather than replacing active operational state.

Demo providers generate labeled simulated offers and reservations. For personal data, enter a quote from an actual message or document with amount, appointment, expiry and source. HomeOps performs no provider contact. Exact approval creates a local service plan **Awaiting your contact**, with no booking receipt or provider acceptance. Record a sourced confirmation after arranging the appointment yourself. Record completion and the confirmed expense separately.

Historical expenses can cite their appliance and invoice source without an invented service event. Corrections preserve an audit history and change totals. Quotes, unpaid reservations and approved plans are not confirmed spending.

## Exercise the demo

1. Choose Maple and inspect appliance records, warranties and spending on **Overview**.
2. Advance **Demo clock** to the AC due date. Inspect the persistent proactive inbox and reload.
3. Compare the preferred provider's decline, expensive alternative and affordable offer. Review provider, amount, appointment and quote revision before approval.
4. Reject a request and check that no reservation appears. Obtain fresh terms and approve. Booking must not change service history or spending.
5. Confirm appointment arrangements and record completion separately. Appointment confirmation does not independently prove attendance. Inspect the next maintenance date.
6. Exercise purifier replacement, washer warranty warning, recurring gardening, missed confirmation and urgent sink inspection. Parts and final repair cost remain unknown for inspection-only terms.
7. Record/correct a charge in **Expenses**. Open **MCP**, connect, inspect actual initialize/tools/list receipts and ask the agent to recall the persisted total.

Changes to unaccepted terms, budget or availability invalidate consent. Already accepted simulated operations reconcile to their original receipt. Saved appointments are not silently rescheduled.

## Verify

```sh
npm test
npm run typecheck
node_modules/.bin/tsc --noEmit -p apps/web/tsconfig.json
npm run build
```

With HomeOps running:

```sh
npm run verify
node --import tsx scripts/verify-portable.ts
npm run verify -- --model
```

The model verifier requires an initialized synthetic household. For an explicitly authorized personal-record check, add `--allow-personal-model`. The portability check verifies authenticated catalog/export and canonical records. Run it with `--expect-empty` before setup to assert empty startup. Optional `--dataset datasets/cedar-2032.json` explicitly initializes that file only when empty and checks command replay and export. Set `HOMEOPS_URL`, `HOMEOPS_PASSWORD` and optional `HOMEOPS_EVIDENCE_DIR` for isolated runtimes.

`scripts/verify-journey.ts` and `scripts/verify-mcp.ts` exercise synthetic native/MCP approval across same-build restart. Use a disposable Maple workspace. Set a fresh `HOMEOPS_VERIFY_RUN` suffix and retain it across preparation and continuation. Inspect the flags before use. `agent_start` is not idempotent. Save invocation identifiers and reconcile ambiguous starts before another invocation. Do not rebuild while an approval waits.

## Preserve or reset

Preserve `.local/homeops.sqlite` and `apps/agent/.eve/.workflow-data` across normal restarts. SQLite records and Eve workflows are separate durability boundaries. Eve is pinned to 0.81.1. Runtime state, credentials and recordings are ignored by Git.

Stop the application before `npm run seed -- --reset`. This deletes the SQLite database, journals and preferences and explicitly initializes Maple. Use it only on disposable demo state. It does not remove Eve workflows, browser storage or saved MCP references. Use a fresh checkout and fresh browser origin for a complete isolated evaluation. Never continue old workflows against a reset household.

This source snapshot excludes credentials, runtime state, private delivery notes, captures and Git history. SOURCE_MANIFEST.json identifies its source revision and content hashes. HomeOps is MIT licensed; dependencies retain their licenses.
