import maple from './maple-demo.json' with { type: 'json' };
import cedar from './cedar-2032.json' with { type: 'json' };
import { HouseholdDatasetSchema } from '../packages/contracts/src/index.ts';
export const datasetCatalog = [maple, cedar].map(value => { const dataset = HouseholdDatasetSchema.parse(value); return { id: dataset.metadata.id, name: dataset.metadata.name, description: dataset.metadata.description, dataset }; });
export const demoDataset = datasetCatalog[0]!.dataset;
