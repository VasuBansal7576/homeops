import { writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { HouseholdDatasetSchema, type HouseholdDataset } from '../packages/contracts/src/index.ts';
const source = {
  "format": "homeops.household",
  "version": 1,
  "metadata": {
    "id": "maple-demo",
    "name": "Maple household demo",
    "description": "Six reproducible journeys: AC, purifier, warranty, garden, missed confirmation and urgent leak, with historical expenses.",
    "kind": "synthetic",
    "provenance": "Deterministic HomeOps synthetic fixture. No real household or provider claims."
  },
  "providerMode": "simulated",
  "demoNow": "2026-10-21T09:00:00+05:30",
  "household": {
    "id": "home",
    "name": "The Maple household",
    "budget": {
      "minor": 250000,
      "currency": "INR"
    },
    "warrantyNoticeDays": 7
  },
  "schedulingPreferences": {
    "daysOfWeek": [
      1,
      2,
      3,
      4,
      5
    ],
    "startTime": "09:00",
    "endTime": "12:00",
    "timezone": "Asia/Kolkata"
  },
  "notes": [
    "Prefer Trusted Air Services. Ask before booking. Weekday morning appointments suit the household."
  ],
  "appliances": [
    {
      "id": "ac",
      "name": "Living room AC",
      "kind": "ac",
      "location": "Living room",
      "lastService": {
        "performedOn": "2026-04-25",
        "sourceId": "invoice:seed:ac"
      },
      "maintenance": {
        "intervalDays": 180,
        "sourceId": "policy:ac"
      },
      "warranty": {
        "ends": "2027-03-15",
        "sourceId": "warranty:seed:ac",
        "terms": "Fixture manufacturer coverage; consumables and misuse excluded."
      }
    },
    {
      "id": "purifier",
      "name": "Kitchen purifier",
      "kind": "purifier",
      "location": "Kitchen",
      "lastService": {
        "performedOn": "2026-05-01",
        "sourceId": "invoice:seed:purifier"
      },
      "maintenance": {
        "intervalDays": 180,
        "sourceId": "policy:purifier"
      },
      "warranty": {
        "ends": "2027-05-01",
        "sourceId": "warranty:seed:purifier",
        "terms": "Fixture manufacturer coverage; consumables and misuse excluded."
      }
    },
    {
      "id": "washer",
      "name": "Washing machine",
      "kind": "washer",
      "location": "Utility room",
      "lastService": {
        "performedOn": "2026-07-10",
        "sourceId": "invoice:seed:washer"
      },
      "maintenance": {
        "intervalDays": 365,
        "sourceId": "policy:washer"
      },
      "warranty": {
        "ends": "2026-11-01",
        "sourceId": "warranty:seed:washer",
        "terms": "Fixture manufacturer coverage; consumables and misuse excluded."
      }
    },
    {
      "id": "garden",
      "name": "Terrace garden",
      "kind": "garden",
      "location": "Terrace",
      "lastService": {
        "performedOn": "2026-10-01",
        "sourceId": "invoice:seed:garden"
      },
      "maintenance": {
        "intervalDays": 30,
        "sourceId": "policy:garden"
      },
      "warranty": null
    },
    {
      "id": "sink",
      "name": "Kitchen sink",
      "kind": "sink",
      "location": "Kitchen",
      "lastService": {
        "performedOn": "2025-12-09",
        "sourceId": "invoice:seed:sink"
      },
      "maintenance": null,
      "warranty": null
    }
  ],
  "providers": [
    {
      "id": "preferred",
      "name": "Trusted Air Services",
      "serviceKind": "ac",
      "preferred": true,
      "available": true,
      "contactNote": null,
      "simulation": {
        "declines": true,
        "amount": {
          "minor": 170000,
          "currency": "INR"
        }
      }
    },
    {
      "id": "premium",
      "name": "Premium Home Cooling",
      "serviceKind": "ac",
      "preferred": false,
      "available": true,
      "contactNote": null,
      "simulation": {
        "declines": false,
        "amount": {
          "minor": 320000,
          "currency": "INR"
        }
      }
    },
    {
      "id": "coolcare",
      "name": "CoolCare Local",
      "serviceKind": "ac",
      "preferred": false,
      "available": true,
      "contactNote": null,
      "simulation": {
        "declines": false,
        "amount": {
          "minor": 180000,
          "currency": "INR"
        }
      }
    },
    {
      "id": "pure-preferred",
      "name": "Trusted Pure Water",
      "serviceKind": "purifier",
      "preferred": true,
      "available": true,
      "contactNote": null,
      "simulation": {
        "declines": true,
        "amount": {
          "minor": 200000,
          "currency": "INR"
        }
      }
    },
    {
      "id": "pure-premium",
      "name": "Premium Filter Care",
      "serviceKind": "purifier",
      "preferred": false,
      "available": true,
      "contactNote": null,
      "simulation": {
        "declines": false,
        "amount": {
          "minor": 340000,
          "currency": "INR"
        }
      }
    },
    {
      "id": "pure-local",
      "name": "Pure Water Local",
      "serviceKind": "purifier",
      "preferred": false,
      "available": true,
      "contactNote": null,
      "simulation": {
        "declines": false,
        "amount": {
          "minor": 220000,
          "currency": "INR"
        }
      }
    },
    {
      "id": "garden-preferred",
      "name": "Trusted Terrace Care",
      "serviceKind": "garden",
      "preferred": true,
      "available": true,
      "contactNote": null,
      "simulation": {
        "declines": true,
        "amount": {
          "minor": 100000,
          "currency": "INR"
        }
      }
    },
    {
      "id": "garden-premium",
      "name": "Premium Garden Care",
      "serviceKind": "garden",
      "preferred": false,
      "available": true,
      "contactNote": null,
      "simulation": {
        "declines": false,
        "amount": {
          "minor": 300000,
          "currency": "INR"
        }
      }
    },
    {
      "id": "garden-local",
      "name": "Terrace Garden Local",
      "serviceKind": "garden",
      "preferred": false,
      "available": true,
      "contactNote": null,
      "simulation": {
        "declines": false,
        "amount": {
          "minor": 120000,
          "currency": "INR"
        }
      }
    },
    {
      "id": "washer-local",
      "name": "Appliance Care Local",
      "serviceKind": "washer",
      "preferred": false,
      "available": true,
      "contactNote": null,
      "simulation": {
        "declines": false,
        "amount": {
          "minor": 150000,
          "currency": "INR"
        }
      }
    },
    {
      "id": "plumber-preferred",
      "name": "Trusted Plumbing",
      "serviceKind": "sink",
      "preferred": true,
      "available": true,
      "contactNote": null,
      "simulation": {
        "declines": true,
        "amount": {
          "minor": 40000,
          "currency": "INR"
        }
      }
    },
    {
      "id": "plumber-premium",
      "name": "Premium Plumbing",
      "serviceKind": "sink",
      "preferred": false,
      "available": true,
      "contactNote": null,
      "simulation": {
        "declines": false,
        "amount": {
          "minor": 300000,
          "currency": "INR"
        }
      }
    },
    {
      "id": "plumber-local",
      "name": "Neighbourhood Plumbing",
      "serviceKind": "sink",
      "preferred": false,
      "available": true,
      "contactNote": null,
      "simulation": {
        "declines": false,
        "amount": {
          "minor": 50000,
          "currency": "INR"
        }
      }
    }
  ],
  "expenses": [
    {
      "id": "expense:seed:ac",
      "applianceId": "ac",
      "amount": {
        "minor": 180000,
        "currency": "INR"
      },
      "chargedOn": "2026-04-25",
      "sourceId": "invoice:seed:ac",
      "description": "Confirmed historical living room ac service"
    },
    {
      "id": "expense:seed:purifier",
      "applianceId": "purifier",
      "amount": {
        "minor": 240000,
        "currency": "INR"
      },
      "chargedOn": "2026-05-01",
      "sourceId": "invoice:seed:purifier",
      "description": "Confirmed historical kitchen purifier service"
    },
    {
      "id": "expense:seed:washer",
      "applianceId": "washer",
      "amount": {
        "minor": 95000,
        "currency": "INR"
      },
      "chargedOn": "2026-07-10",
      "sourceId": "invoice:seed:washer",
      "description": "Confirmed historical washing machine service"
    },
    {
      "id": "expense:seed:garden",
      "applianceId": "garden",
      "amount": {
        "minor": 120000,
        "currency": "INR"
      },
      "chargedOn": "2026-10-01",
      "sourceId": "invoice:seed:garden",
      "description": "Confirmed historical terrace garden service"
    },
    {
      "id": "expense:seed:sink",
      "applianceId": "sink",
      "amount": {
        "minor": 75000,
        "currency": "INR"
      },
      "chargedOn": "2025-12-09",
      "sourceId": "invoice:seed:sink",
      "description": "Confirmed historical kitchen sink service"
    }
  ]
} as HouseholdDataset;
export function generateDatasets(): HouseholdDataset[] {
  const original = HouseholdDatasetSchema.parse(source);
  const alternate = structuredClone(original);
  alternate.metadata = { ...alternate.metadata, id: 'cedar-2032', name: 'Cedar household in 2032', description: 'Alternate identifiers and dates, with a generic appliance and different budget and policies.' };
  alternate.household = { id: 'cedar-home', name: 'The Cedar household', budget: { minor: 275000, currency: 'INR' }, warrantyNoticeDays: 12 };
  const shiftDay = (day: string) => `${Number(day.slice(0, 4)) + 6}${day.slice(4)}`;
  alternate.demoNow = '2032-10-21T09:00:00+05:30';
  for (const a of alternate.appliances) { a.id = `cedar-${a.id}`; if (a.lastService) { a.lastService.performedOn = shiftDay(a.lastService.performedOn); a.lastService.sourceId = `cedar-${a.lastService.sourceId}`; } if (a.maintenance) { a.maintenance.intervalDays += 1; a.maintenance.sourceId = `cedar-${a.maintenance.sourceId}`; } if (a.warranty) { a.warranty.ends = shiftDay(a.warranty.ends); a.warranty.sourceId = `cedar-${a.warranty.sourceId}`; } }
  for (const p of alternate.providers) p.id = `cedar-${p.id}`;
  for (const e of alternate.expenses) { e.id = `cedar-${e.id}`; e.applianceId = `cedar-${e.applianceId}`; e.chargedOn = shiftDay(e.chargedOn); e.sourceId = `cedar-${e.sourceId}`; }
  alternate.appliances.push({ id: 'cedar-ventilation', name: 'Attic ventilation', kind: 'other', location: 'Attic', lastService: { performedOn: '2032-09-01', sourceId: 'cedar-invoice:ventilation' }, maintenance: { intervalDays: 30, sourceId: 'cedar-policy:ventilation' }, warranty: { ends: '2032-10-30', sourceId: 'cedar-warranty:ventilation', terms: 'Synthetic parts warranty; fault-specific coverage unknown.' } });
  alternate.providers.push({ id: 'cedar-general', name: 'Cedar General Care', serviceKind: 'other', preferred: true, available: true, contactNote: null, simulation: { declines: false, amount: { minor: 110000, currency: 'INR' } } });
  return [original, HouseholdDatasetSchema.parse(alternate)];
}
if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) for (const dataset of generateDatasets()) writeFileSync(new URL(`${dataset.metadata.id}.json`, import.meta.url), `${JSON.stringify(dataset, null, 2)}\n`);
