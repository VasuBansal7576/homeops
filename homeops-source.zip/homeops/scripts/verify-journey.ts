import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { randomUUID } from 'node:crypto';
import { Client, type MessageStreamEvent } from 'eve/client';
import type { HouseholdSnapshot, PublicCommand } from '../packages/contracts/src/index.ts';

const origin = process.env.HOMEOPS_URL ?? 'http://127.0.0.1:43110';
const login = await fetch(`${origin}/api/auth/login`, { method: 'POST', headers: { origin, 'content-type': 'application/json' }, body: JSON.stringify({ password: process.env.HOMEOPS_PASSWORD ?? 'homeops-demo' }) });
assert.equal(login.status, 200);
const cookie = login.headers.get('set-cookie')!.split(';')[0];
const { csrf } = await login.json();
const headers = { cookie, origin, 'content-type': 'application/json', 'x-homeops-csrf': csrf };
const client = new Client({ host: origin, headers });
const run = process.env.HOMEOPS_VERIFY_RUN ?? '';
assert.match(run, /^[a-zA-Z0-9_-]*$/, 'Verification run must be a simple label');
const stem = `artifacts/verification/native${run ? `-${run}` : ''}`;
const file = `${stem}-approval-state.json`;
const snapshot = async (): Promise<HouseholdSnapshot> => { const r = await fetch(`${origin}/api/homeops/snapshot`, { headers }); assert.equal(r.status, 200); return r.json(); };
async function command(command: PublicCommand) {
  const r = await fetch(`${origin}/api/homeops/commands`, { method: 'POST', headers, body: JSON.stringify({ commandId: `verify:${randomUUID()}`, command }) });
  const body = await r.json(); assert.equal(r.status, 200, JSON.stringify(body)); return body;
}
async function events(sessionId: string) {
  const result: MessageStreamEvent[] = [];
  for await (const event of client.sessions.attach(sessionId).stream({ follow: false })) result.push(event);
  return result;
}
async function until<T>(read: () => Promise<T | undefined>, label: string) {
  const end = Date.now() + 240000;
  while (Date.now() < end) { const value = await read(); if (value !== undefined) return value; await new Promise(resolve => setTimeout(resolve, 1500)); }
  throw new Error(`Timed out waiting for ${label}`);
}
try {
  if (process.argv.includes('--prepare')) {
    const initial = await snapshot();
    assert.equal(initial.household.name, 'The Maple household');
    const scheduled = process.argv.includes('--scheduled');
    await command({ type: 'clock.set', now: scheduled ? '2026-10-21T23:59:50+05:30' : '2026-10-22T09:30:00+05:30' });
    let current = await snapshot();
    if (!current.cases.some(c => c.applianceId === 'ac' && !['denied','completed','cancelled'].includes(c.state))) await command({ type: 'fixture.change', change: { kind: 'serviceDate', applianceId: 'ac', performedOn: '2026-04-25' } });
    if (scheduled) {
      assert.ok(!(await snapshot()).cases.some(c => c.applianceId === 'ac' && !['completed','denied','cancelled'].includes(c.state)), 'AC must not be due before the clock crosses midnight');
      await command({ type: 'preference.save', text: 'Keep the terrace door closed during service.' });
    }
    const pending = await until(async () => {
      const state = await snapshot();
      const item = state.cases.findLast(c => c.applianceId === 'ac' && !['denied','completed','cancelled'].includes(c.state) && c.sessionId);
      if (!item?.sessionId) return undefined;
      const history = await events(item.sessionId);
      const failed = history.findLast(e => e.type === 'turn.failed' || e.type === 'step.failed');
      if (failed) throw new Error(JSON.stringify(failed));
      if (item.approval?.status !== 'pending') return undefined;
      const requested = history.findLast(e => e.type === 'input.requested' && e.data.requests.some(r => r.kind === 'tool-approval' && r.action.input?.approvalId === item.approval?.id));
      if (requested?.type !== 'input.requested') return undefined;
      assert.ok(item.offers.some(o => o.status === 'declined'));
      assert.ok(item.offers.some(o => o.withinBudget === false));
      assert.ok(item.offers.some(o => o.withinBudget === true));
      assert.equal(item.booking, null);
      return { caseId: item.id, sessionId: item.sessionId, approvalId: item.approval!.id, requests: requested.data.requests, scheduled, before: { lastService: state.appliances.find(a => a.id === 'ac')!.lastService, expenseTotals: state.expenseTotals }, preparedAt: new Date().toISOString() };
    }, 'actual durable Eve approval');
    await writeFile(file, JSON.stringify(pending, null, 2));
    console.log(JSON.stringify({ result:'VERIFIED', check:'Real AC tools compare decline and budget, then park on durable Eve approval', caseId:pending.caseId, sessionId:pending.sessionId }));
  } else {
    const pending = JSON.parse(await readFile(file, 'utf8'));
    const session = client.sessions.attach(pending.sessionId);
    const history = (await session.snapshot()).events;
    assert.ok(history.some(e => e.type === 'input.requested'), 'Pending approval must survive restart');
    const optionId = process.argv.includes('--deny') ? 'cancel' : 'approve';
    const responses = pending.requests.map((r: {requestId:string}) => ({ requestId:r.requestId, optionId }));
    const response = await session.respond(responses);
    const result = await response.result();
    await writeFile(`${stem}-${optionId}-response.json`, JSON.stringify(result, null, 2));
    assert.ok(!result.events.some(e => e.type === 'turn.failed' || e.type === 'step.failed'), 'Approval continuation must succeed');
    const state = await until(async () => {
      const current = await snapshot();
      const item = current.cases.find(c => c.id === pending.caseId);
      return item?.state === (optionId === 'cancel' ? 'denied' : 'booked') ? current : undefined;
    }, `canonical ${optionId === 'cancel' ? 'denial' : 'booking'} after asynchronous continuation`);
    const item = state.cases.find(c => c.id === pending.caseId)!;
    if (optionId === 'cancel') { assert.equal(item.state, 'denied'); assert.equal(item.booking, null); }
    else {
      assert.equal(item.state, 'booked'); assert.ok(item.booking?.receiptId);
      assert.deepEqual(state.appliances.find(a => a.id === 'ac')!.lastService, pending.before.lastService);
      assert.deepEqual(state.expenseTotals, pending.before.expenseTotals);
      const duplicate = await session.respond(responses);
      await duplicate.result();
      assert.equal((await snapshot()).cases.find(c => c.id === item.id)!.booking?.receiptId, item.booking.receiptId);
      await command({ type:'clock.set', now:'2026-10-24T09:30:00+05:30' });
      await command({ type:'case.confirmAppointment', caseId:item.id, confirmed:true });
      await command({ type:'case.complete', caseId:item.id, completedAt:'2026-10-23', sourceId:'fixture:verified-completion' });
      assert.equal((await snapshot()).cases.find(c => c.id === item.id)!.state, 'completed');
    }
    await writeFile(`${stem}-${optionId}-verification.json`, JSON.stringify({ at:new Date().toISOString(), result:'VERIFIED', sessionId:pending.sessionId, caseId:pending.caseId, final: (await snapshot()).cases.find(c => c.id === pending.caseId), events:await events(pending.sessionId) }, null, 2));
    console.log(`VERIFIED actual durable approval ${optionId} continuation`);
  }
} catch(error) { console.error(error); process.exitCode=1; }
