import { credentialPath, listModels, loadStore, login, PlanError, requirePlanScope } from '../apps/agent/src/model/auth.ts';
import { probe } from '../apps/agent/src/model/plan-fetch.ts';

const command = process.argv[2] ?? 'login';
try {
  if (command === 'login') {
    const credential = await login({ path: credentialPath(), timeoutMs: 900000, newAccount: process.argv.includes('--new'), onURL: url => console.log(url) });
    requirePlanScope(credential);
    console.error('HomeOps authorization saved.');
  } else if (command === 'models') console.log(JSON.stringify(await listModels(), null, 2));
  else if (command === 'probe') console.log(JSON.stringify(await probe(credentialPath(), process.argv[3]), null, 2));
  else if (command === 'status') {
    const store = await loadStore(credentialPath());
    console.log(JSON.stringify({ host_id: store.host_id, accounts: store.accounts.map(({ client_id, subject, email, scopes, expires_at }) => ({ client_id, subject, email, scopes, expires_at })), active_client_id: store.active_client_id }, null, 2));
  } else {
    console.error('Usage: node cli.ts login [--new] | models | probe [catalog-model-slug] | status');
    process.exitCode = 2;
  }
} catch (error) {
  console.error(error instanceof PlanError ? `HomeOps: ${error.code}` : 'HomeOps: operation failed. No credentials were printed.');
  process.exitCode = 1;
}
