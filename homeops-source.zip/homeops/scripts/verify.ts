import assert from 'node:assert/strict';
import { writeFile, mkdir } from 'node:fs/promises';
import { Client } from 'eve/client';

const origin = process.env.HOMEOPS_URL ?? 'http://127.0.0.1:43110';
const evidence: { check: string; result: string; detail?: unknown }[] = [];
const record = (check: string, detail?: unknown) => { evidence.push({ check, result: 'VERIFIED', detail }); console.log(`VERIFIED ${check}`); };
let cookie = '';
let csrf = '';
async function request(path: string, options: RequestInit = {}) {
  return fetch(`${origin}${path}`, { ...options, headers: { origin, cookie, 'content-type': 'application/json', 'x-homeops-csrf': csrf, ...options.headers } });
}
let sequence = 0;
async function rpc(method: string, params: Record<string, unknown> = {}) {
  const response = await request('/eve/v1/mcp', { method: 'POST', headers: { accept: 'application/json, text/event-stream', 'mcp-protocol-version': '2025-11-25' }, body: JSON.stringify({ jsonrpc: '2.0', id: ++sequence, method, params }) });
  assert.equal(response.status, 200, `${method} HTTP status`);
  const text = await response.text();
  const reply = response.headers.get('content-type')?.includes('text/event-stream') ? JSON.parse(text.split('\n').filter(line => line.startsWith('data: ')).at(-1)!.slice(6)) : JSON.parse(text);
  assert.equal(reply.error, undefined, JSON.stringify(reply.error));
  return reply.result;
}
try {
  assert.equal((await fetch(`${origin}/api/homeops/snapshot`)).status, 401);
  record('Gateway rejects unauthenticated household access');
  const login = await request('/api/auth/login', { method: 'POST', body: JSON.stringify({ password: process.env.HOMEOPS_PASSWORD ?? 'homeops-demo' }) });
  assert.equal(login.status, 200);
  cookie = login.headers.get('set-cookie')!.split(';')[0];
  csrf = (await login.json()).csrf;
  record('Signed operator login succeeds');
  const missingCSRF = await fetch(`${origin}/api/homeops/commands`, { method: 'POST', headers: { origin, cookie, 'content-type': 'application/json' }, body: '{}' });
  assert.equal(missingCSRF.status, 403);
  record('Command route rejects missing CSRF');
  const health = await request('/eve/v1/health');
  assert.equal(health.status, 200); assert.equal((await health.json()).status, 'ready');
  record('Built proxy reaches Eve health');
  const snapshotResponse = await request('/api/homeops/snapshot');
  assert.equal(snapshotResponse.status, 200);
  const snapshot = await snapshotResponse.json();
  assert.equal(snapshot.schemaVersion, 1);
  assert.ok(['empty', 'ready'].includes(snapshot.workspace.status));
  if (snapshot.workspace.status === 'empty') {
    assert.equal(snapshot.appliances.length, 0);
    assert.equal(snapshot.providers.length, 0);
    assert.equal(snapshot.expenses.length, 0);
  }
  record('Dashboard reads canonical workspace state', { workspace: snapshot.workspace, appliances: snapshot.appliances.length, expenses: snapshot.expenses.length });
  const initialized = await rpc('initialize', { protocolVersion: '2025-11-25', capabilities: {}, clientInfo: { name: 'homeops-verifier', version: '1.0.0' } });
  assert.equal(initialized.protocolVersion, '2025-11-25');
  record('Actual MCP Streamable HTTP initializes protocol 2025-11-25');
  const notification = await request('/eve/v1/mcp', { method: 'POST', headers: { accept: 'application/json, text/event-stream', 'mcp-protocol-version': '2025-11-25' }, body: JSON.stringify({ jsonrpc: '2.0', method: 'notifications/initialized' }) });
  assert.ok([200, 202, 204].includes(notification.status));
  const list = await rpc('tools/list');
  assert.ok(['agent_start', 'agent_get', 'agent_update'].every(name => list.tools.some((t: { name: string }) => t.name === name)));
  record('Actual MCP lists durable agent tools', list.tools.map((t: { name: string }) => t.name));
  const invalid = await rpc('tools/call', { name: 'agent_get', arguments: { invocationId: 'not-an-invocation' } });
  assert.equal(invalid.isError, true);
  record('Actual MCP invocation enforces durable invocation lookup');
  if (process.argv.includes('--model')) {
    assert.equal(snapshot.workspace.status, 'ready', 'Initialize a household before checking model recall');
    assert.ok(snapshot.workspace.dataKind === 'synthetic' || process.argv.includes('--allow-personal-model'), 'For personal records, explicitly pass --allow-personal-model to send household facts to the configured model');
    const client = new Client({ host: origin, headers: { cookie, origin, 'x-homeops-csrf': csrf } });
    const { session, response } = await client.sessions.create({ message: 'Use household_snapshot to read this household. Tell me the household name and total confirmed spending in INR. Cite the stored source records. Do not change any records.' });
    if (!response) throw new Error('No model turn was accepted');
    const result = await response.result();
    const events = result.events;
    await writeFile('artifacts/verification/model-events.json', JSON.stringify(events, null, 2));
    const failure = events.find(e => e.type === 'turn.failed' || e.type === 'step.failed');
    assert.equal(failure, undefined, JSON.stringify(failure));
    assert.notEqual(result.status, 'failed', 'The actual model turn must succeed');
    assert.ok(events.some(e => e.type === 'action.result'), 'A real tool must complete');
    record('Actual model/tool/model turn completes', { sessionId: session.state.sessionId, result });
  }
} catch (error) {
  evidence.push({ check: 'Compatibility verification', result: 'NOT VERIFIED', detail: error instanceof Error ? error.message : String(error) });
  console.error(error); process.exitCode = 1;
} finally {
  await mkdir('artifacts/verification', { recursive: true });
  await writeFile(`artifacts/verification/${process.argv.includes('--model') ? 'model' : 'transport'}-verification.json`, JSON.stringify({ at: new Date().toISOString(), origin, evidence }, null, 2));
}
