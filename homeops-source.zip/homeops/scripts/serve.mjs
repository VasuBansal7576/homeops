import http from 'node:http';
import { spawn } from 'node:child_process';
import { createHmac, randomBytes, timingSafeEqual } from 'node:crypto';
import { createReadStream, existsSync, mkdirSync, readFileSync, statSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { createVoiceHandler } from './voice.mjs';

const root = resolve(import.meta.dirname, '..');
const local = resolve(root, '.local');
mkdirSync(local, { recursive: true, mode: 0o700 });
const configPath = resolve(local, 'runtime.json');
if (!existsSync(configPath)) writeFileSync(configPath, JSON.stringify({ secret: randomBytes(32).toString('hex') }), { mode: 0o600 });
const { secret } = JSON.parse(readFileSync(configPath, 'utf8'));
const port = Number(process.env.PORT ?? 43110);
const agentPort = port + 1;
const webPort = port + 2;
const origin = `http://127.0.0.1:${port}`;
const password = process.env.HOMEOPS_PASSWORD ?? 'homeops-demo';
const development = process.argv.includes('--dev');
const children = [];
const env = { ...process.env, HOMEOPS_ROOT: root, HOMEOPS_SERVICE_SECRET: secret, HOMEOPS_ORIGIN: origin, HOMEOPS_AGENT_URL: `http://127.0.0.1:${agentPort}`, EVE_TELEMETRY_DISABLED: '1' };

function start(command, args, cwd, extra = {}) {
  const child = spawn(command, args, { cwd, env: { ...env, ...extra }, stdio: 'inherit' });
  children.push(child);
  child.on('exit', code => { if (code && !stopping) console.error(`${command} exited with ${code}`); });
}
let stopping = false;
start(resolve(root, 'node_modules/.bin/eve'), development ? ['dev', '--no-ui', '--port', String(agentPort)] : ['start', '--host', '127.0.0.1', '--port', String(agentPort)], resolve(root, 'apps/agent'));
if (development) start(resolve(root, 'node_modules/.bin/vite'), ['--host', '127.0.0.1', '--port', String(webPort)], resolve(root, 'apps/web'));
else start(process.execPath, ['.output/server/index.mjs'], resolve(root, 'apps/web'), { PORT: String(webPort), HOST: '127.0.0.1' });

function equal(a, b) {
  const x = Buffer.from(a ?? ''); const y = Buffer.from(b ?? '');
  return x.length === y.length && timingSafeEqual(x, y);
}
function signature(value) { return createHmac('sha256', secret).update(value).digest('base64url'); }
function session(req) {
  const raw = req.headers.cookie?.split('; ').find(v => v.startsWith('homeops='))?.slice(8);
  if (!raw) return null;
  const [payload, sig] = raw.split('.');
  if (!payload || !equal(signature(payload), sig)) return null;
  try { const s = JSON.parse(Buffer.from(payload, 'base64url').toString()); return s.expires > Date.now() ? s : null; } catch { return null; }
}
function json(res, status, value, extra = {}) {
  res.writeHead(status, { 'content-type': 'application/json', 'cache-control': 'no-store', ...extra });
  res.end(JSON.stringify(value));
}
async function body(req) {
  let data = ''; for await (const chunk of req) { data += chunk; if (data.length > 1_048_576) throw new Error('Body too large'); }
  return JSON.parse(data || '{}');
}
function forward(req, res, targetPort, protectedRoute) {
  const headers = { ...req.headers, host: `127.0.0.1:${targetPort}` };
  delete headers.cookie;
  if (protectedRoute) headers.authorization = `Bearer ${secret}`;
  if (headers.origin) headers.origin = `http://127.0.0.1:${targetPort}`;
  const proxy = http.request({ hostname: '127.0.0.1', port: targetPort, path: req.url, method: req.method, headers }, response => {
    res.writeHead(response.statusCode ?? 502, response.headers);
    response.pipe(res);
  });
  proxy.on('error', () => { if (!res.headersSent) json(res, 503, { error: { code: 'starting', message: 'HomeOps is starting. Try again in a moment.', retryable: true } }); else res.end(); });
  res.on('close', () => proxy.destroy());
  req.pipe(proxy);
}
const handleVoice = createVoiceHandler({ root, origin, session, equal });
const server = http.createServer(async (req, res) => {
  res.setHeader('Permissions-Policy', 'microphone=(self)');
  try {
    const path = req.url?.split('?')[0] ?? '/';
    const user = session(req);
    if (await handleVoice(req, res)) return;
    if (path === '/api/auth/session' && req.method === 'GET') return json(res, 200, { authenticated: Boolean(user), csrf: user?.csrf ?? null });
    const demo = /^\/demo\/(ac|final)(\.mp4)?$/.exec(path);
    if (demo && ['GET', 'HEAD'].includes(req.method ?? 'GET')) {
      if (!user) return json(res, 401, { error: { code: 'unauthorized', message: 'Sign in to HomeOps first.' } });
      const file = resolve(root, 'artifacts', demo[1] === 'ac' ? 'homeops-ac-early.mp4' : 'homeops-demo.mp4');
      if (!existsSync(file)) return json(res, 404, { error: { code: 'not_recorded', message: 'This recording is not ready yet.' } });
      if (!demo[2]) {
        res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' });
        return res.end(`<!doctype html><html lang="en"><title>HomeOps recording</title><body style="margin:0;background:#132a23;color:white;font:16px system-ui"><h1 style="margin:16px">HomeOps actual browser recording</h1><video controls preload="metadata" style="width:100%;height:calc(100vh - 90px)" src="/demo/${demo[1]}.mp4"></video></body></html>`);
      }
      const size = statSync(file).size;
      const range = req.headers.range;
      const match = range && /^bytes=(\d+)-(\d*)$/.exec(range);
      if (range && !match) { res.writeHead(416, { 'content-range': `bytes */${size}` }); return res.end(); }
      const start = match ? Number(match[1]) : 0;
      const end = match?.[2] ? Math.min(Number(match[2]), size - 1) : size - 1;
      if (start >= size || start > end) { res.writeHead(416, { 'content-range': `bytes */${size}` }); return res.end(); }
      res.writeHead(match ? 206 : 200, { 'content-type': 'video/mp4', 'accept-ranges': 'bytes', 'content-length': end - start + 1, 'cache-control': 'no-store', ...(match ? { 'content-range': `bytes ${start}-${end}/${size}` } : {}) });
      if (req.method === 'HEAD') return res.end();
      return createReadStream(file, { start, end }).pipe(res);
    }
    const mutation = !['GET', 'HEAD', 'OPTIONS'].includes(req.method ?? 'GET');
    if (mutation && req.headers.origin !== origin) return json(res, 403, { error: { code: 'origin', message: 'Use the HomeOps app origin.', retryable: false } });
    if (path === '/api/auth/login' && req.method === 'POST') {
      const input = await body(req);
      if (!equal(input.password, password)) return json(res, 401, { error: { code: 'password', message: 'The demo password is incorrect.', retryable: false } });
      const s = { principalId: 'operator', csrf: randomBytes(24).toString('hex'), expires: Date.now() + 12 * 3600_000 };
      const payload = Buffer.from(JSON.stringify(s)).toString('base64url');
      return json(res, 200, { authenticated: true, csrf: s.csrf }, { 'set-cookie': `homeops=${payload}.${signature(payload)}; HttpOnly; SameSite=Strict; Path=/; Max-Age=43200` });
    }
    const protectedRoute = path.startsWith('/api/homeops/') || path.startsWith('/eve/') || path.startsWith('/.well-known/workflow/');
    if (protectedRoute && !user) return json(res, 401, { error: { code: 'unauthorized', message: 'Sign in to HomeOps.', retryable: false } });
    if (mutation && path.startsWith('/api/homeops/') && !equal(req.headers['x-homeops-csrf'], user?.csrf)) return json(res, 403, { error: { code: 'csrf', message: 'Refresh your HomeOps session.', retryable: false } });
    if (mutation && protectedRoute && !req.headers['content-type']?.includes('application/json')) return json(res, 415, { error: { code: 'content_type', message: 'JSON is required.', retryable: false } });
    forward(req, res, protectedRoute ? agentPort : webPort, protectedRoute);
  } catch { json(res, 400, { error: { code: 'invalid_input', message: 'The request could not be read.', retryable: false } }); }
});
server.listen(port, '127.0.0.1', () => console.log(`HomeOps ${origin} | demo password: ${password}`));
function stop() { stopping = true; for (const child of children) child.kill('SIGTERM'); server.close(); setTimeout(() => process.exit(), 1500).unref(); }
process.on('SIGINT', stop); process.on('SIGTERM', stop);
