import { createHash } from 'node:crypto';
import { createWriteStream, existsSync, mkdirSync, readFileSync, renameSync, rmSync } from 'node:fs';
import { resolve } from 'node:path';
import { pipeline } from 'node:stream/promises';
import { Readable } from 'node:stream';
import { spawnSync } from 'node:child_process';

const root = resolve(import.meta.dirname, '..');
const directory = resolve(root, '.local/voice');
const model = resolve(directory, 'ggml-base.en.bin');
const expected = 'a03779c86df3323075f5e796cb2ce5029f00ec8869eee3fdfb897afe36c6d002';
const url = 'https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-base.en.bin';
const sha = file => createHash('sha256').update(readFileSync(file)).digest('hex');
mkdirSync(directory, { recursive: true, mode: 0o700 });
if (!existsSync(model)) {
  const temporary = model + '.download-' + process.pid;
  try {
    const response = await fetch(url, { signal: AbortSignal.timeout(600000) });
    if (!response.ok || !response.body) throw Error(`Model download failed with HTTP${response.status}`);
    await pipeline(Readable.fromWeb(response.body), createWriteStream(temporary, { flags: 'wx', mode: 0o600 }));
    if (sha(temporary) !== expected) throw Error('Speech model checksum did not match the verified base.en weights.');
    renameSync(temporary, model);
  } finally { rmSync(temporary, { force: true }); }
}
if (sha(model) !== expected) throw Error('Existing speech model checksum differs. Preserve it and explicitly choose a verified model.');
const available = command => spawnSync(command, ['--help'], { stdio: 'ignore', timeout: 10000 }).error === undefined;
const result = { model: 'Whisper base.en', sha256: expected, whisper: available(process.env.HOMEOPS_WHISPER_BIN ?? 'whisper-cli'), ffmpeg: available(process.env.HOMEOPS_FFMPEG_BIN ?? 'ffmpeg'), speech: process.platform === 'darwin' ? existsSync('/usr/bin/say') : available('espeak-ng'), cloudSpeech: false, next: 'npm run build && npm start. Missing binaries require installation; see README voice setup.' };
console.log(JSON.stringify(result, null, 2));
if (!result.whisper || !result.ffmpeg || !result.speech) process.exitCode = 1;
