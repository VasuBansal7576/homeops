import { execFile } from 'node:child_process';
import { constants } from 'node:fs';
import { access, mkdtemp, readFile, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { delimiter, join, resolve } from 'node:path';
import { promisify } from 'node:util';

const exec = promisify(execFile);
export const voiceLimits = Object.freeze({ maxSeconds: 30, maxBytes: 8_388_608 });
const maxBodyBytes = Math.ceil(voiceLimits.maxBytes / 3) * 4 + 1024;
const formats = new Map([
  ['audio/wav', 'wav'], ['audio/webm', 'matroska'], ['audio/mp4', 'mov'],
  ['audio/mpeg', 'mp3'], ['audio/ogg', 'ogg'],
]);

class VoiceError extends Error {
  constructor(status, code, message, retryable = false) {
    super(message);
    Object.assign(this, { status, code, retryable });
  }
}

function json(res, status, value) {
  res.writeHead(status, { 'content-type': 'application/json', 'cache-control': 'no-store' });
  res.end(JSON.stringify(value));
}

async function executable(name) {
  const candidates = name.includes('/') ? [name] : (process.env.PATH ?? '').split(delimiter).map(dir => join(dir, name));
  for (const candidate of candidates) {
    try { await access(candidate, constants.X_OK); return candidate; } catch {}
  }
  return null;
}

async function input(req) {
  if (!/^application\/json(?:\s*;\s*charset=utf-8)?$/i.test(req.headers['content-type'] ?? '')) {
    throw new VoiceError(415, 'content_type', 'JSON is required.');
  }
  if (req.headers['content-encoding'] && req.headers['content-encoding'] !== 'identity') {
    throw new VoiceError(415, 'content_encoding', 'Send uncompressed JSON.');
  }
  if (Number(req.headers['content-length'] ?? 0) > maxBodyBytes) { req.resume(); throw new VoiceError(413, 'audio_too_large', 'Audio must be no larger than 8 MiB.'); }
  const chunks = [];
  let size = 0;
  for await (const chunk of req.iterator({ destroyOnReturn: false })) {
    size += chunk.length;
    if (size > maxBodyBytes) { req.resume(); throw new VoiceError(413, 'audio_too_large', 'Audio must be no larger than 8 MiB.'); }
    chunks.push(chunk);
  }
  try {
    const value = JSON.parse(Buffer.concat(chunks).toString('utf8'));
    if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error();
    return value;
  } catch { throw new VoiceError(400, 'invalid_input', 'Send a valid JSON object.'); }
}

function audioInput(value) {
  const { audioBase64, mimeType } = value;
  if (typeof mimeType !== 'string' || mimeType.length > 200 || !/^audio\/[a-z0-9]+(?:\s*;\s*[a-z0-9-]+=(?:[a-z0-9.,_-]+|"[a-z0-9.,_ -]+"))*$/i.test(mimeType)) {
    throw new VoiceError(415, 'audio_type', 'Choose a WAV, WebM, MP4, MP3 or Ogg audio file.');
  }
  const format = formats.get(mimeType.split(';')[0].trim().toLowerCase());
  if (!format) throw new VoiceError(415, 'audio_type', 'Choose a WAV, WebM, MP4, MP3 or Ogg audio file.');
  if (typeof audioBase64 !== 'string' || !audioBase64.length || audioBase64.length % 4 || !/^[A-Za-z0-9+/]*={0,2}$/.test(audioBase64)) {
    throw new VoiceError(400, 'invalid_audio', 'The audio encoding is invalid.');
  }
  const audio = Buffer.from(audioBase64, 'base64');
  if (audio.length > voiceLimits.maxBytes) throw new VoiceError(413, 'audio_too_large', 'Audio must be no larger than 8 MiB.');
  if (audio.toString('base64') !== audioBase64) throw new VoiceError(400, 'invalid_audio', 'The audio encoding is invalid.');
  return { audio, format };
}

function checkPcm(pcm) {
  const samples = pcm.length / 2;
  if (samples > 16_000 * voiceLimits.maxSeconds) throw new VoiceError(422, 'audio_too_long', 'Record no more than 30 seconds.');
  if (!samples || pcm.length % 2) throw new VoiceError(422, 'invalid_audio', 'This file contains no decodable audio.');
  let energy = 0;
  let activeFrames = 0;
  for (let start = 0; start < samples; start += 320) {
    const end = Math.min(start + 320, samples);
    let frame = 0;
    for (let i = start; i < end; i++) frame += (pcm.readInt16LE(i * 2) / 32768) ** 2;
    energy += frame;
    if (Math.sqrt(frame / (end - start)) >= 0.003) activeFrames++;
  }
  if (Math.sqrt(energy / samples) < 0.0015 || activeFrames < 3) {
    throw new VoiceError(422, 'no_speech', 'No audible speech was detected. Try again closer to the microphone.');
  }
}

function wave(pcm) {
  const header = Buffer.alloc(44);
  header.write('RIFF'); header.writeUInt32LE(pcm.length + 36, 4); header.write('WAVEfmt ', 8);
  header.writeUInt32LE(16, 16); header.writeUInt16LE(1, 20); header.writeUInt16LE(1, 22);
  header.writeUInt32LE(16_000, 24); header.writeUInt32LE(32_000, 28);
  header.writeUInt16LE(2, 32); header.writeUInt16LE(16, 34); header.write('data', 36);
  header.writeUInt32LE(pcm.length, 40);
  return Buffer.concat([header, pcm]);
}

export function createVoiceHandler({ root, origin, session, equal, modelPath = process.env.HOMEOPS_WHISPER_MODEL ?? resolve(root, '.local/voice/ggml-base.en.bin'), run = exec, findExecutable = executable, temporaryRoot = tmpdir() }) {
  let active = false;
  async function capabilities() {
    const ffmpeg = await findExecutable(process.env.HOMEOPS_FFMPEG_BIN ?? 'ffmpeg');
    const whisper = await findExecutable(process.env.HOMEOPS_WHISPER_BIN ?? 'whisper-cli');
    const speech = await findExecutable(process.platform === 'darwin' ? '/usr/bin/say' : 'espeak-ng');
    let model = false;
    try { await access(modelPath, constants.R_OK); model = true; } catch {}
    return { ffmpeg, whisper, speech, model };
  }
  async function processAudio(command, args, timeout = 15_000) {
    try { await run(command, args, { timeout, killSignal: 'SIGKILL', maxBuffer: 1_048_576, windowsHide: true }); }
    catch (error) {
      if (error.killed || error.code === 'ETIMEDOUT') throw new VoiceError(504, 'voice_timeout', 'Audio processing timed out. Try a shorter recording.', true);
      throw new VoiceError(422, 'audio_processing', 'Audio could not be processed. Try another recording or type your message.', true);
    }
  }
  return async function handleVoice(req, res) {
    const path = req.url?.split('?')[0] ?? '';
    if (!path.startsWith('/api/homeops/voice/')) return false;
    try {
      const user = session(req);
      if (!user) throw new VoiceError(401, 'unauthorized', 'Sign in to HomeOps.');
      if ((req.headers.origin && req.headers.origin !== origin) || ['cross-site', 'same-site'].includes(req.headers['sec-fetch-site'])) {
        throw new VoiceError(403, 'origin', 'Use the HomeOps app origin.');
      }
      const statusRoute = path === '/api/homeops/voice/status';
      const transcribe = path === '/api/homeops/voice/transcribe';
      const speak = path === '/api/homeops/voice/speak';
      if (!statusRoute && !transcribe && !speak) throw new VoiceError(404, 'not_found', 'This voice route does not exist.');
      if (req.method !== (statusRoute ? 'GET' : 'POST')) throw new VoiceError(405, 'method', 'Use the supported voice request method.');
      if (!statusRoute) {
        if (req.headers.origin !== origin) throw new VoiceError(403, 'origin', 'Use the HomeOps app origin.');
        if (!equal(req.headers['x-homeops-csrf'], user.csrf)) throw new VoiceError(403, 'csrf', 'Refresh your HomeOps session.');
      }
      if (statusRoute) {
        const c = await capabilities();
        json(res, 200, {
          transcription: { available: Boolean(c.ffmpeg && c.whisper && c.model), engine: 'whisper.cpp', ...(!c.ffmpeg ? { reason: 'Install FFmpeg for local audio conversion.' } : !c.whisper ? { reason: 'Install whisper.cpp for local transcription.' } : !c.model ? { reason: 'The local Whisper model is not installed. Follow the voice setup instructions.' } : {}) },
          speech: { available: Boolean(c.ffmpeg && c.speech), engine: process.platform === 'darwin' ? 'macOS say' : 'espeak-ng', ...(!c.ffmpeg || !c.speech ? { reason: 'Local speech output requires FFmpeg and an installed system speech engine.' } : {}) },
          limits: voiceLimits,
        });
        return true;
      }
      const value = await input(req);
      let audio;
      let text;
      if (transcribe) audio = audioInput(value);
      else {
        if (typeof value.text !== 'string' || !value.text.trim() || value.text.length > 1800 || /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/.test(value.text)) {
          throw new VoiceError(400, 'invalid_text', 'Speech requires 1 to 1800 characters of assistant text.');
        }
        text = value.text.trim();
      }
      const c = await capabilities();
      if (!c.ffmpeg || (transcribe ? !c.whisper || !c.model : !c.speech)) throw new VoiceError(503, 'voice_unavailable', 'The local voice engine is unavailable. Check voice status or type your message.', true);
      if (active) throw new VoiceError(429, 'voice_busy', 'Another voice request is running. Try again shortly.', true);
      active = true;
      let dir;
      let transcriptResult;
      let speechResult;
      try {
        dir = await mkdtemp(join(temporaryRoot, 'homeops-voice-'));
        if (transcribe) {
          const source = join(dir, 'input.audio');
          const pcmFile = join(dir, 'decoded.pcm');
          const wav = join(dir, 'speech.wav');
          const output = join(dir, 'transcript');
          await writeFile(source, audio.audio, { mode: 0o600 });
          await processAudio(c.ffmpeg, ['-nostdin', '-hide_banner', '-loglevel', 'error', '-protocol_whitelist', 'file,pipe', '-f', audio.format, '-i', source, '-map', '0:a:0', '-vn', '-ac', '1', '-ar', '16000', '-t', '30.1', '-f', 's16le', '-acodec', 'pcm_s16le', pcmFile]);
          const pcm = await readFile(pcmFile);
          checkPcm(pcm);
          await writeFile(wav, wave(pcm), { mode: 0o600 });
          await processAudio(c.whisper, ['-m', modelPath, '-f', wav, '-l', 'en', '-t', '4', '-ng', '-nt', '-np', '-otxt', '-of', output], 90_000);
          const transcript = (await readFile(`${output}.txt`, 'utf8')).trim();
          if (!transcript || /^\s*(?:\[[^\]]*\]|\([^)]*\)|[.\s])*$/u.test(transcript)) throw new VoiceError(422, 'no_speech', 'No speech was recognized. Try again or type your message.');
          transcriptResult = { text: transcript, engine: 'whisper.cpp', language: 'en' };
        } else {
          const source = join(dir, process.platform === 'darwin' ? 'speech.aiff' : 'speech.wav');
          const output = join(dir, 'output.wav');
          const sourceText = join(dir, 'text.txt');
          await writeFile(sourceText, text, { mode: 0o600 });
          await processAudio(c.speech, process.platform === 'darwin' ? ['-f', sourceText, '-o', source] : ['-f', sourceText, '-w', source], 60_000);
          await processAudio(c.ffmpeg, ['-nostdin', '-hide_banner', '-loglevel', 'error', '-i', source, '-ac', '1', '-ar', '22050', '-acodec', 'pcm_s16le', output]);
          const wav = await readFile(output);
          if (wav.length < 44 || wav.length > 16_777_216 || wav.toString('ascii', 0, 4) !== 'RIFF') throw new VoiceError(502, 'speech_failed', 'The speech engine did not produce playable audio.', true);
          speechResult = wav;
        }
      } finally {
        try { if (dir) await rm(dir, { recursive: true, force: true }); }
        finally { active = false; }
      }
      if (transcriptResult) json(res, 200, transcriptResult);
      else {
        res.writeHead(200, { 'content-type': 'audio/wav', 'content-length': speechResult.length, 'cache-control': 'no-store' });
        res.end(speechResult);
      }
    } catch (error) {
      const known = error instanceof VoiceError;
      json(res, known ? error.status : 500, { error: { code: known ? error.code : 'voice_failed', message: known ? error.message : 'Voice processing failed. Try again or type your message.', retryable: known ? error.retryable : true } });
    }
    return true;
  };
}
