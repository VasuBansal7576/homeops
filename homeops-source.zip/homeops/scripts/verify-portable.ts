import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { HouseholdDatasetSchema, type HouseholdSnapshot } from '../packages/contracts/src/index.ts';

const origin = process.env.HOMEOPS_URL ?? 'http://127.0.0.1:43110';
const directory = resolve(process.env.HOMEOPS_EVIDENCE_DIR ?? 'artifacts/verification/redesign');
const observations: { check: string; detail: unknown }[] = [];
const record = (check: string, detail: unknown = true) => { observations.push({ check, detail }); console.log(`VERIFIED ${check}`); };
let cookie = '';
let csrf = '';
async function request(path: string, options: RequestInit = {}) {
  return fetch(origin + path, { ...options, headers: { origin, cookie, 'content-type': 'application/json', 'x-homeops-csrf': csrf, ...options.headers } });
}
async function snapshot(): Promise<HouseholdSnapshot> {
  const response = await request('/api/homeops/snapshot');
  assert.equal(response.status, 200);
  return response.json();
}

let failure: string | null = null;
try {
  for (const route of ['/api/homeops/datasets', '/api/homeops/export']) assert.equal((await fetch(origin + route)).status, 401, route);
  record('Catalog and export require authentication');
  const login = await request('/api/auth/login', { method: 'POST', body: JSON.stringify({ password: process.env.HOMEOPS_PASSWORD ?? 'homeops-demo' }) });
  assert.equal(login.status, 200);
  cookie = login.headers.get('set-cookie')!.split(';')[0]!;
  csrf = (await login.json()).csrf;
  const catalogResponse = await request('/api/homeops/datasets');
  assert.equal(catalogResponse.status, 200);
  const catalog = await catalogResponse.json();
  assert.ok(catalog.datasets.length >= 2, 'Provide the primary and different-ID synthetic datasets');
  for (const entry of catalog.datasets) HouseholdDatasetSchema.parse(entry.dataset);
  record('Authenticated catalog contains separately validated datasets', catalog.datasets.map((entry: { id: string }) => entry.id));
  const before = await snapshot();
  if (process.argv.includes('--expect-empty')) {
    assert.equal(before.workspace.status, 'empty');
    for (const key of ['appliances', 'providers', 'expenses', 'cases'] as const) assert.equal(before[key].length, 0, key);
    const exported = await request('/api/homeops/export');
    assert.ok(!exported.ok, 'An empty workspace cannot fabricate a household export');
    record('Fresh startup has no implicit household or provider records');
  }
  const datasetIndex = process.argv.indexOf('--dataset');
  if (datasetIndex !== -1) {
    const file = process.argv[datasetIndex + 1];
    assert.ok(file, 'Supply the dataset JSON path after --dataset');
    const dataset = HouseholdDatasetSchema.parse(JSON.parse(await readFile(resolve(file), 'utf8')));
    if (before.workspace.status === 'empty') {
      const commandId = `verify-initialize:${createHash('sha256').update(JSON.stringify(dataset)).digest('hex')}`;
      const body = JSON.stringify({ commandId, command: { type: 'dataset.initialize', dataset } });
      const response = await request('/api/homeops/commands', { method: 'POST', body });
      assert.ok(response.ok, `Initialize returned ${response.status}: ${await response.text()}`);
      const replay = await request('/api/homeops/commands', { method: 'POST', body });
      assert.ok(replay.ok, 'The same initialization command must replay');
      record('Explicit dataset initialization and exact command replay succeed', dataset.metadata.id);
    } else {
      assert.equal(before.workspace.datasetId, dataset.metadata.id, 'Refuse to replace another initialized workspace');
      record('Existing workspace opened without reinitialization', dataset.metadata.id);
    }
  }
  const current = await snapshot();
  if (current.workspace.status === 'ready') {
    const response = await request('/api/homeops/export');
    assert.equal(response.status, 200);
    const exported = HouseholdDatasetSchema.parse(await response.json());
    assert.equal(exported.household.id, current.household.id);
    assert.equal(exported.household.name, current.household.name);
    assert.deepEqual(exported.household.budget, current.household.budget);
    for (const key of ['appliances', 'providers', 'expenses'] as const) assert.deepEqual(exported[key].map(record => record.id).sort(), current[key].map(record => record.id).sort(), key);
    record('Portable export validates and reflects the authoritative household', { workspace: current.workspace, appliances: exported.appliances.length, providers: exported.providers.length, expenses: exported.expenses.length });
    if (current.workspace.dataKind === 'personal') {
      assert.equal(current.workspace.providerMode, 'manual');
      assert.equal(exported.demoNow, null);
      assert.ok(exported.providers.every(provider => provider.simulation === null));
      assert.ok(Math.abs(Date.parse(current.clock.effectiveNow) - Date.now()) < 60_000, 'Personal household uses system time');
      record('Personal mode uses manual providers and system time');
    }
    await mkdir(directory, { recursive: true });
    await writeFile(resolve(directory, 'portable-export.json'), JSON.stringify(exported, null, 2) + '\n');
  }
} catch (error) {
  failure = error instanceof Error ? error.message : String(error);
  console.error(failure);
  process.exitCode = 1;
} finally {
  await mkdir(directory, { recursive: true });
  await writeFile(resolve(directory, 'portable-runtime.json'), JSON.stringify({ at: new Date().toISOString(), origin, observations, status: failure ? 'NOT VERIFIED' : 'VERIFIED', failure, limits: 'Checks initialization, transport and export only. It does not prove model inference, browser UI or complete workflow behavior.' }, null, 2) + '\n');
}
