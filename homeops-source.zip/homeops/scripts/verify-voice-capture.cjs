const assert = require('node:assert/strict');
const { createRequire } = require('node:module');
const path = require('node:path');
const project = path.resolve(__dirname, '..');
const requireProject = createRequire(path.join(project, 'package.json'));
const ts = requireProject('typescript');
const fs = require('node:fs');
const Module = require('node:module');
const React = requireProject('react');
const code = ts.transpileModule(fs.readFileSync(process.argv[2] || path.join(project, 'apps/web/app/_components/voice-controls.tsx'), 'utf8'), { compilerOptions: { module: ts.ModuleKind.CommonJS, jsx: ts.JsxEmit.ReactJSX, target: ts.ScriptTarget.ES2022 } }).outputText;
const compiled = new Module(path.join(project, 'apps/web/app/_components/voice-controls.test.cjs'));
compiled.filename = path.join(project, 'apps/web/app/_components/voice-controls.test.cjs');
compiled.paths = Module._nodeModulePaths(project);
compiled._compile(code, compiled.filename);
const { VoiceInput } = compiled.exports;
const internals = React.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;
class HookHarness {
  constructor(component, props) { this.component = component; this.props = props; this.slots = []; this.effects = []; }
  render() {
    let cursor = 0; const previous = internals.H; const slots = this.slots; const effects = this.effects;
    internals.H = {
      useState(initial) { const index = cursor++; if (!slots[index]) slots[index] = { value: typeof initial === 'function' ? initial() : initial }; return [slots[index].value, (value) => { slots[index].value = typeof value === 'function' ? value(slots[index].value) : value; }]; },
      useRef(initial) { const index = cursor++; if (!slots[index]) slots[index] = { current: initial }; return slots[index]; },
      useEffect(effect, deps) { const index = cursor++; const slot = slots[index]; if (!slot || !deps || deps.some((value, i) => !Object.is(value, slot.deps[i]))) { slots[index] = { deps, cleanup: slot?.cleanup }; effects.push(() => { slots[index].cleanup?.(); slots[index].cleanup = effect(); }); } },
    };
    try { this.tree = this.component(this.props); } finally { internals.H = previous; }
    for (const effect of effects.splice(0)) effect(); return this.tree;
  }
  unmount() { for (const slot of this.slots) slot?.cleanup?.(); }
}
function elements(node, match, result = []) { if (!node || typeof node !== 'object') return result; if (match(node)) result.push(node); for (const child of React.Children.toArray(node.props?.children)) elements(child, match, result); return result; }
function find(harness, type, label) { return elements(harness.tree, (node) => node.type === type && (!label || JSON.stringify(node.props.children).includes(label)))[0]; }
const flush = () => new Promise((resolve) => setImmediate(resolve));
const capability = { transcription: { available: true, engine: 'whisper.cpp' }, speech: { available: true, engine: 'local' }, limits: { maxSeconds: 30, maxBytes: 8388608 } };
globalThis.window = { isSecureContext: true };
let stopped = 0; let intervals = []; let requests = []; let transcripts = []; let mediaCalls = 0;
const stream = () => ({ getTracks: () => [{ stop: () => stopped++ }] });
Object.defineProperty(globalThis, 'navigator', { value: { mediaDevices: { getUserMedia: async () => { mediaCalls++; return stream(); } } }, configurable: true });
globalThis.setInterval = (callback) => { intervals.push(callback); return intervals.length; };
globalThis.clearInterval = () => {};
globalThis.FileReader = class { readAsDataURL(blob) { blob.arrayBuffer().then((buffer) => { this.result = `data:${blob.type};base64,${Buffer.from(buffer).toString('base64')}`; this.onload(); }); } };
globalThis.MediaRecorder = class {
  static isTypeSupported(type) { return type.startsWith('audio/webm'); }
  constructor(_stream, options) { this.mimeType = options?.mimeType || 'audio/webm'; this.state = 'inactive'; }
  start() { this.state = 'recording'; }
  stop() { this.state = 'inactive'; queueMicrotask(() => { this.ondataavailable?.({ data: new Blob(['actual-test-audio'], { type: this.mimeType }) }); this.onstop?.(); }); }
};
globalThis.fetch = async (url, options) => { requests.push({ url, options }); return url.endsWith('/speak') ? new Response(new Blob(['wav-test-data'], { type: 'audio/wav' }), { headers: { 'content-type': 'audio/wav' } }) : Response.json({ text: 'My sink is leaking.' }); };
const created = []; const revoked = [];
URL.createObjectURL = (blob) => { const url = `blob:controlled-${created.length}`; created.push({ blob, url }); return url; };
URL.revokeObjectURL = (url) => revoked.push(url);
const busy = [];
const props = { csrf: 'test-csrf', capability, disabled: false, onTranscript: (text) => transcripts.push(text), onBusyChange: (value) => busy.push(value) };

(async () => {
  let timers = [];
  let clock = 0;
  globalThis.setTimeout = (callback, delay) => {
    const timer = { callback, due: clock + delay };
    timers.push(timer);
    return timer;
  };
  globalThis.clearTimeout = (timer) => { timers = timers.filter((entry) => entry !== timer); };
  const advance = async (milliseconds) => {
    clock += milliseconds;
    for (const timer of [...timers]) if (timer.due <= clock) {
      clearTimeout(timer);
      timer.callback();
    }
    await flush();
  };
  const phase = (input) => input.tree.props['data-voice-input-state'];
  const mount = () => { const input = new HookHarness(VoiceInput, props); input.render(); return input; };
  const record = async (input) => {
    find(input, 'button', 'Record message').props.onClick();
    await flush(); input.render();
  };
  const results = [];
  const pending = () => {
    let resolve;
    navigator.mediaDevices.getUserMedia = () => new Promise((done) => { resolve = done; });
    return () => resolve(stream());
  };

  let grant = pending();
  let input = mount();
  await record(input);
  assert.equal(phase(input), 'requesting');
  assert.equal(busy.at(-1), true);
  await advance(19_999); input.render();
  assert.equal(phase(input), 'requesting');
  await advance(1); input.render();
  assert.equal(phase(input), 'error', 'Unresolved capture must recover after 20 seconds');
  assert.equal(input.tree.props['data-voice-error-code'], 'capture_timeout');
  assert.equal(busy.at(-1), false);
  assert.equal(find(input, 'input').props.disabled, false);
  assert.equal(find(input, 'button', 'Record message').props.disabled, false);
  let stoppedBefore = stopped;
  grant(); await flush(); input.render();
  assert.equal(stopped, stoppedBefore + 1);
  assert.equal(phase(input), 'error');
  assert.equal(requests.length, 0);
  input.unmount();
  results.push('20 second pending-request recovery, late grant stopped, no transcription');

  for (const action of ['cancel', 'unmount']) {
    grant = pending(); input = mount(); await record(input);
    stoppedBefore = stopped;
    if (action === 'cancel') { find(input, 'button', 'Cancel audio').props.onClick(); input.render(); }
    else input.unmount();
    grant(); await flush();
    assert.equal(stopped, stoppedBefore + 1);
    assert.equal(requests.length, 0);
    if (action === 'cancel') { input.render(); assert.equal(phase(input), 'idle'); input.unmount(); }
    await advance(20_000);
    assert.equal(timers.length, 0);
    results.push(`${action} invalidates late grant and clears deadlines`);
  }

  for (const name of ['NotAllowedError', 'NotFoundError', 'NotReadableError', 'SecurityError', 'AbortError']) {
    navigator.mediaDevices.getUserMedia = async () => { throw new DOMException('controlled failure', name); };
    input = mount(); await record(input);
    assert.equal(phase(input), 'error');
    assert.equal(input.tree.props['data-voice-error-code'], name);
    assert.equal(input.tree.props['data-microphone-error'], name);
    assert.equal(find(input, 'input').props.disabled, false);
    assert.equal(find(input, 'button', 'Record message').props.disabled, false);
    input.unmount();
    results.push(`${name} is observable with Record and upload recovery`);
  }

  let permission = 'prompt';
  let queries = 0;
  navigator.permissions = { query: async () => { queries++; return { state: permission }; } };
  navigator.mediaDevices.getUserMedia = async () => stream();
  input = mount(); await flush(); input.render();
  assert.equal(input.tree.props['data-microphone-permission'], 'prompt');
  permission = 'granted';
  await record(input);
  assert.equal(input.tree.props['data-microphone-permission'], 'granted');
  assert.equal(queries, 2);
  assert.equal(phase(input), 'recording');
  assert.equal(input.tree.props['data-voice-source'], 'live-microphone');
  const intervalCount = intervals.length;
  const previewFor = async (harness) => {
    find(harness, 'button', 'Stop').props.onClick();
    await flush(); await flush(); harness.render();
    assert.equal(phase(harness), 'review');
    const player = find(harness, 'audio');
    const download = find(harness, 'a', 'Download microphone recording');
    assert.equal(player.props.src, created.at(-1).url);
    assert.equal(download.props.href, player.props.src);
    assert.equal(download.props.download, 'homeops-microphone.webm');
    assert.equal(player.props.autoPlay, undefined);
    assert.equal(await created.at(-1).blob.text(), 'actual-test-audio');
    assert.equal(harness.tree.props['data-microphone-stage'], 'recording stopped');
    return player;
  };
  let player = await previewFor(input);
  assert.equal(requests.length, 1);
  const payload = JSON.parse(requests[0].options.body);
  assert.equal(Buffer.from(payload.audioBase64, 'base64').toString(), await created.at(-1).blob.text());
  assert.equal(requests[0].options.headers['x-homeops-csrf'], 'test-csrf');
  let pauses = 0; let unloads = 0;
  player.props.ref.current = { pause: () => pauses++, removeAttribute: () => {}, load: () => unloads++ };
  await record(input);
  assert.equal(pauses, 1); assert.equal(unloads, 1);
  assert.equal(revoked.at(-1), created[0].url);
  assert.equal(find(input, 'audio'), undefined);
  player = await previewFor(input);
  find(input, 'button', 'Discard microphone recording').props.onClick(); input.render();
  assert.equal(revoked.at(-1), created[1].url);
  assert.equal(find(input, 'audio'), undefined);
  assert.equal(phase(input), 'idle');
  await record(input); await previewFor(input);
  input.unmount();
  assert.equal(revoked.at(-1), created[2].url);
  assert.equal(intervals.length, intervalCount + 2);
  results.push('Observed permission is rechecked on Record without delaying capture');
  results.push('Actual recorder Blob preview matches transcription payload, has controls and no autoplay');
  results.push('Preview URL and playback cleaned before next capture, discard and unmount');

  navigator.permissions = { query: () => new Promise(() => {}) };
  input = mount(); await record(input);
  assert.equal(phase(input), 'recording');
  await advance(1_000); input.render();
  assert.equal(input.tree.props['data-microphone-permission'], 'unavailable');
  find(input, 'button', 'Cancel audio').props.onClick(); input.render();
  find(input, 'input').props.onChange({ currentTarget: { files: [new Blob(['uploaded-test-audio'], { type: 'audio/wav' })], value: 'test' } });
  await flush(); await flush(); input.render();
  assert.equal(phase(input), 'review');
  assert.equal(input.tree.props['data-voice-source'], 'recorded-audio');
  assert.equal(find(input, 'audio'), undefined);
  input.unmount();
  results.push('Unsettled permission query does not delay recording, upload never gains microphone preview');
  console.log(JSON.stringify({ boundary: 'Actual component callbacks with controlled browser APIs and React hook dispatcher. This does not prove host permission or live microphone capture.', results }, null, 2));
})().catch((error) => { console.error(error); process.exitCode = 1; });
