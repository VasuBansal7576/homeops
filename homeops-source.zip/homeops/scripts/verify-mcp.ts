import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import type { HouseholdSnapshot } from '../packages/contracts/src/index.ts';

type Invocation = { invocationId: string; status: string; pollAfterMs?: number; error?: unknown; inputRequests?: Record<string, { requestId: string; kind: string; action: { toolName: string; input: { caseId: string; approvalId: string } } }> };
const origin = process.env.HOMEOPS_URL ?? 'http://127.0.0.1:43110';
const tag = process.argv.includes('--denial') ? 'denial' : 'approval';
const run = process.env.HOMEOPS_VERIFY_RUN ?? '';
assert.match(run, /^[a-zA-Z0-9_-]*$/, 'Verification run must be a simple label');
const stem = `artifacts/verification/mcp-${tag}${run ? `-${run}` : ''}`;
const file = `${stem}-state.json`;
const login = await fetch(`${origin}/api/auth/login`, { method:'POST', headers:{origin,'content-type':'application/json'}, body:JSON.stringify({password:process.env.HOMEOPS_PASSWORD ?? 'homeops-demo'}) });
assert.equal(login.status, 200);
const cookie = login.headers.get('set-cookie')!.split(';')[0];
const { csrf } = await login.json();
const headers = { cookie, origin, 'content-type':'application/json', 'x-homeops-csrf':csrf };
let sequence = 0;
async function rpc(method: string, params: unknown = {}) {
  const id = ++sequence;
  const response = await fetch(`${origin}/eve/v1/mcp`, { method:'POST', headers:{...headers, accept:'application/json, text/event-stream','mcp-protocol-version':'2025-11-25'}, body:JSON.stringify({jsonrpc:'2.0',id,method,params}) });
  assert.equal(response.status,200);
  const body = await response.text();
  const replies = response.headers.get('content-type')?.includes('text/event-stream') ? body.split(/\r?\n\r?\n/).flatMap(block => {
    const data = block.split(/\r?\n/).filter(line => line.startsWith('data:')).map(line => line.slice(5).trim()).join('\n');
    return data ? [JSON.parse(data)] : [];
  }) : [JSON.parse(body)];
  const reply = replies.find(item => item.id === id);
  assert.ok(reply,'MCP response must match the JSON-RPC id');
  assert.equal(reply.error,undefined,JSON.stringify(reply.error));
  return reply.result;
}
async function call(name: string, args: unknown): Promise<Invocation> {
  const result = await rpc('tools/call',{name,arguments:args});
  assert.notEqual(result.isError,true,JSON.stringify(result));
  const invocation = result.structuredContent ?? JSON.parse(result.content.find((b: {type:string}) => b.type === 'text').text);
  assert.equal(typeof invocation.invocationId,'string');
  return invocation;
}
async function poll(current: Invocation, wanted: string) {
  const end = Date.now()+240000;
  while(current.status !== wanted) {
    assert.notEqual(current.status,'failed',JSON.stringify(current.error));
    assert.ok(['working','authorization_required'].includes(current.status),JSON.stringify(current));
    assert.ok(Date.now()<end,`Retain invocation ${current.invocationId} and resume agent_get`);
    await new Promise(resolve=>setTimeout(resolve,Math.max(1000,current.pollAfterMs ?? 1000)));
    current = await call('agent_get',{invocationId:current.invocationId});
  }
  return current;
}
async function snapshot(): Promise<HouseholdSnapshot> {
  const response=await fetch(`${origin}/api/homeops/snapshot`,{headers});assert.equal(response.status,200);return response.json();
}
try {
  assert.equal((await rpc('initialize',{protocolVersion:'2025-11-25',capabilities:{},clientInfo:{name:'homeops-journey-verifier',version:'1.0.0'}})).protocolVersion,'2025-11-25');
  if(process.argv.includes('--prepare')) {
    const before=await snapshot();
    assert.equal(before.household.name,'The Maple household');
    assert.ok(!before.cases.some(c=>c.applianceId==='ac'&&!['completed','denied','cancelled'].includes(c.state)),'Finish existing AC work before starting a separate MCP journey');
    const message='Use household_command to set the demo clock to 2026-10-22T09:00:00+05:30, then change the AC serviceDate to 2026-04-25. Read household_snapshot. For the newly due AC case, request offers, compare the declined preferred provider and alternatives against budget, choose the affordable quote and call book_service for durable approval. Do not change any other dates, quotes, charges or preferences. After consent report the result. All household data and providers are fictional fixtures.';
    await writeFile(`${stem}-start-intent.json`,JSON.stringify({at:new Date().toISOString(),message}),{flag:'wx'});
    const started=await call('agent_start',{message});
    await writeFile(file,JSON.stringify({invocation:started,before},null,2));
    const invocation=await poll(started,'input_required');
    const requests=Object.values(invocation.inputRequests!);
    assert.ok(requests.length>0);
    for(const request of requests) { assert.equal(request.kind,'tool-approval');assert.equal(request.action.toolName,'book_service'); }
    const caseId=requests[0]!.action.input.caseId;
    assert.equal((await snapshot()).cases.find(c=>c.id===caseId)!.booking,null);
    await writeFile(file,JSON.stringify({invocation,before,caseId},null,2));
    console.log(`VERIFIED MCP model/tools parked approval ${invocation.invocationId}`);
  } else {
    const saved=JSON.parse(await readFile(file,'utf8'));
    const resumed=await call('agent_get',{invocationId:saved.invocation.invocationId});
    assert.equal(resumed.status,'input_required');assert.deepEqual(resumed.inputRequests,saved.invocation.inputRequests);
    const responses=Object.values(resumed.inputRequests!).map(r=>({requestId:r.requestId,optionId:tag==='denial'?'cancel':'approve'}));
    const updated=await call('agent_update',{invocationId:resumed.invocationId,responses});
    const completed=await poll(updated,'completed');
    const after=await snapshot();const item=after.cases.find(c=>c.id===saved.caseId)!;
    assert.equal(item.state,tag==='denial'?'denied':'booked');
    if(tag==='denial') assert.equal(item.booking,null);else assert.ok(item.booking?.receiptId);
    assert.deepEqual(after.expenseTotals,saved.before.expenseTotals);
    const replayed=await call('agent_update',{invocationId:resumed.invocationId,responses});
    assert.equal(replayed.invocationId,resumed.invocationId);
    assert.deepEqual((await snapshot()).cases.find(c=>c.id===item.id)!.booking,item.booking);
    await writeFile(`${stem}-verification.json`,JSON.stringify({at:new Date().toISOString(),result:'VERIFIED',completed,replayed,case:item},null,2));
    console.log(`VERIFIED actual MCP ${tag} continuation and exact response replay`);
  }
} catch(error) {console.error(error);process.exitCode=1;}
