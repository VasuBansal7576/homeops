# HomeOps public source snapshot

This marker identifies the project root for the inactive alternate authorization adapter.
Read README.md for supported local setup. The selected planner uses Codex app-server.
The alternate direct Sign in with ChatGPT adapter remains inactive and unverified.
