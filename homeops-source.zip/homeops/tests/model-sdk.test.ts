import assert from 'node:assert/strict';
import { test } from 'node:test';
import { createOpenAI } from '@ai-sdk/openai';
import { stepCountIs, streamText, tool } from 'ai';
import { z } from 'zod';
import { createPlanFetch } from '../apps/agent/src/model/plan-fetch.ts';

test('installed AI SDK completes model, namespaced tool, model with full second-request history', async () => {
  const requests: Record<string, unknown>[] = [];
  let toolCalls = 0;
  const fetcher: typeof fetch = async (_url, init) => {
    requests.push(JSON.parse(String(init?.body)));
    const first = requests.length === 1;
    const events = first ? [
      { type: 'response.created', response: { id: 'res-1', created_at: 1, model: 'fixture-model' } },
      { type: 'response.output_item.added', output_index: 0, item: { type: 'function_call', id: 'fc-1', call_id: 'call-1', name: 'get_clock', namespace: 'homeops', arguments: '' } },
      { type: 'response.function_call_arguments.delta', item_id: 'fc-1', output_index: 0, delta: '{}' },
      { type: 'response.output_item.done', output_index: 0, item: { type: 'function_call', id: 'fc-1', call_id: 'call-1', name: 'get_clock', namespace: 'homeops', arguments: '{}', status: 'completed' } },
      { type: 'response.completed', response: {} },
    ] : [
      { type: 'response.created', response: { id: 'res-2', created_at: 2, model: 'fixture-model' } },
      { type: 'response.output_item.added', output_index: 0, item: { type: 'message', id: 'msg-1' } },
      { type: 'response.output_text.delta', item_id: 'msg-1', output_index: 0, delta: 'The business clock is 2026-10-21.' },
      { type: 'response.output_item.done', output_index: 0, item: { type: 'message', id: 'msg-1' } },
      { type: 'response.completed', response: {} },
    ];
    return new Response(events.map(event => `data: ${JSON.stringify(event)}\n\n`).join(''), { headers: { 'content-type': 'text/event-stream' } });
  };
  const openai = createOpenAI({ apiKey: 'placeholder-overridden-by-fetch', fetch: createPlanFetch({ fetcher, getAccessToken: async () => 'synthetic-fixture-token' }) });
  const result = streamText({
    model: openai.responses('fixture-model'),
    system: 'You are HomeOps.',
    prompt: 'What is the business clock?',
    tools: { get_clock: tool({ inputSchema: z.object({}), execute: async () => { toolCalls++; return { date: '2026-10-21' }; } }) },
    stopWhen: stepCountIs(2),
    providerOptions: { openai: { store: false } },
  });
  assert.equal(await result.text, 'The business clock is 2026-10-21.');
  assert.equal(toolCalls, 1);
  assert.equal(requests.length, 2);
  const history = requests[1].input as Record<string, unknown>[];
  assert.equal(history.some(item => item.type === 'item_reference'), false);
  assert.equal(history.find(item => item.type === 'function_call')?.namespace, 'homeops');
  assert.equal(history.some(item => item.type === 'function_call_output' && String(item.output).includes('2026-10-21')), true);
  assert.equal(history[0].role, 'developer');
  assert.equal(requests.every(request => request.store === false && request.stream === true), true);
});
