import { demoDataset } from '../datasets/catalog.ts';
import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { openHomeOps, type HomeOps, type HomeCommand } from '../apps/agent/src/homeops/index.ts';
import { allowsSlot, earliestSlot } from '../apps/agent/src/homeops/availability.ts';
import { AvailabilityPreferencesSchema, DEFAULT_AVAILABILITY_PREFERENCES, PublicCommandSchema, type AvailabilityPreferences, type PublicCommand } from '../packages/contracts/src/index.ts';

const operator = { principalId: 'demo-operator', role: 'operator' as const };
const afternoons: AvailabilityPreferences = { daysOfWeek: [1, 2, 3, 4, 5], startTime: '15:00', endTime: '18:00', timezone: 'Asia/Kolkata' };
function fixture(faultAfterProviderAcceptance?: () => void) {
  const filename = join(mkdtempSync(join(tmpdir(), 'homeops-availability-')), 'home.sqlite');
  let home = openHomeOps({ initialDataset: demoDataset, filename, faultAfterProviderAcceptance }); let serial = 0;
  return {
    filename,
    get home() { return home; },
    snapshot: () => home.snapshot(operator),
    send: (command: PublicCommand | { type: 'case.book'; caseId: string; approvalId: string }) => home.execute(operator, { ...command, id: `availability-${++serial}` } as HomeCommand),
    restart: () => { home.close(); home = openHomeOps({ initialDataset: demoDataset, filename }); },
    close: () => home.close(),
  };
}
type Fixture = ReturnType<typeof fixture>;
const ac = (f: Fixture) => f.snapshot().cases.find(c => c.applianceId === 'ac')!;
async function offers(f: Fixture) {
  await f.send({ type: 'case.requestOffers', caseId: ac(f).id });
  return ac(f).offers.find(offer => offer.providerId === 'coolcare')!;
}
async function select(f: Fixture) {
  const offer = await offers(f);
  await f.send({ type: 'case.chooseOffer', caseId: ac(f).id, offerId: offer.id, revision: offer.revision });
  const approval = ac(f).approval!;
  const binding = { approvalId: approval.id, callId: `call-${approval.id}`, requestId: `request-${approval.id}`, sessionId: `session-${approval.id}` };
  f.home.bindApproval(operator, binding);
  return { approval, binding };
}
const approve = (home: HomeOps, binding: Awaited<ReturnType<typeof select>>['binding']) => home.settleApproval(operator, { ...binding, id: `settle-${binding.approvalId}`, responderId: operator.principalId, decision: 'approve' });

test('strict schedule schema rejects malformed, ambiguous and unsupported rules', () => {
  for (const bad of [
    { daysOfWeek: [] }, { daysOfWeek: [0] }, { daysOfWeek: [8] }, { daysOfWeek: [1, 1] }, { daysOfWeek: [1.5] },
    { startTime: '9:00' }, { startTime: '24:00' }, { startTime: '09:60' }, { endTime: '12:00:00' },
    { startTime: '17:30', endTime: '18:00' }, { startTime: '18:00', endTime: '15:00' },
    { timezone: 'UTC' }, { windows: [] },
  ]) {
    const preferences = { ...afternoons, ...bad };
    assert.equal(AvailabilityPreferencesSchema.safeParse(preferences).success, false, JSON.stringify(bad));
    assert.equal(PublicCommandSchema.safeParse({ type: 'preference.setSchedule', preferences }).success, false);
  }
  assert.equal(AvailabilityPreferencesSchema.safeParse({ ...afternoons, startTime: '17:00' }).success, true);
});

test('routine slots skip weekends, support Sunday afternoons and stay on the local calendar across UTC midnight', () => {
  assert.equal(earliestSlot(afternoons, '2026-10-23T16:00:00+05:30', false)!.start, '2026-10-26T09:30:00.000Z');
  const sunday = { ...afternoons, daysOfWeek: [7], startTime: '14:30', endTime: '15:30' };
  assert.deepEqual(earliestSlot(sunday, '2026-10-23T16:00:00+05:30', false), { start: '2026-10-25T09:00:00.000Z', end: '2026-10-25T10:00:00.000Z' });
  assert.equal(earliestSlot({ ...afternoons, startTime: '00:00', endTime: '01:00' }, '2026-10-22T23:59:00+05:30', false)!.start, '2026-10-22T18:30:00.000Z');
  assert.equal(earliestSlot(sunday, '2026-10-25T08:00:00+05:30', false)!.start, '2026-11-01T09:00:00.000Z');
});

test('urgent slots honor the two-hour lead and exact full-hour boundaries without an outside-window fallback', () => {
  assert.equal(earliestSlot(afternoons, '2026-10-23T14:00:00+05:30', true)!.start, '2026-10-23T10:30:00.000Z');
  assert.equal(earliestSlot(afternoons, '2026-10-23T15:00:00+05:30', true)!.end, '2026-10-23T12:30:00.000Z');
  assert.equal(earliestSlot(afternoons, '2026-10-23T15:00:00.001+05:30', true)!.start, '2026-10-26T09:30:00.000Z');
  assert.equal(earliestSlot(afternoons, '2026-10-23T17:00:00+05:30', true)!.start, '2026-10-26T09:30:00.000Z');
  assert.equal(allowsSlot(afternoons, { start: '2026-10-23T17:00:00+05:30', end: '2026-10-23T18:00:00+05:30' }), true);
  for (const slot of [
    { start: '2026-10-23T17:00:00+05:30', end: '2026-10-23T18:00:00.001+05:30' },
    { start: '2026-10-23T14:59:00+05:30', end: '2026-10-23T15:59:00+05:30' },
    { start: '2026-10-24T15:00:00+05:30', end: '2026-10-24T16:00:00+05:30' },
    { start: '2026-10-23T15:00:00+05:30', end: '2026-10-23T15:30:00+05:30' },
  ]) assert.equal(allowsSlot(afternoons, slot), false);
  assert.equal(earliestSlot({ ...afternoons, daysOfWeek: [] }, '2026-10-23T17:00:00+05:30', true), null);
});

test('saved rules generate actual Friday-to-Monday offers and survive restart while notes stay separate', async () => {
  const f = fixture();
  try {
    await f.send({ type: 'clock.set', now: '2026-10-23T16:00:00+05:30' });
    await f.send({ type: 'preference.save', text: 'Sunday morning only, as a note.' });
    assert.deepEqual(f.snapshot().schedulingPreferences, DEFAULT_AVAILABILITY_PREFERENCES);
    await f.send({ type: 'preference.setSchedule', preferences: { ...afternoons, daysOfWeek: [5, 3, 1, 4, 2] } });
    assert.deepEqual(f.snapshot().schedulingPreferences, afternoons);
    assert.equal((await offers(f)).terms!.slot.start, '2026-10-26T09:30:00.000Z');
    f.restart();
    assert.deepEqual(f.snapshot().schedulingPreferences, afternoons);
    assert.equal(ac(f).offers.find(offer => offer.providerId === 'coolcare')!.terms!.slot.start, '2026-10-26T09:30:00.000Z');
    await f.send({ type: 'preference.setSchedule', preferences: { ...afternoons, daysOfWeek: [7] } });
    assert.equal((await offers(f)).terms!.slot.start, '2026-10-25T09:30:00.000Z');
  } finally { f.close(); }
});

test('old SQLite initializes default availability exactly once without duplicating or resetting household records', async () => {
  const f = fixture();
  await f.send({ type: 'preference.save', text: 'Leave shoes by the door.' });
  const before = f.snapshot(); f.close();
  const db = new DatabaseSync(f.filename);
  db.prepare("DELETE FROM meta WHERE id='schedulingPreferences'").run(); db.close();
  let home = openHomeOps({ initialDataset: demoDataset, filename: f.filename });
  assert.deepEqual(home.snapshot(operator).schedulingPreferences, DEFAULT_AVAILABILITY_PREFERENCES);
  assert.deepEqual(home.snapshot(operator).expenses, before.expenses);
  assert.deepEqual(home.snapshot(operator).preferences, before.preferences);
  const revision = home.snapshot(operator).revision; home.close();
  home = openHomeOps({ initialDataset: demoDataset, filename: f.filename });
  assert.deepEqual(home.snapshot(operator).schedulingPreferences, DEFAULT_AVAILABILITY_PREFERENCES);
  assert.equal(home.snapshot(operator).revision, revision); home.close();
});

test('same normalized schedule and exact replay preserve pending consent; an actual change stales offers and consent', async () => {
  const f = fixture();
  try {
    await f.send({ type: 'clock.set', now: '2026-10-22T09:00:00+05:30' });
    const { approval, binding } = await select(f);
    const before = ac(f).approval;
    const command = { id: 'same-rules', type: 'preference.setSchedule' as const, preferences: { ...DEFAULT_AVAILABILITY_PREFERENCES, daysOfWeek: [5, 4, 3, 2, 1] } };
    await f.home.execute(operator, command);
    assert.equal((await f.home.execute(operator, command)).status, 'replayed');
    assert.deepEqual(ac(f).approval, before);
    const oldOffer = ac(f).offers.find(offer => offer.id === approval.terms.offerId)!;
    await f.send({ type: 'preference.setSchedule', preferences: afternoons });
    assert.equal(ac(f).approval!.status, 'invalidated');
    assert.ok(ac(f).offers.every(offer => offer.status !== 'available'));
    await assert.rejects(approve(f.home, binding), /stale/i);
    await assert.rejects(f.send({ type: 'case.chooseOffer', caseId: ac(f).id, offerId: oldOffer.id, revision: oldOffer.revision }), /stale/i);
    const fresh = await select(f); assert.notEqual(fresh.approval.id, approval.id);
    assert.equal(fresh.approval.terms.slot.start, '2026-10-23T09:30:00.000Z');
    await approve(f.home, fresh.binding);
    await f.send({ type: 'case.book', caseId: ac(f).id, approvalId: fresh.approval.id });
    assert.equal(ac(f).state, 'booked');
  } finally { f.close(); }
});

test('changed rules invalidate approved booking authority even when the old appointment would still fit', async () => {
  const f = fixture();
  try {
    await f.send({ type: 'clock.set', now: '2026-10-22T09:00:00+05:30' });
    const { approval, binding } = await select(f); await approve(f.home, binding);
    await f.send({ type: 'preference.setSchedule', preferences: { ...DEFAULT_AVAILABILITY_PREFERENCES, endTime: '13:00' } });
    assert.equal(ac(f).approval!.status, 'invalidated');
    await assert.rejects(f.send({ type: 'case.book', caseId: ac(f).id, approvalId: approval.id }), /approval|stale/i);
    assert.equal(ac(f).booking, null);
  } finally { f.close(); }
});

for (const settled of [false, true]) {
  test(`legacy ${settled ? 'approved authority' : 'pending consent'} outside default availability is rechecked after migration`, async () => {
    const f = fixture();
    await f.send({ type: 'clock.set', now: '2026-10-23T09:00:00+05:30' });
    await f.send({ type: 'preference.setSchedule', preferences: { ...DEFAULT_AVAILABILITY_PREFERENCES, daysOfWeek: [6] } });
    const { approval, binding } = await select(f);
    assert.equal(approval.terms.slot.start, '2026-10-24T03:30:00.000Z');
    if (settled) await approve(f.home, binding);
    f.close();
    const db = new DatabaseSync(f.filename);
    db.prepare("DELETE FROM meta WHERE id='schedulingPreferences'").run(); db.close();
    const home = openHomeOps({ initialDataset: demoDataset, filename: f.filename });
    try {
      const migrated = home.snapshot(operator).cases.find(c => c.applianceId === 'ac')!;
      assert.equal(migrated.approval!.status, settled ? 'approved' : 'pending');
      if (settled) await assert.rejects(home.execute(operator, { id: 'legacy-book', type: 'case.book', caseId: migrated.id, approvalId: approval.id }), /scheduling preferences/i);
      else await assert.rejects(approve(home, binding), /scheduling preferences/i);
      assert.equal(home.snapshot(operator).cases.find(c => c.applianceId === 'ac')!.booking, null);
    } finally { home.close(); }
  });
}

test('quote fixtures cannot bypass saved weekdays or full-hour window edges', async () => {
  const f = fixture();
  try {
    await f.send({ type: 'clock.set', now: '2026-10-22T09:00:00+05:30' });
    let offer = await offers(f);
    for (const start of ['2026-10-24T09:00:00+05:30', '2026-10-23T11:01:00+05:30']) {
      await f.send({ type: 'fixture.change', change: { kind: 'quote', offerId: offer.id, amount: { minor: 180000, currency: 'INR' }, start } });
      offer = ac(f).offers.find(row => row.id === offer.id)!;
      await assert.rejects(f.send({ type: 'case.chooseOffer', caseId: ac(f).id, offerId: offer.id, revision: offer.revision }), /scheduling/i);
      assert.equal(ac(f).approval, null);
    }
    await f.send({ type: 'fixture.change', change: { kind: 'quote', offerId: offer.id, amount: { minor: 180000, currency: 'INR' }, start: '2026-10-23T11:00:00+05:30' } });
    offer = ac(f).offers.find(row => row.id === offer.id)!;
    await f.send({ type: 'case.chooseOffer', caseId: ac(f).id, offerId: offer.id, revision: offer.revision });
    assert.equal(ac(f).approval!.status, 'pending');
  } finally { f.close(); }
});

test('urgent offers disclose a saved-window delay and remain inspection-only', async () => {
  const f = fixture();
  try {
    await f.send({ type: 'clock.set', now: '2026-10-23T17:00:00+05:30' });
    await f.send({ type: 'preference.setSchedule', preferences: afternoons });
    const opened = await f.send({ type: 'case.openUrgent', applianceId: 'sink', description: 'Leaking sink' });
    await f.send({ type: 'case.requestOffers', caseId: opened.affectedIds[0]! });
    const offer = f.snapshot().cases.find(c => c.id === opened.affectedIds[0])!.offers.find(offer => offer.providerId === 'plumber-local')!;
    assert.equal(offer.terms!.slot.start, '2026-10-26T09:30:00.000Z');
    assert.match(offer.explanation, /urgent.*delayed.*availability/i);
    assert.deepEqual(offer.terms!.charge, { kind: 'inspection', fee: { minor: 50000, currency: 'INR' }, parts: 'unknown' });
  } finally { f.close(); }
});

test('provider acceptance crash followed by preference change reconciles exactly one original reservation', async () => {
  let fail = true;
  const f = fixture(() => { if (fail) { fail = false; throw new Error('receipt crash'); } });
  try {
    await f.send({ type: 'clock.set', now: '2026-10-22T09:00:00+05:30' });
    const { approval, binding } = await select(f); await approve(f.home, binding);
    const command = { id: 'stable-book', type: 'case.book' as const, caseId: ac(f).id, approvalId: approval.id };
    const before = f.snapshot();
    await assert.rejects(f.home.execute(operator, command), /receipt crash/);
    await f.send({ type: 'preference.setSchedule', preferences: afternoons });
    assert.equal(ac(f).approval!.status, 'consumed');
    assert.equal(ac(f).booking!.start, approval.terms.slot.start);
    assert.equal(f.snapshot().activity.filter(a => a.kind === 'provider.accepted').length, 1);
    f.restart();
    await f.home.execute(operator, command);
    await f.send({ type: 'case.book', caseId: ac(f).id, approvalId: approval.id });
    assert.equal(ac(f).booking!.start, approval.terms.slot.start);
    assert.equal(ac(f).approval!.status, 'consumed');
    assert.deepEqual(f.snapshot().expenses, before.expenses);
    assert.deepEqual(f.snapshot().appliances, before.appliances);
    const db = new DatabaseSync(f.filename, { readOnly: true });
    assert.equal(db.prepare('SELECT count(*) AS count FROM provider_operations').get()!.count, 1);
    assert.equal(db.prepare('SELECT count(*) AS count FROM bookings').get()!.count, 1); db.close();
    const booked = ac(f);
    await f.send({ type: 'preference.setSchedule', preferences: { ...afternoons, daysOfWeek: [7] } });
    assert.deepEqual(ac(f), booked);
  } finally { f.close(); }
});
