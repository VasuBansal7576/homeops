import { demoDataset } from '../datasets/catalog.ts';
import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { openHomeOps, type HomeCommand, type HomeOps } from '../apps/agent/src/homeops/index.ts';
import type { CaseCard, PublicCommand } from '../packages/contracts/src/index.ts';

const operator = { principalId: 'demo-operator', role: 'operator' as const };
const scheduler = { principalId: 'schedule', role: 'scheduler' as const };
const money = (minor: number) => ({ minor, currency: 'INR' as const });
function fixture() {
  const filename = join(mkdtempSync(join(tmpdir(), 'homeops-scenarios-')), 'home.sqlite');
  let home = openHomeOps({ initialDataset: demoDataset, filename }); let serial = 0;
  return {
    get home() { return home; },
    snapshot: () => home.snapshot(operator),
    send: (command: PublicCommand | { type: 'work.tick' }) => home.execute(operator, { ...command, id: `scenario-${++serial}` } as HomeCommand),
    restart: () => { home.close(); home = openHomeOps({ initialDataset: demoDataset, filename }); },
    close: () => home.close(),
  };
}
type Fixture = ReturnType<typeof fixture>;
const currentCase = (f: Fixture, applianceId: string) => f.snapshot().cases.find(c => c.applianceId === applianceId && !['completed', 'cancelled'].includes(c.state) && !c.title.includes('warranty'))!;
const appliance = (f: Fixture, id: string) => f.snapshot().appliances.find(a => a.id === id)!;
async function choose(f: Fixture, c: CaseCard, providerId: string) {
  await f.send({ type: 'case.requestOffers', caseId: c.id });
  const offer = f.snapshot().cases.find(row => row.id === c.id)!.offers.find(o => o.providerId === providerId)!;
  await f.send({ type: 'case.chooseOffer', caseId: c.id, offerId: offer.id, revision: offer.revision });
  return f.snapshot().cases.find(row => row.id === c.id)!.approval!;
}
async function approveAndBook(f: Fixture, c: CaseCard, providerId: string) {
  const approval = await choose(f, c, providerId);
  const binding = { approvalId: approval.id, callId: `call-${approval.id}`, sessionId: `session-${approval.id}`, requestId: `request-${approval.id}` };
  f.home.bindApproval(operator, binding);
  await f.home.settleApproval(operator, { ...binding, id: `settle-${approval.id}`, decision: 'approve', responderId: operator.principalId });
  await f.home.execute(operator, { id: `book-${approval.id}`, type: 'case.book', caseId: c.id, approvalId: approval.id });
  return approval;
}

for (const scenario of [
  { id: 'purifier', day: '2026-10-28', completed: '2026-10-29', provider: 'pure-local', next: '2027-04-27', policy: 90, changedNext: '2027-01-27' },
  { id: 'garden', day: '2026-10-31', completed: '2026-11-02', provider: 'garden-local', next: '2026-12-02', policy: 14, changedNext: '2026-11-16' },
]) {
  test(`${scenario.id} uses its own providers, approval and completion policy across restart`, async () => {
    const f = fixture();
    try {
      await f.send({ type: 'clock.set', now: `${scenario.day}T09:00:00+05:30` });
      const c = currentCase(f, scenario.id); assert.ok(c);
      const oldService = appliance(f, scenario.id).lastService;
      const spending = f.snapshot().expenseTotals;
      const approval = await choose(f, c, scenario.provider);
      const offers = f.snapshot().cases.find(row => row.id === c.id)!.offers;
      assert.equal(offers.length, 3);
      assert.ok(offers.some(o => o.status === 'declined'));
      assert.ok(offers.some(o => o.withinBudget === false));
      assert.ok(offers.every(o => !['preferred', 'premium', 'coolcare'].includes(o.providerId)));
      assert.equal(approval.terms.slot.start.slice(0, 10), scenario.completed);
      assert.ok(Date.parse(approval.terms.expiresAt) > Date.parse(f.snapshot().clock.effectiveNow));
      await assert.rejects(f.home.execute(operator, { id: 'no-approval', type: 'case.book', caseId: c.id, approvalId: approval.id }), /approval/i);
      const binding = { approvalId: approval.id, callId: 'call', sessionId: 'session', requestId: 'request' };
      f.home.bindApproval(operator, binding); f.restart();
      assert.equal(f.snapshot().cases.find(row => row.id === c.id)!.approval!.status, 'pending');
      await f.home.settleApproval(operator, { ...binding, id: 'approve', decision: 'approve', responderId: operator.principalId });
      await f.home.execute(operator, { id: 'book', type: 'case.book', caseId: c.id, approvalId: approval.id });
      await f.home.execute(operator, { id: 'book-retry', type: 'case.book', caseId: c.id, approvalId: approval.id });
      assert.deepEqual(appliance(f, scenario.id).lastService, oldService);
      assert.deepEqual(f.snapshot().expenseTotals, spending);
      await f.send({ type: 'clock.set', now: `${scenario.completed}T11:00:00+05:30` });
      await f.send({ type: 'case.complete', caseId: c.id, completedAt: scenario.completed, sourceId: `technician:${scenario.id}` });
      assert.equal(appliance(f, scenario.id).nextDue.value, scenario.next);
      assert.deepEqual(f.snapshot().expenseTotals, spending);
      await f.send({ type: 'fixture.change', change: { kind: 'policy', applianceId: scenario.id, intervalDays: scenario.policy } });
      assert.equal(appliance(f, scenario.id).nextDue.value, scenario.changedNext);
      f.restart();
      await f.send({ type: 'clock.set', now: `${scenario.changedNext}T09:00:00+05:30` });
      await f.send({ type: 'work.tick' });
      const recurrence = f.snapshot().cases.filter(row => row.applianceId === scenario.id && row.state === 'due');
      assert.equal(recurrence.length, 1); assert.notEqual(recurrence[0]!.id, c.id);
      assert.ok(f.home.pendingJobs(scheduler).some(j => j.caseId === recurrence[0]!.id));
    } finally { f.close(); }
  });

  test(`${scenario.id} source and policy changes recalculate pending work and preserve unknown dates`, async () => {
    const f = fixture();
    try {
      await f.send({ type: 'clock.set', now: `${scenario.day}T09:00:00+05:30` });
      const c = currentCase(f, scenario.id);
      await choose(f, c, scenario.provider);
      await f.send({ type: 'fixture.change', change: { kind: 'serviceDate', applianceId: scenario.id, performedOn: null } });
      assert.equal(appliance(f, scenario.id).nextDue.value, null);
      assert.equal(f.snapshot().cases.find(row => row.id === c.id)!.state, 'cancelled');
      assert.equal(f.snapshot().cases.find(row => row.id === c.id)!.approval!.status, 'invalidated');
      assert.ok(!f.home.pendingJobs(scheduler).some(j => j.caseId === c.id));
      f.restart(); await f.send({ type: 'work.tick' });
      assert.ok(!currentCase(f, scenario.id));
      await f.send({ type: 'fixture.change', change: { kind: 'serviceDate', applianceId: scenario.id, performedOn: '2026-10-01' } });
      await f.send({ type: 'fixture.change', change: { kind: 'policy', applianceId: scenario.id, intervalDays: 1 } });
      const fresh = currentCase(f, scenario.id); assert.ok(fresh); assert.notEqual(fresh.id, c.id);
      await f.send({ type: 'fixture.change', change: { kind: 'policy', applianceId: scenario.id, intervalDays: 365 } });
      assert.equal(appliance(f, scenario.id).nextDue.value, '2027-10-01');
      assert.equal(f.snapshot().cases.find(row => row.id === fresh.id)!.state, 'cancelled');
    } finally { f.close(); }
  });
}

test('washer warranty warning uses its stored source, deduplicates and cannot authorize service', async () => {
  const f = fixture();
  try {
    await f.send({ type: 'clock.set', now: '2026-10-24T09:00:00+05:30' });
    assert.ok(!f.snapshot().cases.some(c => c.title.includes('warranty')));
    await f.send({ type: 'clock.set', now: '2026-10-25T09:00:00+05:30' });
    const warning = f.snapshot().cases.find(c => c.title.includes('warranty'))!; assert.ok(warning);
    assert.match(warning.reason, /2026-11-01/); assert.match(warning.reason, /unverified/);
    const event = f.snapshot().activity.find(a => a.caseId === warning.id && a.kind === 'warranty.expiry')!;
    const warranty = appliance(f, 'washer').warrantyEnds;
    assert.ok('sourceId' in warranty && event.sourceIds.includes(warranty.sourceId));
    assert.ok(!warning.offers.length); assert.equal(warning.booking, null);
    await assert.rejects(f.send({ type: 'case.requestOffers', caseId: warning.id }), /warranty/i);
    const job = f.home.pendingJobs(scheduler).find(j => j.caseId === warning.id)!;
    assert.equal(job.kind, 'warranty'); assert.ok(job.inboxId);
    f.home.claimJob(scheduler, { jobId: job.id, owner: 'worker' });
    f.home.bindJobSession(scheduler, { jobId: job.id, owner: 'worker', sessionId: 'warranty-session' });
    f.restart(); await f.send({ type: 'clock.set', now: '2026-11-03T09:00:00+05:30' }); await f.send({ type: 'work.tick' });
    assert.equal(f.snapshot().cases.filter(c => c.title.includes('warranty')).length, 1);
    assert.equal(f.snapshot().inbox.filter(i => i.caseId === warning.id).length, 1);
    assert.equal(f.snapshot().inbox.find(i => i.caseId === warning.id)!.sessionId, 'warranty-session');
    assert.ok(!f.home.pendingJobs(scheduler).some(j => j.caseId === warning.id));
    assert.equal(appliance(f, 'washer').lastService.value, '2026-07-10');
  } finally { f.close(); }
});

for (const explicitlyUnconfirmed of [false, true]) {
  test(`appointment follow-up is durable and deduplicated for ${explicitlyUnconfirmed ? 'explicit false confirmation' : 'a missed confirmation'}`, async () => {
    const f = fixture();
    try {
      await f.send({ type: 'clock.set', now: '2026-10-22T09:00:00+05:30' });
      const c = currentCase(f, 'ac'); await approveAndBook(f, c, 'coolcare');
      const service = appliance(f, 'ac').lastService; const spending = f.snapshot().expenseTotals;
      const initialJob = f.home.pendingJobs(scheduler).find(j => j.caseId === c.id)!;
      f.home.claimJob(scheduler, { jobId: initialJob.id, owner: 'worker' });
      f.home.bindJobSession(scheduler, { jobId: initialJob.id, owner: 'worker', sessionId: 'booking-session' });
      await f.send({ type: 'work.tick' });
      assert.equal(f.snapshot().inbox.filter(i => i.caseId === c.id).length, 1);
      if (explicitlyUnconfirmed) await f.send({ type: 'case.confirmAppointment', caseId: c.id, confirmed: false });
      else await f.send({ type: 'clock.set', now: '2026-10-23T10:01:00+05:30' });
      const followup = f.home.pendingJobs(scheduler).find(j => j.caseId === c.id && j.kind === 'confirmation')!;
      assert.ok(followup); assert.notEqual(followup.id, initialJob.id);
      if (!explicitlyUnconfirmed) {
        await f.send({ type: 'clock.set', now: '2026-10-23T09:00:00+05:30' });
        assert.ok(!f.home.pendingJobs(scheduler).some(j => j.id === followup.id));
        await f.send({ type: 'clock.set', now: '2026-10-23T10:01:00+05:30' });
        assert.equal(f.home.pendingJobs(scheduler).filter(j => j.id === followup.id).length, 1);
      }
      if (explicitlyUnconfirmed) {
        assert.equal(f.snapshot().cases.find(row => row.id === c.id)!.booking!.confirmed, false);
        assert.ok(f.snapshot().activity.some(a => a.caseId === c.id && a.kind === 'appointment.unconfirmed'));
      }
      f.restart(); await f.send({ type: 'work.tick' }); await f.send({ type: 'work.tick' });
      assert.equal(f.snapshot().inbox.filter(i => i.caseId === c.id).length, 2);
      assert.equal(f.home.pendingJobs(scheduler).filter(j => j.caseId === c.id && j.kind === 'confirmation').length, 1);
      f.home.claimJob(scheduler, { jobId: followup.id, owner: 'followup-worker' });
      f.home.bindJobSession(scheduler, { jobId: followup.id, owner: 'followup-worker', sessionId: 'followup-session' });
      assert.equal(f.snapshot().inbox.find(i => i.id === initialJob.inboxId)!.sessionId, 'booking-session');
      assert.equal(f.snapshot().inbox.find(i => i.id === followup.inboxId)!.sessionId, 'followup-session');
      await f.send({ type: 'work.tick' });
      assert.ok(!f.home.pendingJobs(scheduler).some(j => j.id === followup.id));
      assert.deepEqual(appliance(f, 'ac').lastService, service); assert.deepEqual(f.snapshot().expenseTotals, spending);
      await f.send({ type: 'case.confirmAppointment', caseId: c.id, confirmed: true });
      assert.equal(f.snapshot().cases.find(row => row.id === c.id)!.state, 'awaiting_completion');
      assert.deepEqual(appliance(f, 'ac').lastService, service);
    } finally { f.close(); }
  });
}

test('confirmation or separate completion supersedes an undispatched follow-up without changing spending', async () => {
  for (const complete of [false, true]) {
    const f = fixture();
    try {
      await f.send({ type: 'clock.set', now: '2026-10-22T09:00:00+05:30' });
      const c = currentCase(f, 'ac'); await approveAndBook(f, c, 'coolcare');
      await f.send({ type: 'clock.set', now: '2026-10-23T11:00:00+05:30' });
      assert.ok(f.home.pendingJobs(scheduler).some(j => j.kind === 'confirmation'));
      const spending = f.snapshot().expenseTotals;
      if (complete) await f.send({ type: 'case.complete', caseId: c.id, completedAt: '2026-10-23', sourceId: 'technician-report' });
      else await f.send({ type: 'case.confirmAppointment', caseId: c.id, confirmed: true });
      f.restart(); await f.send({ type: 'work.tick' });
      assert.ok(!f.home.pendingJobs(scheduler).some(j => j.kind === 'confirmation'));
      assert.deepEqual(f.snapshot().expenseTotals, spending);
    } finally { f.close(); }
  }
});

test('urgent leaking sink needs no due date and approval covers only an inspection with unknown final repair cost', async () => {
  const f = fixture();
  try {
    await f.send({ type: 'clock.set', now: '2026-10-21T08:00:00+05:30' });
    await f.send({ type: 'fixture.change', change: { kind: 'serviceDate', applianceId: 'sink', performedOn: null } });
    assert.equal(appliance(f, 'sink').nextDue.value, null);
    const opened = await f.send({ type: 'case.openUrgent', applianceId: 'sink', description: 'Water is leaking under the kitchen sink.' });
    const duplicate = await f.send({ type: 'case.openUrgent', applianceId: 'sink', description: 'The sink is still leaking.' });
    assert.deepEqual(opened.affectedIds, duplicate.affectedIds);
    const c = currentCase(f, 'sink'); assert.equal(c.urgent, true);
    const spending = f.snapshot().expenseTotals;
    const pending = await choose(f, c, 'plumber-local');
    assert.deepEqual(pending.terms.charge, { kind: 'inspection', fee: money(50000), parts: 'unknown' });
    assert.ok(Date.parse(pending.terms.slot.start) > Date.parse(f.snapshot().clock.effectiveNow));
    assert.ok(Date.parse(pending.terms.slot.start) - Date.parse(f.snapshot().clock.effectiveNow) < 3 * 3600000);
    await f.send({ type: 'fixture.change', change: { kind: 'quote', offerId: pending.terms.offerId, amount: money(60000) } });
    assert.equal(f.snapshot().cases.find(row => row.id === c.id)!.approval!.status, 'invalidated');
    const revised = f.snapshot().cases.find(row => row.id === c.id)!.offers.find(o => o.id === pending.terms.offerId)!;
    assert.deepEqual(revised.terms!.charge, { kind: 'inspection', fee: money(60000), parts: 'unknown' });
    await assert.rejects(f.home.execute(operator, { id: 'stale-inspection', type: 'case.book', caseId: c.id, approvalId: pending.id }), /approval/i);
    f.restart(); await f.send({ type: 'work.tick' });
    assert.equal(f.snapshot().cases.filter(row => row.urgent).length, 1);
    await approveAndBook(f, f.snapshot().cases.find(row => row.id === c.id)!, 'plumber-local');
    assert.deepEqual(f.snapshot().expenseTotals, spending);
    assert.equal(appliance(f, 'sink').lastService.value, null);
    const booked = f.snapshot().cases.find(row => row.id === c.id)!;
    assert.equal(booked.approval!.terms.charge.kind, 'inspection'); assert.match(booked.reason, /unknown/);
    await f.send({ type: 'case.complete', caseId: c.id, completedAt: '2026-10-21', sourceId: 'inspection-report' });
    assert.equal(appliance(f, 'sink').nextDue.value, null);
    assert.deepEqual(f.snapshot().expenseTotals, spending);
    assert.match(f.snapshot().cases.find(row => row.id === c.id)!.reason, /final repair cost.*unknown/);
  } finally { f.close(); }
});

test('confirmed expense recording, correction and recall survive restart without counting unpaid bookings', async () => {
  const f = fixture();
  try {
    const initial = f.snapshot().expenseTotals[0]!.minor;
    await f.send({ type: 'case.openUrgent', applianceId: 'sink', description: 'Leaking sink' });
    const c = currentCase(f, 'sink'); await approveAndBook(f, c, 'plumber-local');
    assert.equal(f.snapshot().expenseTotals[0]!.minor, initial);
    const charge = { applianceId: 'sink', caseId: c.id, serviceEventId: null, amount: money(50000), chargedOn: '2026-10-21', sourceId: 'paid-inspection-receipt', description: 'Confirmed paid sink inspection fee' };
    const recorded = await f.home.execute(operator, { id: 'record-inspection', type: 'expense.record', charge });
    assert.equal((await f.home.execute(operator, { id: 'record-inspection', type: 'expense.record', charge })).status, 'replayed');
    f.restart();
    const expense = f.snapshot().expenses.find(e => e.id === recorded.affectedIds[0])!;
    assert.equal(expense.amount.minor, 50000); assert.equal(expense.sourceId, 'paid-inspection-receipt');
    assert.equal(f.snapshot().expenseTotals[0]!.minor, initial + 50000);
    await f.send({ type: 'expense.correct', expenseId: expense.id, expectedRevision: 1, replacement: { ...charge, amount: money(45000), sourceId: 'corrected-inspection-receipt' }, reason: 'Provider corrected the paid invoice' });
    f.restart();
    assert.equal(f.snapshot().expenseTotals[0]!.minor, initial + 45000);
    assert.equal(f.snapshot().expenses.filter(e => e.applianceId === 'sink' && e.chargedOn === '2026-10-21').reduce((sum, e) => sum + e.amount.minor, 0), 45000);
    await assert.rejects(f.send({ type: 'expense.correct', expenseId: expense.id, expectedRevision: 1, replacement: null, reason: 'stale correction' }), /revision/i);
    await f.send({ type: 'expense.correct', expenseId: expense.id, expectedRevision: 2, replacement: null, reason: 'Refunded fee' });
    assert.equal(f.snapshot().expenseTotals[0]!.minor, initial);
  } finally { f.close(); }
});
