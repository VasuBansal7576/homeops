import assert from 'node:assert/strict';
import { test } from 'node:test';
import { mkdtemp, stat } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { createLocalJWKSet, exportJWK, generateKeyPair, SignJWT } from 'jose';
import { authorizationURL, createAttempt, discover, DYNAMIC_CLIENT, getCredential, ISSUER, JWKS, loadStore, RESOURCE, saveStore, TOKEN, validateCallback, validateIdentity } from '../apps/agent/src/model/auth.ts';
import type { Credential } from '../apps/agent/src/model/auth.ts';
import { createPlanFetch, preparePlanRequest, requireCompletedStream } from '../apps/agent/src/model/plan-fetch.ts';

test('authorization binds host, PKCE, nonce, exact loopback URI and plan scopes', () => {
  const pending = createAttempt('urn:uuid:01234567-89ab-4cde-8f01-234567890abc', 54321);
  const url = new URL(authorizationURL(pending));
  assert.equal(url.origin + url.pathname, `${ISSUER}/api/accounts/authorize`);
  assert.equal(url.searchParams.get('client_id'), DYNAMIC_CLIENT);
  assert.equal(url.searchParams.get('redirect_uri'), 'http://127.0.0.1:54321/auth/callback');
  assert.equal(url.searchParams.get('code_challenge_method'), 'S256');
  assert.equal(url.searchParams.get('code_challenge')?.length, 43);
  assert.equal(url.searchParams.get('nonce'), pending.nonce);
  assert.equal(url.searchParams.get('ext_agent_host_id'), pending.hostId);
  assert.match(url.searchParams.get('scope')!, /chatgpt.tokens.use.direct/);
  assert.equal(url.searchParams.get('resource'), RESOURCE);
});

test('callback rejects CSRF, denied consent, wrong path, duplicate values and missing issued ID', () => {
  const pending = createAttempt('host', 54321);
  const callback = new URL(pending.redirectURI);
  callback.search = new URLSearchParams({ state: pending.state, code: 'synthetic-code', client_id: 'oaiapp_test' }).toString();
  assert.deepEqual(validateCallback(callback, pending), { code: 'synthetic-code', clientId: 'oaiapp_test' });
  const wrongState = new URL(callback); wrongState.searchParams.set('state', 'bad');
  assert.throws(() => validateCallback(wrongState, pending), /invalid_oauth_state/);
  const wrongPath = new URL(callback); wrongPath.pathname = '/callback';
  assert.throws(() => validateCallback(wrongPath, pending), /invalid_callback_uri/);
  const denied = new URL(callback); denied.searchParams.set('error', 'access_denied');
  assert.throws(() => validateCallback(denied, pending), /oauth_access_denied/);
  const missingId = new URL(callback); missingId.searchParams.delete('client_id');
  assert.throws(() => validateCallback(missingId, pending), /missing_issued_client_id/);
  const duplicate = new URL(callback); duplicate.searchParams.append('state', pending.state);
  assert.throws(() => validateCallback(duplicate, pending), /duplicate_callback_parameter/);
  const returning = { ...pending, clientId: 'oaiapp_original' };
  assert.throws(() => validateCallback(callback, returning), /oauth_client_changed/);
  const noId = new URL(callback); noId.searchParams.delete('client_id');
  assert.equal(validateCallback(noId, returning).clientId, 'oaiapp_original');
});

test('JWT signature, issuer, audience, nonce and selected identity are validated', async () => {
  const { publicKey, privateKey } = await generateKeyPair('RS256');
  const jwk = await exportJWK(publicKey);
  const key = createLocalJWKSet({ keys: [{ ...jwk, kid: 'fixture', alg: 'RS256' }] });
  const token = await new SignJWT({ nonce: 'nonce', email: 'demo@example.com' }).setProtectedHeader({ alg: 'RS256', kid: 'fixture' }).setIssuer(ISSUER).setAudience('oaiapp_test').setSubject('subject').setIssuedAt().setExpirationTime('1m').sign(privateKey);
  assert.deepEqual(await validateIdentity(token, 'oaiapp_test', { nonce: 'nonce', subject: 'subject' }, key), { subject: 'subject', email: 'demo@example.com' });
  await assert.rejects(validateIdentity(token, 'other', {}, key));
  await assert.rejects(validateIdentity(token, 'oaiapp_test', { nonce: 'other' }, key), /invalid_oidc_nonce/);
  await assert.rejects(validateIdentity(token, 'oaiapp_test', { subject: 'other' }, key), /oauth_account_changed/);
  await assert.rejects(validateIdentity(token.slice(0, -10) + 'AAAAAAAAAA', 'oaiapp_test', {}, key));
});

test('auth persistence uses a stable host and owner-only atomic credential file', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'homeops-auth-store-'));
  const path = join(directory, '.local/auth.json');
  const first = await loadStore(path, true);
  const second = await loadStore(path, true);
  assert.equal(second.host_id, first.host_id);
  assert.equal((await stat(path)).mode & 0o777, 0o600);
  assert.match(first.host_id, /^urn:uuid:/);
});

test('request transformation preserves every history item and applies plan restrictions', () => {
  const input = [
    { type: 'message', role: 'system', content: 'HomeOps policy' },
    { role: 'user', content: 'Find AC offers' },
    { type: 'function_call', call_id: 'call-1', name: 'list_offers', arguments: '{}' },
    { type: 'function_call_output', call_id: 'call-1', output: '[]' },
  ];
  const original = { model: 'catalog-model', input, tools: [{ type: 'function', name: 'list_offers', parameters: { type: 'object', properties: {} } }], tool_choice: { type: 'function', name: 'list_offers' }, store: true, stream: false, previous_response_id: 'old', temperature: 0.3, max_output_tokens: 10, metadata: {}, top_p: 1 };
  const prepared = preparePlanRequest(original);
  assert.equal(prepared.stream, true);
  assert.equal(prepared.store, false);
  assert.equal((prepared.input as object[]).length, 4);
  assert.equal((prepared.input as Record<string, unknown>[])[0].role, 'developer');
  assert.equal((prepared.input as Record<string, unknown>[])[2].namespace, 'homeops');
  assert.deepEqual((prepared.input as object[])[3], input[3]);
  assert.equal(input[0].role, 'system');
  for (const field of ['previous_response_id', 'temperature', 'max_output_tokens', 'metadata', 'top_p']) assert.equal(field in prepared, false);
  assert.equal((prepared.tools as Record<string, unknown>[])[0].type, 'namespace');
  assert.equal((prepared.tool_choice as Record<string, unknown>).namespace, 'homeops');
  assert.throws(() => preparePlanRequest({ model: 'm', input: 'string' }), /history_array_required/);
  assert.throws(() => preparePlanRequest({ model: 'm', input: [{ type: 'item_reference', id: 'old' }] }), /full_history_required/);
  assert.throws(() => preparePlanRequest({ model: 'm', input: [], tools: [{ type: 'mcp' }] }), /unsupported_plan_tool/);
});

function sse(events: unknown[]): Response {
  return new Response(events.map(event => `data: ${JSON.stringify(event)}\r\n\r\n`).join(''), { headers: { 'content-type': 'text/event-stream' } });
}

test('stream must reach response.completed and handles usage failures after a text delta', async () => {
  assert.match(await requireCompletedStream(sse([{ type: 'response.completed' }])).text(), /response.completed/);
  await assert.rejects(requireCompletedStream(sse([{ type: 'response.output_text.delta', delta: 'Hello' }])).text(), /stream_ended_without_response_completed/);
  await assert.rejects(requireCompletedStream(sse([{ type: 'response.output_text.delta', delta: 'Hello' }, { type: 'response.failed', response: { error: { code: 'subscription_sharing_usage_limit_exceeded' } } }])).text(), /subscription_sharing_usage_limit_exceeded/);
});

test('fetch adapter replaces credentials only for the public Responses endpoint', async () => {
  let observed: RequestInit | undefined;
  const fetcher: typeof fetch = async (_input, init) => { observed = init; return sse([{ type: 'response.completed' }]); };
  const adapter = createPlanFetch({ fetcher, getAccessToken: async () => 'synthetic-private-token' });
  const result = await adapter(`${RESOURCE}/responses`, { method: 'POST', headers: { Authorization: 'Bearer placeholder' }, body: JSON.stringify({ model: 'catalog-model', input: [] }) });
  await result.text();
  assert.equal(new Headers(observed?.headers).get('authorization'), 'Bearer synthetic-private-token');
  assert.equal(JSON.parse(String(observed?.body)).store, false);
  await assert.rejects(adapter('https://chatgpt.com/backend-api/codex/responses', { method: 'POST' }), /responses_endpoint_only/);
});

test('refresh uses the resource and atomically retains rotated refresh tokens', async () => {
  const directory = await mkdtemp(join(tmpdir(), 'homeops-auth-refresh-'));
  const path = join(directory, 'auth.json');
  const store = await loadStore(path, true);
  const credential: Credential = {
    client_id: 'oaiapp_fixture', host_id: store.host_id, issuer: ISSUER, subject: 'synthetic-subject',
    tokens: { access_token: 'expired-fixture', refresh_token: 'old-refresh', id_token: 'old-id', token_type: 'Bearer' },
    scopes: ['chatgpt.tokens.use.direct', 'resource.invoke'], expires_at: 0, saved_at: new Date().toISOString(),
  };
  await saveStore(path, { ...store, accounts: [credential], active_client_id: credential.client_id });
  let grants = 0;
  const fetcher: typeof fetch = async (input, init) => {
    if (String(input).endsWith('/.well-known/openid-configuration')) return Response.json({ issuer: ISSUER, authorization_endpoint: `${ISSUER}/api/accounts/authorize`, token_endpoint: TOKEN, jwks_uri: JWKS, id_token_signing_alg_values_supported: ['RS256'] });
    assert.equal(String(input), TOKEN);
    const params = new URLSearchParams(String(init?.body));
    assert.equal(params.get('resource'), RESOURCE);
    assert.equal(params.get('grant_type'), 'refresh_token');
    assert.equal(params.get('client_id'), credential.client_id);
    grants++;
    return Response.json({ access_token: 'new-fixture', refresh_token: 'rotated-fixture', token_type: 'Bearer', expires_in: 3600 });
  };
  const [one, two] = await Promise.all([getCredential(path, fetcher), getCredential(path, fetcher)]);
  assert.equal(grants, 1);
  assert.equal(one.tokens.refresh_token, 'rotated-fixture');
  assert.equal(two.tokens.access_token, 'new-fixture');
  assert.equal((await loadStore(path)).accounts[0].tokens.refresh_token, 'rotated-fixture');
});

test('discovery rejects a substituted issuer or token endpoint', async () => {
  const fetcher: typeof fetch = async () => Response.json({ issuer: 'https://other.example', authorization_endpoint: `${ISSUER}/api/accounts/authorize`, token_endpoint: TOKEN, jwks_uri: JWKS, id_token_signing_alg_values_supported: ['RS256'] });
  await assert.rejects(discover(fetcher), /unexpected_oidc_metadata/);
});
