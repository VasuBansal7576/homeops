import assert from 'node:assert/strict';
import test from 'node:test';
import { DEFAULT_AVAILABILITY_PREFERENCES, HouseholdDatasetSchema, PublicCommandSchema, type HouseholdDataset } from '../packages/contracts/src/index.ts';

const personal = (): HouseholdDataset => ({
  format: 'homeops.household', version: 1,
  metadata: { id: 'fresh-family', name: 'Personal household', description: 'Created by its operator', kind: 'personal', provenance: 'User-entered records' },
  providerMode: 'manual', demoNow: null,
  household: { id: 'different-home', name: 'Orchid house', budget: { minor: 420000, currency: 'INR' }, warrantyNoticeDays: 14 },
  schedulingPreferences: DEFAULT_AVAILABILITY_PREFERENCES, notes: [], providers: [],
  appliances: [{ id: 'motor-77', name: 'Water pump', kind: 'other', location: 'Roof', lastService: null, maintenance: { intervalDays: 80, sourceId: 'manual-policy-7' }, warranty: null }],
  expenses: [{ id: 'invoice-88', applianceId: 'motor-77', amount: { minor: 217500, currency: 'INR' }, chargedOn: '2032-02-29', sourceId: 'invoice-photo-88', description: 'Confirmed previous charge' }],
});

test('a distinct household accepts arbitrary IDs, leap dates, generic assets and sourced historical expenses', () => {
  assert.deepEqual(HouseholdDatasetSchema.parse(personal()), personal());
});

test('dataset initialization rejects duplicate IDs and dangling invoice references', () => {
  const duplicate = personal();
  duplicate.appliances.push(duplicate.appliances[0]!);
  assert.equal(HouseholdDatasetSchema.safeParse(duplicate).success, false);
  const dangling = personal();
  dangling.expenses[0]!.applianceId = 'missing';
  assert.equal(HouseholdDatasetSchema.safeParse(dangling).success, false);
});

test('personal datasets cannot silently select a demo clock or simulated providers', () => {
  assert.equal(HouseholdDatasetSchema.safeParse({ ...personal(), demoNow: '2032-02-29T09:00:00+05:30' }).success, false);
  assert.equal(HouseholdDatasetSchema.safeParse({ ...personal(), providerMode: 'simulated' }).success, false);
  const dataset = personal();
  dataset.providers.push({ id: 'plumber-x', name: 'Entered provider', serviceKind: 'other', preferred: true, available: true, contactNote: null, simulation: { declines: false, amount: { minor: 100, currency: 'INR' } } });
  assert.equal(HouseholdDatasetSchema.safeParse(dataset).success, false);
});

test('import rejects workflow fields and unsupported region rather than dropping them', () => {
  assert.equal(HouseholdDatasetSchema.safeParse({ ...personal(), approvals: [] }).success, false);
  const dataset = personal();
  assert.equal(HouseholdDatasetSchema.safeParse({ ...dataset, household: { ...dataset.household, budget: { minor: 100, currency: 'USD' } } }).success, false);
  assert.equal(HouseholdDatasetSchema.safeParse({ ...dataset, schedulingPreferences: { ...dataset.schedulingPreferences, timezone: 'Europe/London' } }).success, false);
});

test('confirmed expenses can cite an appliance and source without a fabricated case', () => {
  assert.equal(PublicCommandSchema.safeParse({ type: 'expense.record', charge: { ...personal().expenses[0], caseId: null, serviceEventId: null } }).success, true);
});
