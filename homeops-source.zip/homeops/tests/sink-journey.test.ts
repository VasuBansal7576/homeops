import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { demoDataset } from '../datasets/catalog.ts';
import { openHomeOps, type HomeCommand } from '../apps/agent/src/homeops/index.ts';
import type { CaseCard, PublicCommand } from '../packages/contracts/src/index.ts';

const operator = { principalId: 'sink-operator', role: 'operator' as const };
const scheduler = { principalId: 'sink-scheduler', role: 'scheduler' as const };
const money = (minor: number) => ({ minor, currency: 'INR' as const });

function fixture() {
  const directory = mkdtempSync(join(tmpdir(), 'homeops-sink-'));
  const filename = join(directory, 'home.sqlite');
  let home = openHomeOps({ filename });
  let serial = 0;
  return {
    get home() { return home; },
    snapshot: () => home.snapshot(operator),
    send: (command: PublicCommand) => home.execute(operator, { ...command, id: `sink:${++serial}` }),
    restart: () => { home.close(); home = openHomeOps({ filename }); },
    close: () => { home.close(); rmSync(directory, { recursive: true, force: true }); },
  };
}
type Fixture = ReturnType<typeof fixture>;
const sinkCase = (f: Fixture): CaseCard => f.snapshot().cases.find(c => c.applianceId === 'sink' && c.purpose === 'urgent')!;
const sink = (f: Fixture) => f.snapshot().appliances.find(a => a.id === 'sink')!;
const sinkTotal = (f: Fixture) => f.snapshot().expenses.filter(e => e.applianceId === 'sink').reduce((sum, e) => sum + e.amount.minor, 0);

async function initialize(f: Fixture) {
  assert.equal(f.snapshot().workspace.status, 'empty');
  await f.send({ type: 'dataset.initialize', dataset: demoDataset });
  await f.send({ type: 'clock.set', now: '2026-10-22T08:00:00+05:30' });
  await f.send({ type: 'case.openUrgent', applianceId: 'sink', description: 'Water is leaking under my kitchen sink. Arrange an inspection.' });
  await f.send({ type: 'case.requestOffers', caseId: sinkCase(f).id });
}

async function select(f: Fixture) {
  const c = sinkCase(f);
  const offer = c.offers.find(o => o.providerId === 'plumber-local')!;
  await f.send({ type: 'case.chooseOffer', caseId: c.id, offerId: offer.id, revision: offer.revision });
  const approval = sinkCase(f).approval!;
  const binding = { approvalId: approval.id, callId: `call:${approval.id}`, sessionId: `session:${approval.id}`, requestId: `request:${approval.id}` };
  f.home.bindApproval(operator, binding);
  return { approval: sinkCase(f).approval!, binding, caseId: c.id };
}

test('sink incident compares preferred decline and over-budget quote before exact INR 500 inspection approval', async () => {
  const f = fixture();
  try {
    await initialize(f);
    assert.equal(sink(f).lastService.value, '2025-12-09');
    assert.equal(sinkTotal(f), 75000);
    assert.equal(sink(f).nextDue.value, null);
    const c = sinkCase(f);
    assert.equal(c.urgent, true);
    assert.equal(c.offers.length, 3);
    assert.equal(c.offers.find(o => o.providerId === 'plumber-preferred')!.status, 'declined');
    const preferred = f.snapshot().providers.find(p => p.id === 'plumber-preferred')!;
    assert.equal(preferred.preferred, true);
    assert.deepEqual(preferred.record.simulation!.amount, money(40000));
    const premium = c.offers.find(o => o.providerId === 'plumber-premium')!;
    assert.equal(premium.withinBudget, false);
    assert.deepEqual(premium.terms!.charge, { kind: 'inspection', fee: money(300000), parts: 'unknown' });
    await assert.rejects(f.send({ type: 'case.chooseOffer', caseId: c.id, offerId: premium.id, revision: premium.revision }), /budget/i);
    const { approval, caseId } = await select(f);
    assert.deepEqual(approval.terms.charge, { kind: 'inspection', fee: money(50000), parts: 'unknown' });
    const lead = Date.parse(approval.terms.slot.start) - Date.parse('2026-10-22T08:00:00+05:30');
    assert.ok(lead >= 2 * 3600000 && lead < 3 * 3600000);
    assert.equal(Date.parse(approval.terms.slot.end) - Date.parse(approval.terms.slot.start), 3600000);
    assert.equal(c.offers.every(o => o.simulated), true);
    await assert.rejects(f.home.execute(operator, { id: 'without-consent', type: 'case.book', caseId, approvalId: approval.id }), /approval/i);
    f.restart();
    assert.deepEqual(sinkCase(f).approval, approval);
    assert.equal(sinkCase(f).booking, null);
    assert.equal(sinkTotal(f), 75000);
  } finally { f.close(); }
});

test('changed inspection fee invalidates old consent and rejection survives replay and restart', async () => {
  const f = fixture();
  try {
    await initialize(f);
    const old = await select(f);
    await f.send({ type: 'fixture.change', change: { kind: 'quote', offerId: old.approval.terms.offerId, amount: money(60000) } });
    await assert.rejects(f.home.settleApproval(operator, { ...old.binding, id: 'stale-consent', responderId: operator.principalId, decision: 'approve' }), /stale/i);
    await assert.rejects(f.home.execute(operator, { id: 'stale-book', type: 'case.book', caseId: old.caseId, approvalId: old.approval.id }), /approval/i);
    const current = await select(f);
    assert.notEqual(current.approval.id, old.approval.id);
    assert.deepEqual(current.approval.terms.charge, { kind: 'inspection', fee: money(60000), parts: 'unknown' });
    await f.home.settleApproval(operator, { ...old.binding, id: 'dismiss-old', responderId: operator.principalId, decision: 'deny' });
    assert.equal(sinkCase(f).approval!.status, 'pending');
    const denial = { ...current.binding, id: 'reject-current', responderId: operator.principalId, decision: 'deny' as const };
    await f.home.settleApproval(operator, denial);
    assert.equal((await f.home.settleApproval(operator, denial)).status, 'replayed');
    f.restart();
    assert.equal(sinkCase(f).state, 'denied');
    assert.equal(sinkCase(f).booking, null);
    await assert.rejects(f.home.execute(operator, { id: 'rejected-book', type: 'case.book', caseId: current.caseId, approvalId: current.approval.id }), /approval/i);
    assert.equal(sinkTotal(f), 75000);
  } finally { f.close(); }
});

test('sink inspection approval books once, follows up, and keeps appointment confirmation, completion and invoice distinct across restart', async () => {
  const f = fixture();
  try {
    await initialize(f);
    const { approval, binding, caseId } = await select(f);
    const spending = f.snapshot().expenseTotals;
    const service = sink(f).lastService;
    const consent = { ...binding, id: 'approved-inspection', responderId: operator.principalId, decision: 'approve' as const };
    await f.home.settleApproval(operator, consent);
    assert.equal((await f.home.settleApproval(operator, consent)).status, 'replayed');
    const booking: HomeCommand = { id: 'book-inspection', type: 'case.book', caseId, approvalId: approval.id };
    await f.home.execute(operator, booking);
    const receipt = sinkCase(f).booking!;
    assert.equal((await f.home.execute(operator, booking)).status, 'replayed');
    f.restart();
    await f.home.execute(operator, { ...booking, id: 'book-inspection-retry' });
    assert.deepEqual(sinkCase(f).booking, receipt);
    assert.equal(f.snapshot().activity.filter(e => e.caseId === caseId && e.kind === 'booking.recorded').length, 1);
    assert.deepEqual(sink(f).lastService, service);
    assert.deepEqual(f.snapshot().expenseTotals, spending);
    await f.send({ type: 'clock.set', now: '2026-10-22T11:01:00+05:30' });
    const followup = f.home.pendingJobs(scheduler).find(j => j.caseId === caseId && j.kind === 'confirmation');
    assert.ok(followup);
    f.restart();
    assert.equal(f.home.pendingJobs(scheduler).filter(j => j.caseId === caseId && j.kind === 'confirmation').length, 1);
    await f.send({ type: 'case.confirmAppointment', caseId, confirmed: true });
    assert.equal(sinkCase(f).state, 'awaiting_completion');
    assert.deepEqual(sink(f).lastService, service);
    assert.deepEqual(f.snapshot().expenseTotals, spending);
    const completion = await f.send({ type: 'case.complete', caseId, completedAt: '2026-10-22', sourceId: 'operator:inspection-completed' });
    assert.equal(sinkCase(f).state, 'completed');
    assert.match(sinkCase(f).title, /inspection/i);
    assert.match(sinkCase(f).reason, /final repair cost.*unknown/i);
    assert.equal(sink(f).nextDue.value, null);
    assert.deepEqual(f.snapshot().expenseTotals, spending);
    const charge = { applianceId: 'sink', caseId, serviceEventId: completion.affectedIds[1]!, amount: money(50000), chargedOn: '2026-10-22', sourceId: 'invoice:sink-inspection-paid', description: 'Operator confirmed paid inspection only. Repair remains unconfirmed.' };
    const expenseCommand: HomeCommand = { id: 'record-paid-inspection', type: 'expense.record', charge };
    await f.home.execute(operator, expenseCommand);
    assert.equal((await f.home.execute(operator, expenseCommand)).status, 'replayed');
    f.restart();
    assert.equal((await f.home.execute(operator, expenseCommand)).status, 'replayed');
    assert.equal(sinkTotal(f), 125000);
    assert.equal(f.snapshot().expenseTotals[0]!.minor, 760000);
    const paid = f.snapshot().expenses.find(e => e.sourceId === charge.sourceId)!;
    assert.equal(paid.amount.minor, 50000);
    assert.equal(paid.serviceEventId, completion.affectedIds[1]);
    assert.equal(sink(f).lastService.value, '2026-10-22');
    assert.equal(sinkCase(f).approval!.terms.charge.kind, 'inspection');
    assert.equal(sinkCase(f).booking!.receiptId, receipt.receiptId);
    assert.equal(f.home.pendingJobs(scheduler).some(j => j.caseId === caseId && j.kind === 'confirmation'), false);
  } finally { f.close(); }
});
