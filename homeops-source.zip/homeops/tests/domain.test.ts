import { demoDataset } from '../datasets/catalog.ts';
import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { openHomeOps, MemoryDocumentConflictError } from '../apps/agent/src/homeops/index.ts';

const operator = { principalId: 'demo-operator', role: 'operator' as const };
const scheduler = { principalId: 'schedule', role: 'scheduler' as const };
const filename = () => join(mkdtempSync(join(tmpdir(), 'homeops-test-')), 'home.sqlite');
const due = async (home: ReturnType<typeof openHomeOps>) => {
  await home.execute(operator, { id: 'advance', type: 'clock.set', now: '2026-10-22T09:00:00+05:30' });
  return home.snapshot(operator).cases.find(c => c.applianceId === 'ac')!;
};
const select = async (home: ReturnType<typeof openHomeOps>) => {
  const c = await due(home);
  await home.execute(operator, { id: 'offers', type: 'case.requestOffers', caseId: c.id });
  const offer = home.snapshot(operator).cases[0]!.offers.find(o => o.providerId === 'coolcare')!;
  await home.execute(operator, { id: 'choose', type: 'case.chooseOffer', caseId: c.id, offerId: offer.id, revision: offer.revision });
  const approval = home.snapshot(operator).cases[0]!.approval!;
  home.bindApproval(operator, { approvalId: approval.id, callId: 'call-1', sessionId: 'session-1' });
  return { caseId: c.id, approvalId: approval.id, offerId: offer.id };
};
test('due inbox persists and provider comparisons preserve decline and budget', async () => {
  const file = filename(); let home = openHomeOps({ initialDataset: demoDataset, filename: file });
  assert.equal(home.snapshot(operator).cases.length, 0);
  const c = await due(home);
  await home.execute(operator, { id: 'offers', type: 'case.requestOffers', caseId: c.id });
  const offers = home.snapshot(operator).cases[0]!.offers;
  assert.equal(offers.find(o => o.providerId === 'preferred')!.status, 'declined');
  assert.equal(offers.find(o => o.providerId === 'premium')!.withinBudget, false);
  assert.equal(offers.find(o => o.providerId === 'coolcare')!.withinBudget, true);
  await assert.rejects(home.execute(operator, { id: 'too-high', type: 'case.chooseOffer', caseId: c.id, offerId: offers.find(o => o.providerId === 'premium')!.id, revision: 1 }), /budget/i);
  home.close(); home = openHomeOps({ initialDataset: demoDataset, filename: file });
  assert.equal(home.snapshot(operator).inbox.length, 1);
  assert.equal(home.pendingJobs(scheduler).length, 1);
  const job = home.pendingJobs(scheduler)[0]!;
  assert.ok(home.claimJob(scheduler, { jobId: job.id, owner: 'worker', leaseMs: 1000 }));
  assert.equal(home.claimJob(scheduler, { jobId: job.id, owner: 'other' }), null);
  home.bindJobSession(scheduler, { jobId: job.id, owner: 'worker', sessionId: 'session-due' });
  assert.equal(home.snapshot(operator).inbox[0]!.sessionId, 'session-due');
  home.close();
});
test('changed terms invalidate exact approval and cannot book', async () => {
  const home = openHomeOps({ initialDataset: demoDataset, filename: filename() }); const ids = await select(home);
  await home.execute(operator, { id: 'quote', type: 'fixture.change', change: { kind: 'quote', offerId: ids.offerId, amount: { minor: 190000, currency: 'INR' } } });
  await assert.rejects(home.settleApproval(operator, { id: 'approve', approvalId: ids.approvalId, requestId: 'request-1', callId: 'call-1', sessionId: 'session-1', responderId: operator.principalId, decision: 'approve' }), /stale/i);
  await assert.rejects(home.execute(operator, { id: 'book', type: 'case.book', ...ids }), /approval|stale/i);
  assert.equal(home.snapshot(operator).cases[0]!.booking, null); home.close();
});
test('denial survives restart and prevents booking; public JSON cannot settle', async () => {
  const file = filename(); let home = openHomeOps({ initialDataset: demoDataset, filename: file }); const ids = await select(home);
  await assert.rejects(home.execute(operator, { id: 'forged', type: 'approval.settle', approvalId: ids.approvalId } as never), /private|unsupported/i);
  await home.settleApproval(operator, { id: 'deny', approvalId: ids.approvalId, requestId: 'request-1', callId: 'call-1', sessionId: 'session-1', responderId: operator.principalId, decision: 'deny' });
  home.close(); home = openHomeOps({ initialDataset: demoDataset, filename: file });
  assert.equal(home.snapshot(operator).cases[0]!.state, 'denied');
  await assert.rejects(home.execute(operator, { id: 'book', type: 'case.book', ...ids }), /approval/i);
  assert.equal(home.snapshot(operator).cases[0]!.booking, null); home.close();
});
test('provider acceptance before receipt survives crash and retries converge', async () => {
  const file = filename(); let fail = true;
  let home = openHomeOps({ initialDataset: demoDataset, filename: file, faultAfterProviderAcceptance: () => { if (fail) { fail = false; throw new Error('simulated receipt crash'); } } });
  const ids = await select(home);
  await home.settleApproval(operator, { id: 'approve', approvalId: ids.approvalId, requestId: 'request-1', callId: 'call-1', sessionId: 'session-1', responderId: operator.principalId, decision: 'approve' });
  await assert.rejects(home.execute(operator, { id: 'book', type: 'case.book', ...ids }), /receipt crash/);
  home.close(); home = openHomeOps({ initialDataset: demoDataset, filename: file });
  await home.execute(operator, { id: 'after-expiry', type: 'clock.set', now: '2026-10-24T09:00:00+05:30' });
  const before = home.snapshot(operator);
  await home.execute(operator, { id: 'book', type: 'case.book', ...ids });
  await home.execute(operator, { id: 'book-again', type: 'case.book', ...ids });
  const after = home.snapshot(operator); const booking = after.cases[0]!.booking!;
  assert.ok(booking.receiptId); assert.equal(booking.operationId, `provider:${ids.approvalId}`);
  assert.equal(after.cases[0]!.approval!.status, 'consumed');
  const inspection = new DatabaseSync(file, { readOnly: true });
  assert.equal(inspection.prepare('SELECT count(*) AS count FROM provider_operations').get()!.count, 1);
  assert.equal(inspection.prepare('SELECT count(*) AS count FROM bookings').get()!.count, 1);
  inspection.close();
  assert.deepEqual(after.expenses, before.expenses);
  assert.deepEqual(after.appliances.find(a => a.id === 'ac')!.lastService, before.appliances.find(a => a.id === 'ac')!.lastService);
  await home.execute(operator, { id: 'service-day', type: 'clock.set', now: '2026-10-23T11:00:00+05:30' });
  await home.execute(operator, { id: 'complete', type: 'case.complete', caseId: ids.caseId, completedAt: '2026-10-23', sourceId: 'technician-confirmed' });
  assert.equal(home.snapshot(operator).appliances.find(a => a.id === 'ac')!.lastService.value, '2026-10-23');
  assert.equal(home.snapshot(operator).appliances.find(a => a.id === 'ac')!.nextDue.value, '2027-04-21');
  home.close();
});
test('approval bridge rejects other identities and preserves call versus request identifiers', async () => {
  const home = openHomeOps({ initialDataset: demoDataset, filename: filename() }); const ids = await select(home);
  assert.equal(home.snapshot(operator).cases[0]!.approval!.requestId, null);
  const response = { id: 'identity', approvalId: ids.approvalId, requestId: 'actual-eve-request', callId: 'call-1', sessionId: 'session-1', responderId: operator.principalId, decision: 'approve' as const };
  await assert.rejects(home.settleApproval(operator, { ...response, callId: 'actual-eve-request' }), /identity/i);
  await assert.rejects(home.settleApproval(operator, { ...response, sessionId: 'other-session' }), /identity/i);
  await assert.rejects(home.settleApproval(operator, { ...response, responderId: 'other-operator' }), /identity/i);
  await home.settleApproval(operator, response);
  assert.equal(home.snapshot(operator).cases[0]!.approval!.requestId, 'actual-eve-request');
  await assert.rejects(home.execute({ principalId: 'other-operator', role: 'operator' }, { id: 'other-book', type: 'case.book', ...ids }), /approval/i);
  await home.execute(operator, { id: 'authorized-book', type: 'case.book', ...ids });
  home.close();
});
test('pending approval bindings survive same-version restart and appointment changes reject old consent', async () => {
  const file = filename(); let home = openHomeOps({ initialDataset: demoDataset, filename: file }); const ids = await select(home);
  await home.execute(operator, { id: 'preference', type: 'preference.save', text: 'Please keep the terrace door closed.' });
  const pending = home.snapshot(operator).cases[0]!.approval!;
  home.close(); home = openHomeOps({ initialDataset: demoDataset, filename: file });
  assert.deepEqual(home.snapshot(operator).cases[0]!.approval, pending);
  assert.ok(home.snapshot(operator).preferences.includes('Please keep the terrace door closed.'));
  const offer = home.snapshot(operator).cases[0]!.offers.find(o => o.id === ids.offerId)!;
  await home.execute(operator, { id: 'move-appointment', type: 'fixture.change', change: { kind: 'quote', offerId: ids.offerId, amount: offer.terms!.charge.kind === 'fixed' ? offer.terms!.charge.total : offer.terms!.charge.fee, start: '2026-10-23T11:00:00+05:30' } });
  await assert.rejects(home.settleApproval(operator, { id: 'stale-appointment', approvalId: ids.approvalId, requestId: 'request-1', callId: 'call-1', sessionId: 'session-1', responderId: operator.principalId, decision: 'approve' }), /stale/i);
  await assert.rejects(home.execute(operator, { id: 'stale-choose', type: 'case.chooseOffer', caseId: ids.caseId, offerId: ids.offerId, revision: 1 }), /revision|stale/i);
  home.close();
});
test('Eve policy rechecks preserve settled authority only for the original call and session', async () => {
  const file = filename(); let home = openHomeOps({ initialDataset: demoDataset, filename: file }); const ids = await select(home);
  await home.settleApproval(operator, { id: 'consent', approvalId: ids.approvalId, requestId: 'request-1', callId: 'call-1', sessionId: 'session-1', responderId: operator.principalId, decision: 'approve' });
  home.close(); home = openHomeOps({ initialDataset: demoDataset, filename: file });
  const binding = { approvalId: ids.approvalId, callId: 'call-1', sessionId: 'session-1' };
  home.bindApproval(operator, binding);
  assert.throws(() => home.bindApproval(operator, { ...binding, callId: 'call-2' }), /another Eve request/);
  assert.throws(() => home.bindApproval(operator, { ...binding, sessionId: 'session-2' }), /another Eve request/);
  await home.execute(operator, { id: 'book', type: 'case.book', ...ids });
  home.bindApproval(operator, binding);
  assert.equal(home.snapshot(operator).cases[0]!.approval!.status, 'consumed');
  home.close();
});
test('reviewing the same current quote preserves its durable approval binding', async () => {
  const home = openHomeOps({ initialDataset: demoDataset, filename: filename() }); const ids = await select(home);
  const before = home.snapshot(operator).cases[0]!.approval!;
  const result = await home.execute(operator, { id: 'review-again', type: 'case.chooseOffer', caseId: ids.caseId, offerId: ids.offerId, revision: 1 });
  assert.ok(result.affectedIds.includes(ids.approvalId));
  assert.deepEqual(home.snapshot(operator).cases[0]!.approval, before);
  home.bindApproval(operator, { approvalId: ids.approvalId, callId: 'call-1', sessionId: 'session-1' });
  home.close();
});
test('only the bound operator can dismiss stale consent without affecting a newer approval', async () => {
  const file = filename(); let home = openHomeOps({ initialDataset: demoDataset, filename: file }); const ids = await select(home);
  home.bindApproval(operator, { approvalId: ids.approvalId, callId: 'call-1', sessionId: 'session-1', requestId: 'request-1' });
  await home.execute(operator, { id: 'new-price', type: 'fixture.change', change: { kind: 'quote', offerId: ids.offerId, amount: { minor: 190000, currency: 'INR' } } });
  await home.execute(operator, { id: 'new-selection', type: 'case.chooseOffer', caseId: ids.caseId, offerId: ids.offerId, revision: 2 });
  const newer = home.snapshot(operator).cases[0]!.approval!;
  const response = { id: 'dismiss', approvalId: ids.approvalId, decision: 'deny' as const, responderId: operator.principalId, requestId: 'request-1', callId: 'call-1', sessionId: 'session-1' };
  for (const wrong of [{ responderId: 'other' }, { requestId: 'other' }, { callId: 'other' }, { sessionId: 'other' }]) await assert.rejects(home.settleApproval(operator, { ...response, ...wrong }), /identity/i);
  await assert.rejects(home.settleApproval({ principalId: 'other', role: 'operator' }, response), /identity/i);
  await assert.rejects(home.settleApproval(operator, { ...response, decision: 'approve' }), /Terms changed/);
  assert.equal((await home.settleApproval(operator, response)).status, 'applied');
  home.close(); home = openHomeOps({ initialDataset: demoDataset, filename: file });
  assert.equal((await home.settleApproval(operator, response)).status, 'replayed');
  assert.deepEqual(home.snapshot(operator).cases[0]!.approval, newer);
  assert.equal(home.snapshot(operator).cases[0]!.booking, null);
  assert.equal(home.snapshot(operator).activity.filter(e => e.kind === 'approval.dismissed').length, 1);
  home.close();
});
test('changed budgets and provider availability invalidate prior consent and select from current terms', async () => {
  for (const change of [
    { kind: 'budget' as const, amount: { minor: 170000, currency: 'INR' as const } },
    { kind: 'provider' as const, providerId: 'coolcare', available: false },
  ]) {
    const home = openHomeOps({ initialDataset: demoDataset, filename: filename() }); const ids = await select(home);
    await home.settleApproval(operator, { id: 'approve', approvalId: ids.approvalId, requestId: 'request-1', callId: 'call-1', sessionId: 'session-1', responderId: operator.principalId, decision: 'approve' });
    await home.execute(operator, { id: 'change', type: 'fixture.change', change: change.kind === 'budget' ? { ...change, caseId: ids.caseId } : change });
    assert.equal(home.snapshot(operator).cases[0]!.approval!.status, 'invalidated');
    await assert.rejects(home.execute(operator, { id: 'book', type: 'case.book', ...ids }), /approval/i);
    await home.execute(operator, { id: 'fresh-offers', type: 'case.requestOffers', caseId: ids.caseId });
    assert.equal(home.snapshot(operator).cases[0]!.state, 'unavailable');
    home.close();
  }
});
test('memory and confirmed expense corrections persist and detect conflicts', async () => {
  const file = filename(); let home = openHomeOps({ initialDataset: demoDataset, filename: file });
  const document = home.putMemoryDocument('preferences', 'Prefer afternoon visits.', null);
  assert.equal(document.version, 1);
  assert.throws(() => home.putMemoryDocument('preferences', 'overwrite', null), MemoryDocumentConflictError);
  const expense = home.snapshot(operator).expenses[0]!; const before = home.snapshot(operator).expenseTotals[0]!.minor;
  await home.execute(operator, { id: 'expense-correction', type: 'expense.correct', expenseId: expense.id, expectedRevision: expense.revision, replacement: { applianceId: expense.applianceId, caseId: expense.caseId, serviceEventId: expense.serviceEventId, amount: { minor: 100000, currency: 'INR' }, chargedOn: expense.chargedOn, sourceId: 'corrected-receipt', description: 'Corrected confirmed charge' }, reason: 'Invoice correction' });
  assert.equal(home.snapshot(operator).expenseTotals[0]!.minor, before - expense.amount.minor + 100000);
  await assert.rejects(home.execute(operator, { id: 'expense-stale', type: 'expense.correct', expenseId: expense.id, expectedRevision: expense.revision, replacement: null, reason: 'stale' }), /revision/i);
  home.close(); home = openHomeOps({ initialDataset: demoDataset, filename: file });
  assert.deepEqual(home.getMemoryDocument('preferences'), document);
  assert.ok(home.snapshot(operator).preferences.includes('Prefer afternoon visits.'));
  await home.execute(operator, { id: 'void-charge', type: 'expense.correct', expenseId: expense.id, expectedRevision: 2, replacement: null, reason: 'Duplicate charge voided' });
  assert.equal(home.snapshot(operator).expenseTotals[0]!.minor, before - expense.amount.minor);
  home.close();
});
test('moving before due supersedes work, returning to due creates a fresh persistent job', async () => {
  const home = openHomeOps({ initialDataset: demoDataset, filename: filename() }); const original = await due(home);
  await home.execute(operator, { id: 'before-due', type: 'clock.set', now: '2026-10-21T09:00:00+05:30' });
  assert.equal(home.snapshot(operator).cases[0]!.state, 'cancelled');
  assert.equal(home.pendingJobs(scheduler).length, 0);
  await home.execute(operator, { id: 'due-again', type: 'clock.set', now: '2026-10-22T09:00:00+05:30' });
  const fresh = home.snapshot(operator).cases.find(c => c.state === 'due')!;
  assert.ok(fresh); assert.notEqual(fresh.id, original.id);
  assert.equal(home.pendingJobs(scheduler).length, 1);
  home.close();
});
test('source dates and policies recalculate due work and command IDs bind payload and actor', async () => {
  const home = openHomeOps({ initialDataset: demoDataset, filename: filename() });
  await home.execute(operator, { id: 'unknown', type: 'fixture.change', change: { kind: 'serviceDate', applianceId: 'ac', performedOn: null } });
  await due(home); assert.equal(home.snapshot(operator).cases.length, 0);
  assert.equal(home.snapshot(operator).appliances.find(a => a.id === 'ac')!.nextDue.value, null);
  await home.execute(operator, { id: 'source', type: 'fixture.change', change: { kind: 'serviceDate', applianceId: 'ac', performedOn: '2026-10-01' } });
  await home.execute(operator, { id: 'policy', type: 'fixture.change', change: { kind: 'policy', applianceId: 'ac', intervalDays: 21 } });
  assert.equal(home.snapshot(operator).cases.length, 1);
  assert.equal((await home.execute(operator, { id: 'policy', type: 'fixture.change', change: { kind: 'policy', applianceId: 'ac', intervalDays: 21 } })).status, 'replayed');
  await assert.rejects(home.execute(operator, { id: 'policy', type: 'work.tick' }), /reused/i);
  await assert.rejects(home.execute(scheduler, { id: 'wrong-role', type: 'clock.set', now: '2026-10-22T09:00:00Z' }), /unauthorized/i);
  home.close();
});
