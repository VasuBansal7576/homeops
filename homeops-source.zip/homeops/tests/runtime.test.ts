import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createCodexRuntimeModel } from '../apps/agent/src/model/codex-runtime.ts';
import { disabledFeatures, type PlannerTransport, type Notification } from '../apps/agent/src/model/codex-rpc.ts';
import type { LanguageModelV3CallOptions } from '@ai-sdk/provider';

class FakeTransport implements PlannerTransport {
  failure = new Promise<never>(() => {});
  handler: (message: Notification) => void = () => {};
  closed = false;
  calls: { method: string; params: any }[] = [];
  constructor(readonly action = { kind: 'answer', text: 'Confirmed fixture 47.', toolName: '', argumentsJson: '' }, readonly behavior = 'complete') {}
  onNotification(handler: (message: Notification) => void) { this.handler = handler; }
  notify() {}
  async close() { this.closed = true; }
  async rpc(method: string, params?: any) {
    this.calls.push({ method, params });
    if (method === 'account/read') return { account: { type: 'chatgpt' } };
    if (method === 'model/list') return { data: [{ model: 'fixture-model', isDefault: true }] };
    if (method === 'config/read') return { config: { features: { ...Object.fromEntries(disabledFeatures.map(name => [name, false])), skip_host_skill_discovery: true }, web_search: 'disabled', mcp_servers: { fixture: { url: 'ignored' } }, plugins: { 'fixture@local': { enabled: true } } } };
    if (method === 'thread/start') return { thread: { id: 'fixture-thread' } };
    if (method === 'turn/start') {
      if (this.behavior === 'rpc-error') throw new Error('RPC failed');
      if (this.behavior === 'pending') return {};
      queueMicrotask(() => {
        if (this.behavior === 'tool-item') this.handler({ method: 'item/started', params: { threadId: 'fixture-thread', item: { type: 'commandExecution' } } });
        else this.handler({ method: 'item/completed', params: { threadId: 'fixture-thread', item: { type: 'agentMessage', text: JSON.stringify(this.action) } } });
        this.handler({ method: 'turn/completed', params: { threadId: 'fixture-thread', turn: { id: 'fixture-turn', status: this.behavior === 'failed' ? 'failed' : 'completed' } } });
      });
    }
    return {};
  }
}
const rejects = (value: PromiseLike<unknown>, error?: RegExp) => error ? assert.rejects(Promise.resolve(value), error) : assert.rejects(Promise.resolve(value));
const options: LanguageModelV3CallOptions = {
  prompt: [
    { role: 'system', content: 'Household system instruction.' },
    { role: 'user', content: [{ type: 'text', text: 'Read the fixture clock.' }] },
    { role: 'assistant', content: [{ type: 'tool-call', toolCallId: 'call-1', toolName: 'get_fixture_clock', input: {} }] },
    { role: 'tool', content: [{ type: 'tool-result', toolCallId: 'call-1', toolName: 'get_fixture_clock', output: { type: 'json', value: { fixture: 47 } } }] },
  ],
  tools: [{ type: 'function', name: 'get_fixture_clock', description: 'Read fixture.', inputSchema: { type: 'object', properties: {}, additionalProperties: false } }],
};
function setup(fake: FakeTransport, timeoutMs = 1000) { return createCodexRuntimeModel({ transportFactory: () => fake, timeoutMs }); }
test('preserves complete history and disables configured MCP and plugins', async () => {
  const fake = new FakeTransport();
  const result = await setup(fake).doGenerate(options);
  assert.equal(result.finishReason.unified, 'stop');
  assert.equal(fake.closed, true);
  const thread = fake.calls.find(call => call.method === 'thread/start')!.params;
  assert.deepEqual(thread.config, { web_search: 'disabled', 'mcp_servers.fixture.enabled': false, 'plugins.fixture@local.enabled': false });
  assert.equal(thread.ephemeral, true);
  assert.equal(thread.sandbox, 'read-only');
  const turn = fake.calls.find(call => call.method === 'turn/start')!.params;
  const supplied = JSON.parse(turn.input[0].text);
  assert.deepEqual(supplied.history, options.prompt);
  assert.deepEqual(supplied.tools, options.tools);
});
test('returns ordinary tool calls and buffered stream events', async () => {
  const fake = new FakeTransport({ kind: 'tool', text: '', toolName: 'get_fixture_clock', argumentsJson: '{}' });
  const result = await setup(fake).doStream(options);
  const events = [];
  for await (const event of result.stream) events.push(event);
  assert.equal(events[0].type, 'stream-start');
  assert.ok(events.some(event => event.type === 'tool-call' && event.toolName === 'get_fixture_clock' && event.input === '{}'));
  assert.equal(events.at(-1)?.type, 'finish');
  assert.equal(fake.closed, true);
});
test('rejects unknown tools, malformed arguments, and tool choice violations', async () => {
  for (const action of [
    { kind: 'tool', text: '', toolName: 'shell', argumentsJson: '{}' },
    { kind: 'tool', text: '', toolName: 'get_fixture_clock', argumentsJson: '[]' },
    { kind: 'tool', text: '', toolName: 'get_fixture_clock', argumentsJson: '{bad' },
    { kind: 'tool', text: '', toolName: 'get_fixture_clock', argumentsJson: '{"unexpected":true}' },
  ]) {
    const fake = new FakeTransport(action);
    await rejects(setup(fake).doGenerate(options));
    assert.equal(fake.closed, true);
  }
  await rejects(setup(new FakeTransport()).doGenerate({ ...options, toolChoice: { type: 'required' } }));
  await rejects(setup(new FakeTransport({ kind: 'tool', text: '', toolName: 'get_fixture_clock', argumentsJson: '{}' })).doGenerate({ ...options, toolChoice: { type: 'none' } }));
});
test('rejects runtime tools, failed turns and RPC errors', async () => {
  for (const behavior of ['tool-item', 'failed', 'rpc-error']) {
    const fake = new FakeTransport(undefined, behavior);
    await rejects(setup(fake).doGenerate(options));
    assert.equal(fake.closed, true);
  }
});
test('abort and timeout always close the isolated transport', async () => {
  const fake = new FakeTransport(undefined, 'pending');
  const signal = new AbortController();
  const result = setup(fake).doGenerate({ ...options, abortSignal: signal.signal });
  setTimeout(() => signal.abort(), 20);
  await rejects(result);
  assert.equal(fake.closed, true);
  const timed = new FakeTransport(undefined, 'pending');
  await rejects(setup(timed, 20).doGenerate(options), /timed out/);
  assert.equal(timed.closed, true);
});
test('rejects unsupported media and provider tools before starting transport', async () => {
  let started = false;
  const model = createCodexRuntimeModel({ transportFactory: () => { started = true; return new FakeTransport(); } });
  await rejects(model.doGenerate({ prompt: [{ role: 'user', content: [{ type: 'file', mediaType: 'image/png', data: new Uint8Array() }] }] }));
  await rejects(model.doGenerate({ prompt: [], tools: [{ type: 'provider', id: 'provider.tool', name: 'remote', args: {} }] }));
  assert.equal(started, false);
});
