import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { openHomeOps, type HomeOps, type HomeCommand } from '../apps/agent/src/homeops/index.ts';
import { HouseholdDatasetSchema, type HouseholdDataset, type PublicCommand, type CaseCard } from '../packages/contracts/src/index.ts';
import { datasetCatalog, demoDataset } from '../datasets/catalog.ts';
import { generateDatasets } from '../datasets/generate.ts';

const actor = { principalId: 'portable-owner', role: 'operator' as const };
const money = (minor: number) => ({ minor, currency: 'INR' as const });
function fixture(dataset?: HouseholdDataset) {
  const filename = join(mkdtempSync(join(tmpdir(), 'homeops-portable-')), 'home.sqlite');
  let home = openHomeOps({ filename, initialDataset: dataset }); let serial = 0;
  return { filename, get home() { return home; }, snapshot: () => home.snapshot(actor), send: (command: PublicCommand | { type: 'work.tick' }) => home.execute(actor, { ...command, id: `portable:${++serial}` } as HomeCommand), restart: (initialDataset?: HouseholdDataset) => { home.close(); home = openHomeOps({ filename, initialDataset }); }, close: () => home.close() };
}
function personal(): HouseholdDataset {
  return { ...structuredClone(demoDataset), metadata: { id: 'my-home', name: 'My actual household', description: '', kind: 'personal', provenance: 'Entered by owner' }, providerMode: 'manual', demoNow: null, household: { id: 'house-88', name: 'House 88', budget: money(440000), warrantyNoticeDays: 21 }, appliances: [{ id: 'vent-77', name: 'Ventilation', kind: 'other', location: 'Attic', lastService: { performedOn: '2020-01-01', sourceId: 'invoice:2020' }, maintenance: { intervalDays: 365, sourceId: 'owner-policy' }, warranty: { ends: '2020-02-01', sourceId: 'warranty:actual', terms: 'Parts only. Specific coverage unverified.' } }], providers: [{ id: 'provider-77', name: 'Entered Technician', serviceKind: 'other', preferred: true, available: true, contactNote: 'Owner telephone directory', simulation: null }], expenses: [{ id: 'invoice-old', applianceId: 'vent-77', amount: money(31000), chargedOn: '2020-01-01', sourceId: 'actual-invoice', description: 'Confirmed historical service charge' }], schedulingPreferences: { daysOfWeek: [1, 2, 3, 4, 5, 6, 7], startTime: '00:00', endTime: '23:59', timezone: 'Asia/Kolkata' }, notes: [] };
}
const active = (f: ReturnType<typeof fixture>) => f.snapshot().cases.find(c => c.applianceId === 'vent-77' && !c.title.includes('warranty') && !['completed', 'cancelled'].includes(c.state))!;
async function quote(f: ReturnType<typeof fixture>, c: CaseCard, minor = 73000) {
  const clock = Date.parse(f.snapshot().clock.effectiveNow);
  const local = new Date(clock + 19800000 + 2 * 86400000).toISOString().slice(0, 10);
  await f.send({ type: 'case.recordQuote', caseId: c.id, providerId: 'provider-77', slot: { start: `${local}T10:00:00+05:30`, end: `${local}T11:00:00+05:30` }, expiresAt: new Date(clock + 86400000).toISOString(), sourceId: `quote:phone:${minor}`, charge: { kind: 'fixed', total: money(minor) } });
  return active(f).offers.find(o => o.providerId === 'provider-77')!;
}
async function select(f: ReturnType<typeof fixture>) {
  const c = active(f); const offer = await quote(f, c);
  await f.send({ type: 'case.chooseOffer', caseId: c.id, offerId: offer.id, revision: offer.revision });
  const approval = active(f).approval!;
  const binding = { approvalId: approval.id, callId: `call:${approval.id}`, sessionId: `session:${approval.id}`, requestId: `request:${approval.id}` };
  f.home.bindApproval(actor, binding);
  return { approval, binding, caseId: c.id };
}
const sqlRows = (filename: string, table: string) => { const db = new DatabaseSync(filename, { readOnly: true }); try { return db.prepare(`SELECT id,data FROM ${table} ORDER BY id`).all(); } finally { db.close(); } };

test('startup and reopen stay empty; explicit initialization is atomic, authenticated and replayable', async () => {
  const f = fixture();
  try {
    assert.deepEqual(f.snapshot().workspace, { status: 'empty' });
    assert.deepEqual(f.snapshot().appliances, []); assert.deepEqual(f.snapshot().providers, []); assert.equal(f.snapshot().expenses.length, 0);
    await f.home.execute({ principalId: 'clock', role: 'scheduler' }, { id: 'empty-tick', type: 'work.tick' });
    await assert.rejects(f.send({ type: 'preference.save', text: 'Before setup' }), /initialize/i);
    await assert.rejects(f.home.execute({ principalId: 'clock', role: 'scheduler' }, { id: 'scheduler-initialize', type: 'dataset.initialize', dataset: demoDataset }), /unauthorized/i);
    const bad = structuredClone(demoDataset); bad.expenses[0]!.applianceId = 'missing';
    await assert.rejects(f.send({ type: 'dataset.initialize', dataset: bad }), /expense/i);
    f.restart(); assert.equal(f.snapshot().workspace.status, 'empty');
    const command = { id: 'init', type: 'dataset.initialize' as const, dataset: demoDataset };
    const first = await f.home.execute(actor, command); assert.equal(first.status, 'applied');
    f.restart(); assert.equal((await f.home.execute(actor, command)).status, 'replayed');
    await assert.rejects(f.home.execute({ principalId: 'someone-else', role: 'operator' }, command), /actor/i);
    await assert.rejects(f.send({ type: 'dataset.initialize', dataset: demoDataset }), /empty/i);
    assert.equal(f.snapshot().appliances.length, 5); assert.equal(sqlRows(f.filename, 'service_events').length, 5);
  } finally { f.close(); }
});

test('separate synthetic artifacts reproduce byte for byte and alternate identifiers drive generic policy and warranty work', async () => {
  const generated = generateDatasets();
  assert.equal(generated.length, 2);
  for (const d of generated) { assert.deepEqual(HouseholdDatasetSchema.parse(d), d); assert.equal(readFileSync(new URL(`../datasets/${d.metadata.id}.json`, import.meta.url), 'utf8'), `${JSON.stringify(d, null, 2)}\n`); }
  assert.deepEqual(datasetCatalog.map(d => d.dataset), generated);
  const f = fixture(generated[1]);
  try {
    await f.send({ type: 'work.tick' });
    const generic = f.snapshot().cases.find(c => c.applianceId === 'cedar-ventilation' && !c.title.includes('warranty'))!;
    assert.ok(generic); assert.deepEqual(generic.budget, generated[1]!.household.budget);
    await f.send({ type: 'clock.set', now: '2032-10-25T09:00:00+05:30' });
    assert.ok(f.snapshot().cases.some(c => c.applianceId === 'cedar-ventilation' && c.title.includes('warranty')));
    await f.send({ type: 'case.openUrgent', applianceId: 'cedar-ventilation', description: 'Fan is sparking' });
    assert.ok(f.snapshot().cases.some(c => c.applianceId === 'cedar-ventilation' && c.urgent));
    await f.send({ type: 'case.requestOffers', caseId: generic.id });
    assert.equal(f.snapshot().cases.find(c => c.id === generic.id)!.offers[0]!.providerId, 'cedar-general');
  } finally { f.close(); }
});

test('personal records use system time, optimistic revisions, ordinary generic asset/provider edits and export reimport', async () => {
  const data = personal(); const f = fixture(data); const target = fixture();
  try {
    assert.ok(Math.abs(Date.parse(f.snapshot().clock.effectiveNow) - Date.now()) < 1000);
    await assert.rejects(f.send({ type: 'clock.set', now: '2032-10-22T09:00:00Z' }), /system clock/i);
    await assert.rejects(f.send({ type: 'fixture.change', change: { kind: 'policy', applianceId: 'vent-77', intervalDays: 3 } }), /ordinary record/i);
    const h = f.snapshot().household;
    await f.send({ type: 'household.update', expectedRevision: h.revision, name: 'Edited household', budget: money(90000), warrantyNoticeDays: 3 });
    await assert.rejects(f.send({ type: 'household.update', expectedRevision: h.revision, name: 'Stale household', budget: money(1), warrantyNoticeDays: 1 }), /revision/i);
    const a = f.snapshot().appliances[0]!;
    await f.send({ type: 'asset.upsert', expectedRevision: a.revision, record: { ...a.record, maintenance: { intervalDays: 30, sourceId: 'new-policy' }, warranty: null } });
    await assert.rejects(f.send({ type: 'asset.upsert', expectedRevision: a.revision, record: a.record }), /revision/i);
    const p = f.snapshot().providers[0]!;
    await f.send({ type: 'provider.upsert', expectedRevision: p.revision, record: { ...p.record, name: 'Updated technician', contactNote: 'Source: owner directory' } });
    await assert.rejects(f.send({ type: 'provider.upsert', expectedRevision: p.revision, record: p.record }), /revision/i);
    await f.send({ type: 'asset.upsert', expectedRevision: null, record: { id: 'new-asset', name: 'New fixture', kind: 'other', location: 'Cellar', lastService: null, maintenance: null, warranty: null } });
    await f.send({ type: 'provider.upsert', expectedRevision: null, record: { ...p.record, id: 'second-provider', name: 'Second technician' } });
    f.restart();
    assert.equal(f.snapshot().household.name, 'Edited household'); assert.equal(f.snapshot().appliances[0]!.record.maintenance!.sourceId, 'new-policy'); assert.equal(f.snapshot().providers[0]!.record.contactNote, 'Source: owner directory');
    assert.ok(f.snapshot().cases.filter(c => c.state === 'due').every(c => c.budget.minor === 90000));
    const exported = f.home.exportDataset(actor); assert.equal(exported.demoNow, null); assert.equal(exported.expenses[0]!.sourceId, 'actual-invoice');
    await target.send({ type: 'dataset.initialize', dataset: exported });
    assert.deepEqual(target.home.exportDataset(actor), exported);
    await assert.rejects(target.send({ type: 'dataset.initialize', dataset: exported }), /empty/i);
    assert.equal(target.snapshot().expenses[0]!.caseId, null); assert.equal(target.snapshot().expenses[0]!.serviceEventId, null);
  } finally { f.close(); target.close(); }
});

test('manual quote approval produces exactly one local plan and no provider acceptance, booking, completion or charge', async () => {
  const f = fixture(personal());
  try {
    await f.send({ type: 'work.tick' }); const c = active(f); const initial = f.snapshot();
    const dueEvidence = initial.activity.find(a => a.caseId === c.id && a.kind === 'maintenance.due')!; assert.ok(dueEvidence.sourceIds.includes('owner-policy')); assert.ok(dueEvidence.sourceIds.includes('invoice:2020'));
    await f.send({ type: 'case.requestOffers', caseId: c.id });
    assert.equal(active(f).offers.length, 0); assert.ok(!f.snapshot().activity.some(a => a.kind === 'provider.accepted'));
    const { approval, binding, caseId } = await select(f);
    assert.equal(approval.terms.fulfillment, 'manual_plan'); assert.equal(approval.terms.sourceId, 'quote:phone:73000');
    await assert.rejects(f.home.execute(actor, { id: 'without-consent', type: 'case.book', caseId, approvalId: approval.id }), /approval/i);
    f.restart(); assert.deepEqual(active(f).approval!.terms, approval.terms); assert.equal(active(f).approval!.termsHash, approval.termsHash);
    await assert.rejects(f.home.settleApproval(actor, { ...binding, id: 'wrong-person', decision: 'approve', responderId: 'someone-else' }), /identity/i);
    await f.home.settleApproval(actor, { ...binding, id: 'consent', decision: 'approve', responderId: actor.principalId });
    const command = { id: 'make-plan', type: 'case.book' as const, caseId, approvalId: approval.id };
    await f.home.execute(actor, command); assert.equal((await f.home.execute(actor, command)).status, 'replayed');
    await f.home.execute(actor, { ...command, id: 'second-call' }); f.restart();
    const planned = active(f); assert.equal(planned.state, 'planned'); assert.equal(planned.servicePlan!.status, 'needs_contact'); assert.equal(planned.booking, null);
    for (const table of ['provider_operations', 'bookings']) assert.equal(sqlRows(f.filename, table).length, 0);
    assert.equal(sqlRows(f.filename, 'service_plans').length, 1); assert.equal(f.snapshot().activity.filter(a => a.kind === 'plan.created').length, 1);
    assert.deepEqual(f.snapshot().expenses, initial.expenses); assert.deepEqual(f.snapshot().appliances, initial.appliances);
    await assert.rejects(f.send({ type: 'case.complete', caseId, completedAt: f.snapshot().clock.effectiveNow.slice(0, 10), sourceId: 'premature' }), /booked/i);
    await assert.rejects(f.send({ type: 'case.confirmAppointment', caseId, confirmed: true }), /booked/i);
    await f.send({ type: 'case.confirmManualPlan', caseId, sourceId: 'call:provider-confirmed' });
    assert.equal(active(f).state, 'awaiting_completion'); assert.equal(active(f).servicePlan!.sourceId, 'call:provider-confirmed'); assert.equal(active(f).booking, null);
    const day = new Date(Date.now() + 19800000).toISOString().slice(0, 10);
    await f.send({ type: 'case.complete', caseId, completedAt: day, sourceId: 'signed-completion' });
    assert.equal(f.snapshot().appliances[0]!.lastService.value, day); assert.deepEqual(f.snapshot().expenses, initial.expenses);
    const charge = { applianceId: 'vent-77', caseId: null, serviceEventId: null, amount: money(73000), chargedOn: day, sourceId: 'paid-invoice', description: 'Confirmed paid service' };
    const expense = await f.send({ type: 'expense.record', charge });
    await f.send({ type: 'expense.correct', expenseId: expense.affectedIds[0]!, expectedRevision: 1, replacement: { ...charge, amount: money(71000), sourceId: 'corrected-paid-invoice' }, reason: 'Invoice corrected' });
    f.restart(); assert.equal(f.snapshot().expenseTotals[0]!.minor, 102000); assert.equal(f.snapshot().expenses[1]!.revision, 2);
    await assert.rejects(f.send({ type: 'expense.correct', expenseId: expense.affectedIds[0]!, expectedRevision: 1, replacement: null, reason: 'Stale correction' }), /revision/i);
  } finally { f.close(); }
});

test('changed manual quotes and provider records invalidate stale consent without generating acceptance', async () => {
  const f = fixture(personal());
  try {
    await f.send({ type: 'work.tick' }); let selected = await select(f);
    await quote(f, active(f), 74000);
    assert.equal(active(f).approval!.status, 'invalidated');
    await assert.rejects(f.home.settleApproval(actor, { ...selected.binding, id: 'stale-quote', decision: 'approve', responderId: actor.principalId }), /stale/i);
    selected = await select(f);
    await f.home.settleApproval(actor, { ...selected.binding, id: 'approve-before-edit', decision: 'approve', responderId: actor.principalId });
    const p = f.snapshot().providers[0]!;
    await f.send({ type: 'provider.upsert', expectedRevision: p.revision, record: { ...p.record, contactNote: 'Corrected phone source' } });
    assert.equal(active(f).approval!.status, 'invalidated'); assert.equal(active(f).offers[0]!.status, 'unavailable');
    await assert.rejects(f.home.execute(actor, { id: 'stale-book', type: 'case.book', caseId: selected.caseId, approvalId: selected.approval.id }), /approval/i);
    assert.equal(sqlRows(f.filename, 'service_plans').length, 0); assert.equal(sqlRows(f.filename, 'provider_operations').length, 0);
  } finally { f.close(); }
});

test('legacy metadata migration preserves exact approval authority, receipts and links and never restores deleted providers', async () => {
  const f = fixture(demoDataset);
  try {
    await f.send({ type: 'clock.set', now: '2026-10-22T09:00:00+05:30' });
    const c = f.snapshot().cases.find(c => c.applianceId === 'ac')!;
    await f.send({ type: 'case.requestOffers', caseId: c.id }); const offer = f.snapshot().cases.find(row => row.id === c.id)!.offers.find(o => o.providerId === 'coolcare')!;
    await f.send({ type: 'case.chooseOffer', caseId: c.id, offerId: offer.id, revision: offer.revision });
    const approval = f.snapshot().cases.find(row => row.id === c.id)!.approval!;
    assert.ok(!('fulfillment' in approval.terms)); assert.ok(!('sourceId' in approval.terms));
    const binding = { approvalId: approval.id, callId: 'legacy-call', sessionId: 'legacy-session', requestId: 'legacy-request' };
    f.home.bindApproval(actor, binding);
    await f.home.settleApproval(actor, { ...binding, id: 'legacy-approve', responderId: actor.principalId, decision: 'approve' });
    await f.home.execute(actor, { id: 'legacy-book', type: 'case.book', caseId: c.id, approvalId: approval.id });
    const charge = { applianceId: 'ac', caseId: c.id, serviceEventId: null, amount: money(10000), chargedOn: '2026-10-22', sourceId: 'legacy-paid-invoice', description: 'Confirmed paid inspection' };
    await f.send({ type: 'expense.record', charge });
    const before = Object.fromEntries(['approvals', 'bookings', 'provider_operations', 'command_receipts', 'expenses'].map(table => [table, sqlRows(f.filename, table)]));
    const db = new DatabaseSync(f.filename); db.exec("DELETE FROM meta WHERE id IN ('workspace','datasetMetadata','schedulingPreferences'); DELETE FROM providers WHERE id='pure-local';"); db.close();
    f.restart();
    for (const [table, rows] of Object.entries(before)) assert.deepEqual(sqlRows(f.filename, table), rows);
    assert.ok(!f.snapshot().providers.some(p => p.id === 'pure-local')); assert.ok(!('fulfillment' in f.snapshot().cases.find(row => row.id === c.id)!.approval!.terms));
    f.restart(demoDataset); assert.ok(!f.snapshot().providers.some(p => p.id === 'pure-local'));
    assert.equal(f.snapshot().workspace.status, 'ready');
    assert.equal(HouseholdDatasetSchema.parse(f.home.exportDataset(actor)).providers.length, demoDataset.providers.length - 1);
  } finally { f.close(); }
});

test('manual budget and asset edits stale unaccepted consent while completed evidence and approved plans remain immutable', async () => {
  const f = fixture(personal());
  try {
    await f.send({ type: 'work.tick' });
    let selected = await select(f);
    await f.send({ type: 'case.setBudget', caseId: selected.caseId, amount: money(70000) });
    assert.equal(active(f).approval!.status, 'invalidated');
    await assert.rejects(f.home.settleApproval(actor, { ...selected.binding, id: 'stale-budget', decision: 'approve', responderId: actor.principalId }), /stale/i);
    await f.send({ type: 'case.setBudget', caseId: selected.caseId, amount: money(80000) });
    selected = await select(f);
    const record = f.snapshot().appliances[0]!;
    await f.send({ type: 'asset.upsert', expectedRevision: record.revision, record: { ...record.record, name: 'Renamed ventilation' } });
    assert.equal(active(f).approval!.status, 'invalidated');
    await assert.rejects(f.home.settleApproval(actor, { ...selected.binding, id: 'stale-asset', decision: 'approve', responderId: actor.principalId }), /stale/i);
    selected = await select(f);
    await f.home.settleApproval(actor, { ...selected.binding, id: 'approve-plan', decision: 'approve', responderId: actor.principalId });
    await f.home.execute(actor, { id: 'plan', type: 'case.book', caseId: selected.caseId, approvalId: selected.approval.id });
    const immutablePlan = sqlRows(f.filename, 'service_plans'); const immutableApproval = sqlRows(f.filename, 'approvals');
    const provider = f.snapshot().providers[0]!;
    await f.send({ type: 'provider.upsert', expectedRevision: provider.revision, record: { ...provider.record, name: 'Directory name corrected' } });
    await assert.rejects(f.send({ type: 'case.setBudget', caseId: selected.caseId, amount: money(100) }), /unaccepted/i);
    assert.deepEqual(sqlRows(f.filename, 'service_plans'), immutablePlan); assert.deepEqual(sqlRows(f.filename, 'approvals'), immutableApproval);
    await f.send({ type: 'case.confirmManualPlan', caseId: selected.caseId, sourceId: 'call:arranged' });
    await f.send({ type: 'case.complete', caseId: selected.caseId, completedAt: '2020-01-02', sourceId: 'signed-old-completion' });
    const history = sqlRows(f.filename, 'service_events');
    const latest = f.snapshot().appliances[0]!;
    await f.send({ type: 'asset.upsert', expectedRevision: latest.revision, record: { ...latest.record, lastService: { performedOn: '2021-01-01', sourceId: 'corrected-current-baseline' }, maintenance: null } });
    for (const event of history) assert.ok(sqlRows(f.filename, 'service_events').some(row => row.id === event.id && row.data === event.data));
    assert.equal(f.snapshot().cases.find(c => c.id === selected.caseId)!.state, 'completed');
    await assert.rejects(f.send({ type: 'case.setBudget', caseId: selected.caseId, amount: money(100) }), /unaccepted/i);
  } finally { f.close(); }
});

test('historical invoices import without fabricated service events and changed warranty terms produce current warnings', async () => {
  const data = personal(); data.appliances[0]!.lastService = null;
  const f = fixture(data);
  try {
    assert.equal(sqlRows(f.filename, 'service_events').length, 0);
    assert.equal(f.snapshot().expenses[0]!.serviceEventId, null); assert.equal(f.snapshot().expenses[0]!.caseId, null);
    await f.send({ type: 'work.tick' });
    const old = f.snapshot().cases.find(c => c.title.includes('warranty'))!; assert.ok(old);
    const a = f.snapshot().appliances[0]!;
    await f.send({ type: 'asset.upsert', expectedRevision: a.revision, record: { ...a.record, warranty: { ...a.record.warranty!, terms: 'Corrected manufacturer document terms.' } } });
    assert.equal(f.snapshot().cases.find(c => c.id === old.id)!.state, 'cancelled');
    const current = f.snapshot().cases.find(c => c.title.includes('warranty') && c.state === 'due')!;
    assert.match(current.reason, /Corrected manufacturer document terms/);
    assert.equal(sqlRows(f.filename, 'service_events').length, 0);
    f.restart(); assert.equal(f.home.exportDataset(actor).expenses[0]!.sourceId, 'actual-invoice');
  } finally { f.close(); }
});
