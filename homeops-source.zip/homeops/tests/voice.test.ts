import { test } from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import { execFile, type ExecFileOptions } from 'node:child_process';
import { mkdtemp, readFile, readdir, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { promisify } from 'node:util';

const modulePath = '../scripts/voice.mjs';
const { createVoiceHandler } = await import(modulePath);
const exec = promisify(execFile);

function wav(seconds: number, amplitude = 6000) {
  const samples = Math.round(seconds * 16000);
  const result = Buffer.alloc(44 + samples * 2);
  result.write('RIFF'); result.writeUInt32LE(result.length - 8, 4); result.write('WAVEfmt ', 8);
  result.writeUInt32LE(16, 16); result.writeUInt16LE(1, 20); result.writeUInt16LE(1, 22);
  result.writeUInt32LE(16000, 24); result.writeUInt32LE(32000, 28);
  result.writeUInt16LE(2, 32); result.writeUInt16LE(16, 34); result.write('data', 36);
  result.writeUInt32LE(samples * 2, 40);
  for (let i = 0; i < samples; i++) result.writeInt16LE(Math.round(Math.sin(i * 2 * Math.PI * 200 / 16000) * amplitude), 44 + i * 2);
  return result;
}

type Run = (command: string, args: string[], options: ExecFileOptions) => Promise<unknown>;
async function setup(options: { unavailable?: boolean; run?: Run } = {}) {
  const directory = await mkdtemp(join(tmpdir(), 'homeops-voice-test-'));
  const scratch = join(directory, 'scratch');
  const { mkdir } = await import('node:fs/promises');
  await mkdir(scratch);
  const modelPath = join(directory, 'model.bin');
  if (!options.unavailable) await writeFile(modelPath, 'fixture model, never passed to real whisper');
  const calls: { command: string; args: string[]; text?: string }[] = [];
  const run: Run = options.run ?? (async (command, args, processOptions) => {
    calls.push({ command, args });
    if (command === '/fixture/whisper-cli') {
      await writeFile(`${args[args.indexOf('-of') + 1]}.txt`, 'The kitchen sink is leaking.');
      return {};
    }
    if (command === '/fixture/speech') {
      calls.at(-1)!.text = await readFile(args[args.indexOf('-f') + 1], 'utf8');
      await writeFile(args[args.indexOf(process.platform === 'darwin' ? '-o' : '-w') + 1], wav(1));
      return {};
    }
    return exec(command, args, processOptions);
  });
  let origin = '';
  const server = http.createServer();
  await new Promise<void>(resolve => server.listen(0, '127.0.0.1', resolve));
  const address = server.address();
  assert.ok(address && typeof address !== 'string');
  origin = `http://127.0.0.1:${address.port}`;
  const handler = createVoiceHandler({
    root: directory, origin, modelPath, temporaryRoot: scratch, run,
    session: (req: http.IncomingMessage) => req.headers.cookie === 'operator=valid' ? { csrf: 'fixture-csrf' } : null,
    equal: (a: unknown, b: unknown) => typeof a === 'string' && a === b,
    findExecutable: async (name: string) => name === 'ffmpeg' ? 'ffmpeg' : name.endsWith('whisper-cli') ? '/fixture/whisper-cli' : '/fixture/speech',
  });
  server.on('request', (req, res) => { void handler(req, res).then((handled: boolean) => { if (!handled) { res.writeHead(404); res.end(); } }); });
  async function request(route: string, value?: unknown, extra: Record<string, string> = {}, method = value === undefined ? 'GET' : 'POST') {
    return fetch(`${origin}/api/homeops/voice/${route}`, {
      method,
      headers: { cookie: 'operator=valid', origin, 'x-homeops-csrf': 'fixture-csrf', 'content-type': 'application/json', ...extra },
      ...(value === undefined ? {} : { body: typeof value === 'string' ? value : JSON.stringify(value) }),
    });
  }
  async function close() {
    server.closeAllConnections();
    await new Promise<void>((resolve, reject) => server.close(error => error ? reject(error) : resolve()));
    await rm(directory, { recursive: true, force: true });
  }
  return { request, close, calls, scratch };
}

const recording = (seconds = 1, amplitude = 6000) => ({ audioBase64: wav(seconds, amplitude).toString('base64'), mimeType: 'audio/wav' });

test('voice routes require a session, exact POST origin and CSRF before invoking a process', async () => {
  const h = await setup();
  try {
    for (const route of ['status', 'transcribe', 'speak']) {
      const response = await h.request(route, route === 'status' ? undefined : {}, { cookie: '' });
      assert.equal(response.status, 401);
    }
    for (const headers of [{ origin: 'https://outside.invalid' }, { origin: '' }, { 'x-homeops-csrf': '' }] as Record<string, string>[]) {
      const response = await h.request('transcribe', recording(), headers);
      assert.equal(response.status, 403);
    }
    assert.equal((await h.request('status', undefined, { origin: 'https://outside.invalid' })).status, 403);
    assert.equal((await h.request('status', undefined, { 'sec-fetch-site': 'cross-site' })).status, 403);
    assert.equal((await h.request('speak', { text: 'Hello' }, { 'x-homeops-csrf': '' })).status, 403);
    assert.equal(h.calls.length, 0);
  } finally { await h.close(); }
});

test('status reports local capabilities and limits without exposing model paths', async () => {
  const h = await setup({ unavailable: true });
  try {
    const response = await h.request('status', undefined, { origin: '' });
    assert.equal(response.status, 200);
    assert.equal(response.headers.get('cache-control'), 'no-store');
    const value = await response.json();
    assert.equal(value.transcription.available, false);
    assert.equal(value.transcription.engine, 'whisper.cpp');
    assert.match(value.transcription.reason, /model is not installed/);
    assert.equal(value.speech.available, true);
    assert.deepEqual(value.limits, { maxSeconds: 30, maxBytes: 8388608 });
    assert.ok(!JSON.stringify(value).includes(tmpdir()));
    const unavailable = await h.request('transcribe', recording());
    assert.equal(unavailable.status, 503);
    assert.equal((await unavailable.json()).error.code, 'voice_unavailable');
    assert.equal(h.calls.length, 0);
  } finally { await h.close(); }
});

test('malformed JSON, MIME, encoding, byte limits and text are rejected', async () => {
  const h = await setup();
  try {
    const cases: [string, unknown, number, Record<string, string>?][] = [
      ['transcribe', '{', 400], ['transcribe', [], 400], ['transcribe', 'a'.repeat(12_000_000), 413],
      ['transcribe', recording(), 415, { 'content-type': 'text/plain' }],
      ['transcribe', recording(), 415, { 'content-encoding': 'gzip' }],
      ['transcribe', { ...recording(), mimeType: 'audio/x-playlist' }, 415],
      ['transcribe', { ...recording(), mimeType: 'audio/wav;codecs=../../etc' }, 415],
      ['transcribe', { audioBase64: 'Zg==junk', mimeType: 'audio/wav' }, 400],
      ['transcribe', { audioBase64: 'Zh==', mimeType: 'audio/wav' }, 400],
      ['transcribe', { audioBase64: 'data:audio/wav;base64,AAAA', mimeType: 'audio/wav' }, 400],
      ['transcribe', { audioBase64: '', mimeType: 'audio/wav' }, 400],
      ['transcribe', { audioBase64: Buffer.alloc(8_388_609).toString('base64'), mimeType: 'audio/wav' }, 413],
      ['speak', { text: '' }, 400], ['speak', { text: 'a'.repeat(1801) }, 400],
      ['speak', { text: 'hello\u0000world' }, 400],
    ];
    for (const [route, value, status, headers] of cases) {
      const response = await h.request(route, value, headers);
      assert.equal(response.status, status, JSON.stringify({ route, status, body: await response.text() }));
    }
    assert.equal(h.calls.length, 0);
    assert.equal((await h.request('speak', undefined, {}, 'GET')).status, 405);
    assert.equal((await h.request('unknown')).status, 404);
  } finally { await h.close(); }
});

test('real PCM conversion rejects digital silence, inaudible audio and over-30-second recordings before ASR', async () => {
  const h = await setup();
  try {
    for (const [seconds, amplitude, code] of [[1, 0, 'no_speech'], [1, 1, 'no_speech'], [30.05, 6000, 'audio_too_long']] as const) {
      const response = await h.request('transcribe', recording(seconds, amplitude));
      assert.equal(response.status, 422);
      assert.equal((await response.json()).error.code, code);
      assert.deepEqual(await readdir(h.scratch), []);
    }
    const invalid = await h.request('transcribe', { audioBase64: Buffer.from('this is not a wave').toString('base64'), mimeType: 'audio/wav' });
    assert.equal(invalid.status, 422);
    const playlist = await h.request('transcribe', { audioBase64: Buffer.from('ffconcat version 1.0\nfile file:///etc/passwd\n').toString('base64'), mimeType: 'audio/wav' });
    assert.equal(playlist.status, 422);
    assert.ok(h.calls.every(call => call.command.endsWith('ffmpeg')));
    assert.deepEqual(await readdir(h.scratch), []);
  } finally { await h.close(); }
});

test('ASR returns editable text, supports codec parameters, accepts exactly 30 seconds and cleans raw audio', async () => {
  const h = await setup();
  try {
    const response = await h.request('transcribe', { ...recording(30), mimeType: 'audio/wav; codecs=pcm' });
    assert.equal(response.status, 200);
    assert.deepEqual(await response.json(), { text: 'The kitchen sink is leaking.', engine: 'whisper.cpp', language: 'en' });
    const call = h.calls.find(call => call.command.endsWith('whisper-cli'))!;
    assert.ok(!call.args.includes('--prompt'));
    assert.ok(call.args.includes('-ng'));
    assert.deepEqual(await readdir(h.scratch), []);
  } finally { await h.close(); }
});

test('speech reads literal supplied text and returns a playable WAV without retaining audio or text', async () => {
  const h = await setup();
  try {
    const text = 'Inspection needs approval. $(touch /tmp/never-run) `echo literal`';
    const response = await h.request('speak', { text });
    assert.equal(response.status, 200);
    assert.equal(response.headers.get('content-type'), 'audio/wav');
    assert.equal(response.headers.get('cache-control'), 'no-store');
    const bytes = Buffer.from(await response.arrayBuffer());
    assert.equal(bytes.toString('ascii', 0, 4), 'RIFF');
    assert.ok(bytes.length > 1000);
    assert.equal(h.calls.find(call => call.command === '/fixture/speech')?.text, text);
    assert.deepEqual(await readdir(h.scratch), []);
  } finally { await h.close(); }
});

test('processing timeout is recoverable and cleans temporary files', async () => {
  const h = await setup({ run: async () => { throw Object.assign(new Error('fixture timeout with private content'), { killed: true }); } });
  try {
    for (let i = 0; i < 2; i++) {
      const response = await h.request('transcribe', recording());
      assert.equal(response.status, 504);
      const value = await response.json();
      assert.equal(value.error.code, 'voice_timeout');
      assert.equal(value.error.retryable, true);
      assert.ok(!JSON.stringify(value).includes('private content'));
      assert.deepEqual(await readdir(h.scratch), []);
    }
  } finally { await h.close(); }
});

test('real browser-compatible WebM, MP4, MP3 and Ogg audio reaches the same transcription boundary', async () => {
  const h = await setup();
  const dir = await mkdtemp(join(tmpdir(), 'homeops-voice-formats-'));
  try {
    const source = join(dir, 'source.wav');
    await writeFile(source, wav(1));
    for (const [extension, mimeType, codec] of [['webm', 'audio/webm;codecs=opus', 'libopus'], ['m4a', 'audio/mp4', 'aac'], ['mp3', 'audio/mpeg', 'libmp3lame'], ['ogg', 'audio/ogg', 'libopus']]) {
      const output = join(dir, `converted.${extension}`);
      await exec('ffmpeg', ['-nostdin', '-hide_banner', '-loglevel', 'error', '-i', source, '-c:a', codec!, output]);
      const response = await h.request('transcribe', { audioBase64: (await readFile(output)).toString('base64'), mimeType });
      assert.equal(response.status, 200, `${mimeType} ${await response.text()}`);
      assert.deepEqual(await readdir(h.scratch), []);
    }
  } finally { await h.close(); await rm(dir, { recursive: true, force: true }); }
});

test('concurrent voice generation returns a recoverable busy response and releases the slot after failure', async () => {
  let release: () => void = () => {};
  let notifyStarted: () => void = () => {};
  const started = new Promise<void>(resolve => { notifyStarted = resolve; });
  const waiting = new Promise<void>(resolve => { release = resolve; });
  const h = await setup({ run: async () => { notifyStarted(); await waiting; throw new Error('fixture failure'); } });
  try {
    const first = h.request('speak', { text: 'First request.' });
    await started;
    const second = await h.request('speak', { text: 'Second request.' });
    assert.equal(second.status, 429);
    assert.equal((await second.json()).error.code, 'voice_busy');
    release();
    assert.equal((await first).status, 422);
    assert.deepEqual(await readdir(h.scratch), []);
    assert.equal((await h.request('speak', { text: 'Try again.' })).status, 422);
  } finally { release(); await h.close(); }
});
