import { z } from 'zod';

export const MoneySchema = z.object({ minor: z.number().int().nonnegative().safe(), currency: z.literal('INR') });
export type Money = z.infer<typeof MoneySchema>;
const localTime = z.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/, 'Use a local time in HH:mm format.');
const minutes = (value: string) => Number(value.slice(0, 2)) * 60 + Number(value.slice(3));
export const AvailabilityPreferencesSchema = z.object({
  daysOfWeek: z.array(z.number().int().min(1).max(7)).min(1).max(7).refine(days => new Set(days).size === days.length, 'Choose each weekday only once.'),
  startTime: localTime,
  endTime: localTime,
  timezone: z.literal('Asia/Kolkata'),
}).strict().refine(value => minutes(value.endTime) - minutes(value.startTime) >= 60, 'Allow at least one hour within a single local day.');
export type AvailabilityPreferences = z.infer<typeof AvailabilityPreferencesSchema>;
export const DEFAULT_AVAILABILITY_PREFERENCES: AvailabilityPreferences = { daysOfWeek: [1, 2, 3, 4, 5], startTime: '09:00', endTime: '12:00', timezone: 'Asia/Kolkata' };
const recordId = z.string().trim().min(1).max(160);
const recordText = z.string().trim().min(1).max(500);
export const ApplianceKindSchema = z.enum(['ac', 'purifier', 'washer', 'garden', 'sink', 'other']);
export type ApplianceKind = z.infer<typeof ApplianceKindSchema>;
export const ApplianceInputSchema = z.object({
  id: recordId, name: recordText, kind: ApplianceKindSchema, location: recordText,
  lastService: z.object({ performedOn: z.iso.date(), sourceId: recordId }).strict().nullable(),
  maintenance: z.object({ intervalDays: z.number().int().min(1).max(3650), sourceId: recordId }).strict().nullable(),
  warranty: z.object({ ends: z.iso.date(), sourceId: recordId, terms: recordText }).strict().nullable(),
}).strict();
export type ApplianceInput = z.infer<typeof ApplianceInputSchema>;
export const ProviderInputSchema = z.object({
  id: recordId, name: recordText, serviceKind: ApplianceKindSchema, preferred: z.boolean(),
  available: z.boolean(), contactNote: z.string().trim().max(1000).nullable(),
  simulation: z.object({ declines: z.boolean(), amount: MoneySchema }).strict().nullable(),
}).strict();
export type ProviderInput = z.infer<typeof ProviderInputSchema>;
export const DatasetExpenseSchema = z.object({ id: recordId, applianceId: recordId, amount: MoneySchema, chargedOn: z.iso.date(), sourceId: recordId, description: recordText }).strict();
export const HouseholdDatasetSchema = z.object({
  format: z.literal('homeops.household'), version: z.literal(1),
  metadata: z.object({ id: recordId, name: recordText, description: z.string().trim().max(1000), kind: z.enum(['synthetic', 'personal']), provenance: recordText }).strict(),
  providerMode: z.enum(['simulated', 'manual']), demoNow: z.iso.datetime({ offset: true }).nullable(),
  household: z.object({ id: recordId, name: recordText, budget: MoneySchema, warrantyNoticeDays: z.number().int().min(0).max(365) }).strict(),
  schedulingPreferences: AvailabilityPreferencesSchema,
  notes: z.array(z.string().trim().min(1).max(1000)).max(100),
  appliances: z.array(ApplianceInputSchema).max(500), providers: z.array(ProviderInputSchema).max(500), expenses: z.array(DatasetExpenseSchema).max(5000),
}).strict().superRefine((value, context) => {
  for (const key of ['appliances', 'providers', 'expenses'] as const) {
    const seen = new Set<string>();
    for (const [i, record] of value[key].entries()) {
      if (seen.has(record.id)) context.addIssue({ code: 'custom', path: [key, i, 'id'], message: 'IDs must be unique within each collection.' });
      seen.add(record.id);
    }
  }
  const applianceIds = new Set(value.appliances.map(record => record.id));
  value.expenses.forEach((record, i) => {
    if (!applianceIds.has(record.applianceId)) context.addIssue({ code: 'custom', path: ['expenses', i, 'applianceId'], message: 'Expense must reference an appliance in this dataset.' });
  });
  if (value.metadata.kind === 'personal' && (value.providerMode !== 'manual' || value.demoNow !== null)) context.addIssue({ code: 'custom', message: 'Personal households use manual providers and the system clock.' });
  value.providers.forEach((record, i) => {
    if ((value.providerMode === 'simulated') !== (record.simulation !== null)) context.addIssue({ code: 'custom', path: ['providers', i, 'simulation'], message: 'Provider simulation must match the household provider mode.' });
  });
});
export type HouseholdDataset = z.infer<typeof HouseholdDatasetSchema>;
export type WorkspaceInfo = { status: 'empty' } | { status: 'ready'; dataKind: 'synthetic' | 'personal'; providerMode: 'simulated' | 'manual'; datasetId: string; datasetVersion: number };
export type Evidence<T> = { value: T; sourceId: string } | { value: null; reason: string };
export type CaseState = 'due' | 'requesting_offers' | 'awaiting_approval' | 'booking' | 'booked' | 'planned' | 'awaiting_completion' | 'completed' | 'denied' | 'unavailable' | 'cancelled' | 'failed';
export type QuoteTerms = {
  caseId: string; providerId: string; offerId: string; revision: number;
  slot: { start: string; end: string }; expiresAt: string;
  charge: { kind: 'fixed'; total: Money } | { kind: 'inspection'; fee: Money; parts: 'unknown' };
} & ({ fulfillment?: never; sourceId?: never } | { fulfillment: 'manual_plan'; sourceId: string });
export type OfferCard = { id: string; providerId: string; providerName: string; revision: number; status: 'declined' | 'unavailable' | 'available'; terms: QuoteTerms | null; withinBudget: boolean | null; simulated: boolean; explanation: string };
export type ApprovalCard = { id: string; status: 'pending' | 'approved' | 'denied' | 'invalidated' | 'consumed'; terms: QuoteTerms; termsHash: string; sessionId: string | null; requestId: string | null };
export type BookingCard = { receiptId: string; operationId: string; providerName: string; start: string; end: string; confirmed: boolean | null; simulated: true };
export type ManualServicePlan = { id: string; caseId: string; approvalId: string; terms: QuoteTerms; status: 'needs_contact' | 'user_confirmed'; sourceId: string | null; createdAt: string; confirmedAt: string | null };
export type CaseCard = { id: string; applianceId: string; purpose: 'maintenance' | 'warranty' | 'urgent'; title: string; state: CaseState; reason: string; budget: Money; urgent: boolean; offers: OfferCard[]; approval: ApprovalCard | null; booking: BookingCard | null; servicePlan: ManualServicePlan | null; sessionId: string | null };
export type ApplianceCard = { id: string; name: string; kind: ApplianceKind; location: string; lastService: Evidence<string>; nextDue: Evidence<string>; warrantyEnds: Evidence<string>; intervalDays: number | null; revision: number; record: ApplianceInput };
export type ExpenseRow = { id: string; revision: number; applianceId: string; caseId: string | null; serviceEventId: string | null; amount: Money; chargedOn: string; sourceId: string; description: string };
export type InboxItem = { id: string; caseId: string; title: string; body: string; createdAt: string; readAt: string | null; sessionId: string | null };
export type ActivityRow = { id: string; caseId: string | null; at: string; kind: string; summary: string; sourceIds: string[]; simulated: boolean };
export type HouseholdSnapshot = { schemaVersion: 1; workspace: WorkspaceInfo; revision: number; clock: { effectiveNow: string; timezone: 'Asia/Kolkata' }; household: { id: string; name: string; budget: Money; revision: number; warrantyNoticeDays: number }; appliances: ApplianceCard[]; cases: CaseCard[]; inbox: InboxItem[]; expenses: ExpenseRow[]; expenseTotals: Money[]; activity: ActivityRow[]; providers: { id: string; name: string; available: boolean; preferred: boolean; revision: number; record: ProviderInput }[]; preferences: string[]; schedulingPreferences: AvailabilityPreferences };

const id = z.string().min(1).max(160);
const day = z.iso.date();
const charge = z.object({ applianceId: id, caseId: id.nullable(), serviceEventId: id.nullable(), amount: MoneySchema, chargedOn: day, sourceId: id, description: z.string().min(1).max(500) });
export const PublicCommandSchema = z.discriminatedUnion('type', [
  z.object({ type: z.literal('dataset.initialize'), dataset: HouseholdDatasetSchema }),
  z.object({ type: z.literal('household.update'), expectedRevision: z.number().int().positive(), name: recordText, budget: MoneySchema, warrantyNoticeDays: z.number().int().min(0).max(365) }),
  z.object({ type: z.literal('asset.upsert'), expectedRevision: z.number().int().positive().nullable(), record: ApplianceInputSchema }),
  z.object({ type: z.literal('provider.upsert'), expectedRevision: z.number().int().positive().nullable(), record: ProviderInputSchema }),
  z.object({ type: z.literal('case.setBudget'), caseId: id, amount: MoneySchema }),
  z.object({ type: z.literal('case.recordQuote'), caseId: id, providerId: id, slot: z.object({ start: z.iso.datetime({ offset: true }), end: z.iso.datetime({ offset: true }) }).strict(), expiresAt: z.iso.datetime({ offset: true }), sourceId: id, charge: z.discriminatedUnion('kind', [z.object({ kind: z.literal('fixed'), total: MoneySchema }), z.object({ kind: z.literal('inspection'), fee: MoneySchema, parts: z.literal('unknown') })]) }),
  z.object({ type: z.literal('case.confirmManualPlan'), caseId: id, sourceId: id }),
  z.object({ type: z.literal('clock.set'), now: z.iso.datetime({ offset: true }) }),
  z.object({ type: z.literal('case.openUrgent'), applianceId: id, description: z.string().min(1).max(1000) }),
  z.object({ type: z.literal('case.requestOffers'), caseId: id }),
  z.object({ type: z.literal('case.chooseOffer'), caseId: id, offerId: id, revision: z.number().int().positive() }),
  z.object({ type: z.literal('case.confirmAppointment'), caseId: id, confirmed: z.boolean() }),
  z.object({ type: z.literal('case.complete'), caseId: id, completedAt: day, sourceId: id }),
  z.object({ type: z.literal('expense.record'), charge }),
  z.object({ type: z.literal('expense.correct'), expenseId: id, expectedRevision: z.number().int().positive(), replacement: charge.nullable(), reason: z.string().min(1).max(500) }),
  z.object({ type: z.literal('fixture.change'), change: z.discriminatedUnion('kind', [
    z.object({ kind: z.literal('budget'), caseId: id, amount: MoneySchema }),
    z.object({ kind: z.literal('provider'), providerId: id, available: z.boolean() }),
    z.object({ kind: z.literal('policy'), applianceId: id, intervalDays: z.number().int().min(1).max(3650) }),
    z.object({ kind: z.literal('serviceDate'), applianceId: id, performedOn: day.nullable() }),
    z.object({ kind: z.literal('quote'), offerId: id, amount: MoneySchema, start: z.iso.datetime({ offset: true }).optional() })
  ]) }),
  z.object({ type: z.literal('inbox.read'), inboxId: id }),
  z.object({ type: z.literal('preference.save'), text: z.string().min(1).max(1000) }),
  z.object({ type: z.literal('preference.setSchedule'), preferences: AvailabilityPreferencesSchema })
]);
export type PublicCommand = z.infer<typeof PublicCommandSchema>;
export const CommandEnvelopeSchema = z.object({ commandId: id, command: PublicCommandSchema });
export type CommandResult = { commandId: string; status: 'applied' | 'pending' | 'replayed'; revision: number; affectedIds: string[] };
export type ErrorBody = { error: { code: string; message: string; retryable: boolean }; commandId?: string };
